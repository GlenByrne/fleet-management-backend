/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 523:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.context = void 0;
const client_1 = __webpack_require__(524);
const prisma = new client_1.PrismaClient();
function context(req, response) {
    return {
        ...req,
        ...response,
        prisma,
    };
}
exports.context = context;


/***/ }),

/***/ 224:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
const graphql_shield_1 = __webpack_require__(973);
const getUserId_1 = __webpack_require__(412);
const rules = {
    isAuthenticatedUser: (0, graphql_shield_1.rule)()((_, __, context) => {
        const userId = (0, getUserId_1.getUserId)(context);
        return Boolean(userId);
    }),
    isAdmin: (0, graphql_shield_1.rule)()(async (_, __, context) => {
        const userId = (0, getUserId_1.getUserId)(context);
        const user = await context.prisma.user.findUnique({
            where: {
                id: String(userId),
            },
        });
        return (user === null || user === void 0 ? void 0 : user.role) === 'ADMIN';
    }),
};
const permissions = (0, graphql_shield_1.shield)({
    Query: {
        vehicle: rules.isAuthenticatedUser,
        vehicles: rules.isAuthenticatedUser,
        defectsForVehicle: rules.isAuthenticatedUser,
        upcomingCVRT: rules.isAuthenticatedUser,
        tollTags: rules.isAuthenticatedUser,
        tollTagsNotAssigned: rules.isAuthenticatedUser,
        fuelCards: rules.isAuthenticatedUser,
        fuelCardsNotAssigned: rules.isAuthenticatedUser,
        depots: (0, graphql_shield_1.and)(rules.isAuthenticatedUser, rules.isAdmin),
        vehiclesInDepot: rules.isAuthenticatedUser,
        users: (0, graphql_shield_1.and)(rules.isAuthenticatedUser, rules.isAdmin),
    },
    Mutation: {
        addVehicle: (0, graphql_shield_1.and)(rules.isAuthenticatedUser, rules.isAdmin),
        updateVehicle: (0, graphql_shield_1.and)(rules.isAuthenticatedUser, rules.isAdmin),
        deleteVehicle: (0, graphql_shield_1.and)(rules.isAuthenticatedUser, rules.isAdmin),
        addTollTag: (0, graphql_shield_1.and)(rules.isAuthenticatedUser, rules.isAdmin),
        updateTollTag: (0, graphql_shield_1.and)(rules.isAuthenticatedUser, rules.isAdmin),
        deleteTollTag: (0, graphql_shield_1.and)(rules.isAuthenticatedUser, rules.isAdmin),
        addFuelCard: (0, graphql_shield_1.and)(rules.isAuthenticatedUser, rules.isAdmin),
        updateFuelCard: (0, graphql_shield_1.and)(rules.isAuthenticatedUser, rules.isAdmin),
        deleteFuelCard: (0, graphql_shield_1.and)(rules.isAuthenticatedUser, rules.isAdmin),
        addDepot: (0, graphql_shield_1.and)(rules.isAuthenticatedUser, rules.isAdmin),
        updateDepot: (0, graphql_shield_1.and)(rules.isAuthenticatedUser, rules.isAdmin),
        deleteDepot: (0, graphql_shield_1.and)(rules.isAuthenticatedUser, rules.isAdmin),
        addDefect: rules.isAuthenticatedUser,
        addUser: (0, graphql_shield_1.and)(rules.isAuthenticatedUser, rules.isAdmin),
        deleteUser: (0, graphql_shield_1.and)(rules.isAuthenticatedUser, rules.isAdmin),
    },
}, { allowExternalErrors: true });
exports["default"] = permissions;


/***/ }),

/***/ 734:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DateTimeScalar = void 0;
const graphql_scalars_1 = __webpack_require__(189);
const nexus_1 = __webpack_require__(854);
const graphql_middleware_1 = __webpack_require__(290);
const defectTypes = __importStar(__webpack_require__(244));
const depotTypes = __importStar(__webpack_require__(842));
const fuelCardTypes = __importStar(__webpack_require__(847));
const tollTagTypes = __importStar(__webpack_require__(20));
const vehicleTypes = __importStar(__webpack_require__(545));
const userTypes = __importStar(__webpack_require__(853));
const organisationTypes = __importStar(__webpack_require__(559));
const infringementTypes = __importStar(__webpack_require__(546));
const enumTypes = __importStar(__webpack_require__(11));
const permissions_1 = __importDefault(__webpack_require__(224));
exports.DateTimeScalar = (0, nexus_1.asNexusMethod)(graphql_scalars_1.DateTimeResolver, 'date');
const schemaWithoutPermissions = (0, nexus_1.makeSchema)({
    types: [
        defectTypes,
        depotTypes,
        fuelCardTypes,
        tollTagTypes,
        vehicleTypes,
        userTypes,
        organisationTypes,
        infringementTypes,
        enumTypes,
        exports.DateTimeScalar,
    ],
    outputs: {
        schema: `${__dirname}/../generated/schema.graphql`,
        typegen: `${__dirname}/../generated/types.ts`,
    },
    contextType: {
        module: /*require.resolve*/(523),
        export: 'Context',
    },
    sourceTypes: {
        modules: [
            {
                module: '@prisma/client',
                alias: 'prisma',
            },
        ],
    },
});
const schema = (0, graphql_middleware_1.applyMiddleware)(schemaWithoutPermissions, permissions_1.default);
exports["default"] = schema;


/***/ }),

/***/ 244:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DefectMutation = exports.DefectQuery = exports.Defect = void 0;
const nexus_1 = __webpack_require__(854);
const getUserId_1 = __webpack_require__(412);
const Enum_1 = __webpack_require__(11);
exports.Defect = (0, nexus_1.objectType)({
    name: 'Defect',
    definition(t) {
        t.nonNull.id('id');
        t.nonNull.string('description');
        t.nonNull.string('reporter');
        t.nonNull.date('dateReported');
        t.date('dateCompleted');
        t.nonNull.field('status', {
            type: Enum_1.DefectStatus,
        });
    },
});
exports.DefectQuery = (0, nexus_1.extendType)({
    type: 'Query',
    definition(t) {
        t.list.field('defectsForVehicle', {
            type: exports.Defect,
            args: {
                vehicleId: (0, nexus_1.nonNull)((0, nexus_1.idArg)()),
            },
            resolve: (_, { vehicleId }, context) => {
                try {
                    return context.prisma.vehicle
                        .findUnique({
                        where: {
                            id: vehicleId,
                        },
                    })
                        .defects();
                }
                catch (error) {
                    throw new Error('Error retrieving defects');
                }
            },
        });
    },
});
const AddDefectInput = (0, nexus_1.inputObjectType)({
    name: 'AddDefectInput',
    definition(t) {
        t.nonNull.string('description');
        t.nonNull.id('vehicleId');
    },
});
const UpdateDefectInput = (0, nexus_1.inputObjectType)({
    name: 'UpdateDefectInput',
    definition(t) {
        t.nonNull.id('id');
        t.nonNull.string('description');
        t.nonNull.field('status', {
            type: Enum_1.DefectStatus,
        });
    },
});
const DeleteDefectInput = (0, nexus_1.inputObjectType)({
    name: 'DeleteDefectInput',
    definition(t) {
        t.nonNull.id('id');
    },
});
exports.DefectMutation = (0, nexus_1.extendType)({
    type: 'Mutation',
    definition(t) {
        t.nonNull.field('addDefect', {
            type: exports.Defect,
            args: {
                data: (0, nexus_1.nonNull)((0, nexus_1.arg)({
                    type: AddDefectInput,
                })),
            },
            resolve: async (_, args, context) => {
                const userId = (0, getUserId_1.getUserId)(context);
                if (!userId) {
                    throw new Error('Unable to add defect. You are not logged in.');
                }
                const user = await context.prisma.user.findUnique({
                    where: {
                        id: userId,
                    },
                });
                if (!user) {
                    throw new Error('Unable to add defect. You are not logged in.');
                }
                return context.prisma.defect.create({
                    data: {
                        description: args.data.description,
                        dateReported: new Date(),
                        reporter: user.name,
                        status: 'INCOMPLETE',
                        vehicle: {
                            connect: {
                                id: args.data.vehicleId,
                            },
                        },
                    },
                });
            },
        });
        t.nonNull.field('updateDefect', {
            type: exports.Defect,
            args: {
                data: (0, nexus_1.nonNull)((0, nexus_1.arg)({
                    type: UpdateDefectInput,
                })),
            },
            resolve: async (_, args, context) => {
                try {
                    const isComplete = args.data.status === 'COMPLETE';
                    return context.prisma.defect.update({
                        where: {
                            id: args.data.id,
                        },
                        data: {
                            description: args.data.description,
                            status: args.data.status,
                            dateCompleted: isComplete ? new Date() : null,
                        },
                    });
                }
                catch (error) {
                    throw new Error('Error updating fuel card');
                }
            },
        });
        t.nonNull.field('deleteDefect', {
            type: exports.Defect,
            args: {
                data: (0, nexus_1.nonNull)((0, nexus_1.arg)({
                    type: DeleteDefectInput,
                })),
            },
            resolve: (_, args, context) => {
                try {
                    return context.prisma.defect.delete({
                        where: {
                            id: args.data.id,
                        },
                    });
                }
                catch (error) {
                    throw new Error('Error deleting defect');
                }
            },
        });
    },
});


/***/ }),

/***/ 842:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DepotMutation = exports.DepotQuery = exports.Depot = void 0;
const nexus_1 = __webpack_require__(854);
const getUserId_1 = __webpack_require__(412);
const Organisation_1 = __webpack_require__(559);
const Vehicle_1 = __webpack_require__(545);
exports.Depot = (0, nexus_1.objectType)({
    name: 'Depot',
    definition(t) {
        t.nonNull.id('id');
        t.nonNull.string('name');
        t.nonNull.field('organisation', {
            type: Organisation_1.Organisation,
            resolve: async (parent, _, context) => {
                const organisation = await context.prisma.depot
                    .findUnique({
                    where: { id: parent.id },
                })
                    .organisation();
                if (!organisation) {
                    throw new Error('Organisation not found');
                }
                return organisation;
            },
        });
        t.nonNull.list.nonNull.field('vehicles', {
            type: Vehicle_1.Vehicle,
            resolve(parent, _, context) {
                return context.prisma.depot
                    .findUnique({
                    where: { id: parent.id },
                })
                    .vehicles();
            },
        });
    },
});
const DepotInputFilter = (0, nexus_1.inputObjectType)({
    name: 'DepotInputFilter',
    definition(t) {
        t.string('searchCriteria');
    },
});
exports.DepotQuery = (0, nexus_1.extendType)({
    type: 'Query',
    definition(t) {
        t.list.field('depots', {
            type: exports.Depot,
            args: {
                data: (0, nexus_1.arg)({
                    type: DepotInputFilter,
                }),
            },
            resolve: async (_, args, context) => {
                var _a;
                try {
                    const userId = (0, getUserId_1.getUserId)(context);
                    if (!userId) {
                        throw new Error('Unable to retrieve depots. You are not logged in.');
                    }
                    const organisation = await context.prisma.user
                        .findUnique({
                        where: {
                            id: userId != null ? userId : undefined,
                        },
                    })
                        .organisation();
                    return context.prisma.depot.findMany({
                        where: {
                            AND: [
                                { organisationId: organisation === null || organisation === void 0 ? void 0 : organisation.id },
                                {
                                    name: {
                                        contains: ((_a = args.data) === null || _a === void 0 ? void 0 : _a.searchCriteria) != null
                                            ? args.data.searchCriteria
                                            : undefined,
                                        mode: 'insensitive',
                                    },
                                },
                            ],
                        },
                        orderBy: {
                            name: 'asc',
                        },
                    });
                }
                catch (error) {
                    throw new Error('Error retrieving depots');
                }
            },
        });
        t.list.field('vehiclesInDepot', {
            type: Vehicle_1.Vehicle,
            args: {
                depotId: (0, nexus_1.nonNull)((0, nexus_1.idArg)()),
            },
            resolve: (_, { depotId }, context) => {
                try {
                    return context.prisma.depot
                        .findUnique({
                        where: {
                            id: depotId,
                        },
                    })
                        .vehicles();
                }
                catch (error) {
                    throw new Error('Error retrieving vehicles for depot');
                }
            },
        });
    },
});
const AddDepotInput = (0, nexus_1.inputObjectType)({
    name: 'AddDepotInput',
    definition(t) {
        t.nonNull.string('name');
    },
});
const UpdateDepotInput = (0, nexus_1.inputObjectType)({
    name: 'UpdateDepotInput',
    definition(t) {
        t.nonNull.id('id');
        t.nonNull.string('name');
    },
});
const DeleteDepotInput = (0, nexus_1.inputObjectType)({
    name: 'DeleteDepotInput',
    definition(t) {
        t.nonNull.id('id');
    },
});
exports.DepotMutation = (0, nexus_1.extendType)({
    type: 'Mutation',
    definition(t) {
        t.nonNull.field('addDepot', {
            type: exports.Depot,
            args: {
                data: (0, nexus_1.nonNull)((0, nexus_1.arg)({
                    type: AddDepotInput,
                })),
            },
            resolve: async (_, args, context) => {
                try {
                    const userId = (0, getUserId_1.getUserId)(context);
                    if (!userId) {
                        throw new Error('Unable to add depot. You are not logged in.');
                    }
                    const organisation = await context.prisma.user
                        .findUnique({
                        where: {
                            id: userId != null ? userId : undefined,
                        },
                    })
                        .organisation();
                    const existingDepot = await context.prisma.depot.findUnique({
                        where: {
                            name: args.data.name,
                        },
                    });
                    if (existingDepot) {
                        throw new Error('Depot already exists with this name');
                    }
                    return context.prisma.depot.create({
                        data: {
                            name: args.data.name,
                            organisation: {
                                connect: {
                                    id: organisation === null || organisation === void 0 ? void 0 : organisation.id,
                                },
                            },
                        },
                    });
                }
                catch (error) {
                    throw new Error('Error adding depot');
                }
            },
        });
        t.nonNull.field('updateDepot', {
            type: exports.Depot,
            args: {
                data: (0, nexus_1.nonNull)((0, nexus_1.arg)({
                    type: UpdateDepotInput,
                })),
            },
            resolve: async (_, args, context) => {
                try {
                    return context.prisma.depot.update({
                        where: {
                            id: args.data.id,
                        },
                        data: {
                            name: args.data.name,
                        },
                    });
                }
                catch (error) {
                    throw new Error('Error updating depot');
                }
            },
        });
        t.nonNull.field('deleteDepot', {
            type: exports.Depot,
            args: {
                data: (0, nexus_1.nonNull)((0, nexus_1.arg)({
                    type: DeleteDepotInput,
                })),
            },
            resolve: (_, args, context) => {
                try {
                    return context.prisma.depot.delete({
                        where: {
                            id: args.data.id,
                        },
                    });
                }
                catch (error) {
                    throw new Error('Error deleting depot');
                }
            },
        });
    },
});


/***/ }),

/***/ 11:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.InfringementStatus = exports.DefectStatus = exports.VehicleType = exports.Role = void 0;
const nexus_1 = __webpack_require__(854);
exports.Role = (0, nexus_1.enumType)({
    name: 'Role',
    members: {
        Owner: 'OWNER',
        Admin: 'ADMIN',
        User: 'USER',
        Driver: 'DRIVER',
    },
});
exports.VehicleType = (0, nexus_1.enumType)({
    name: 'VehicleType',
    members: {
        Van: 'VAN',
        Truck: 'TRUCK',
        Trailer: 'TRAILER',
    },
});
exports.DefectStatus = (0, nexus_1.enumType)({
    name: 'DefectStatus',
    members: {
        Incomplete: 'INCOMPLETE',
        Complete: 'COMPLETE',
    },
});
exports.InfringementStatus = (0, nexus_1.enumType)({
    name: 'InfringementStatus',
    members: {
        Unsigned: 'UNSIGNED',
        Signed: 'SIGNED',
    },
});


/***/ }),

/***/ 847:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.FuelCardMutation = exports.FuelCardQuery = exports.FuelCard = void 0;
const nexus_1 = __webpack_require__(854);
const getUserId_1 = __webpack_require__(412);
const Organisation_1 = __webpack_require__(559);
const Vehicle_1 = __webpack_require__(545);
exports.FuelCard = (0, nexus_1.objectType)({
    name: 'FuelCard',
    definition(t) {
        t.nonNull.id('id');
        t.nonNull.string('cardNumber');
        t.nonNull.string('cardProvider');
        t.nonNull.field('organisation', {
            type: Organisation_1.Organisation,
            resolve: async (parent, _, context) => {
                const organisation = await context.prisma.fuelCard
                    .findUnique({
                    where: { id: parent.id },
                })
                    .organisation();
                if (!organisation) {
                    throw new Error('Organisation not found');
                }
                return organisation;
            },
        });
        t.field('vehicle', {
            type: Vehicle_1.Vehicle,
            resolve(parent, _, context) {
                return context.prisma.fuelCard
                    .findUnique({
                    where: { id: parent.id },
                })
                    .vehicle();
            },
        });
    },
});
const FuelCardInputFilter = (0, nexus_1.inputObjectType)({
    name: 'FuelCardInputFilter',
    definition(t) {
        t.string('searchCriteria');
    },
});
exports.FuelCardQuery = (0, nexus_1.extendType)({
    type: 'Query',
    definition(t) {
        t.list.field('fuelCards', {
            type: exports.FuelCard,
            args: {
                data: (0, nexus_1.arg)({
                    type: FuelCardInputFilter,
                }),
            },
            resolve: async (_, args, context) => {
                var _a;
                const userId = (0, getUserId_1.getUserId)(context);
                if (!userId) {
                    throw new Error('Unable to retrieve fuel cards. You are not logged in.');
                }
                const organisation = await context.prisma.user
                    .findUnique({
                    where: {
                        id: userId != null ? userId : undefined,
                    },
                })
                    .organisation();
                return context.prisma.fuelCard.findMany({
                    where: {
                        AND: [
                            { organisationId: organisation === null || organisation === void 0 ? void 0 : organisation.id },
                            {
                                cardNumber: {
                                    contains: ((_a = args.data) === null || _a === void 0 ? void 0 : _a.searchCriteria) != null
                                        ? args.data.searchCriteria
                                        : undefined,
                                    mode: 'insensitive',
                                },
                            },
                        ],
                    },
                    orderBy: {
                        cardNumber: 'asc',
                    },
                });
            },
        });
        t.list.field('fuelCardsNotAssigned', {
            type: exports.FuelCard,
            resolve: async (_, __, context) => {
                const userId = (0, getUserId_1.getUserId)(context);
                if (!userId) {
                    throw new Error('Unable to retrieve unassigned fuel cards. You are not logged in.');
                }
                const organisation = await context.prisma.user
                    .findUnique({
                    where: {
                        id: userId != null ? userId : undefined,
                    },
                })
                    .organisation();
                return context.prisma.fuelCard.findMany({
                    where: {
                        AND: [{ vehicleId: null }, { organisationId: organisation === null || organisation === void 0 ? void 0 : organisation.id }],
                    },
                    orderBy: {
                        cardNumber: 'asc',
                    },
                });
            },
        });
    },
});
const AddFuelCardInput = (0, nexus_1.inputObjectType)({
    name: 'AddFuelCardInput',
    definition(t) {
        t.nonNull.string('cardNumber');
        t.nonNull.string('cardProvider');
    },
});
const UpdateFuelCardInput = (0, nexus_1.inputObjectType)({
    name: 'UpdateFuelCardInput',
    definition(t) {
        t.nonNull.id('id');
        t.nonNull.string('cardNumber');
        t.nonNull.string('cardProvider');
    },
});
const DeleteFuelCardInput = (0, nexus_1.inputObjectType)({
    name: 'DeleteFuelCardInput',
    definition(t) {
        t.nonNull.id('id');
    },
});
exports.FuelCardMutation = (0, nexus_1.extendType)({
    type: 'Mutation',
    definition(t) {
        t.nonNull.field('addFuelCard', {
            type: exports.FuelCard,
            args: {
                data: (0, nexus_1.nonNull)((0, nexus_1.arg)({
                    type: AddFuelCardInput,
                })),
            },
            resolve: async (_, args, context) => {
                const userId = (0, getUserId_1.getUserId)(context);
                if (!userId) {
                    throw new Error('Unable to add fuel card. You are not logged in.');
                }
                const organisation = await context.prisma.user
                    .findUnique({
                    where: {
                        id: userId != null ? userId : undefined,
                    },
                })
                    .organisation();
                const existingCard = await context.prisma.fuelCard.findUnique({
                    where: {
                        cardNumber: args.data.cardNumber,
                    },
                });
                if (existingCard) {
                    throw new Error('Card already exists with this registration');
                }
                return context.prisma.fuelCard.create({
                    data: {
                        cardNumber: args.data.cardNumber,
                        cardProvider: args.data.cardProvider,
                        organisation: {
                            connect: {
                                id: organisation === null || organisation === void 0 ? void 0 : organisation.id,
                            },
                        },
                    },
                });
            },
        });
        t.nonNull.field('updateFuelCard', {
            type: exports.FuelCard,
            args: {
                data: (0, nexus_1.nonNull)((0, nexus_1.arg)({
                    type: UpdateFuelCardInput,
                })),
            },
            resolve: async (_, args, context) => {
                try {
                    return context.prisma.fuelCard.update({
                        where: {
                            id: args.data.id,
                        },
                        data: {
                            cardNumber: args.data.cardNumber,
                            cardProvider: args.data.cardProvider,
                        },
                    });
                }
                catch (error) {
                    throw new Error('Error updating fuel card');
                }
            },
        });
        t.nonNull.field('deleteFuelCard', {
            type: exports.FuelCard,
            args: {
                data: (0, nexus_1.nonNull)((0, nexus_1.arg)({
                    type: DeleteFuelCardInput,
                })),
            },
            resolve: (_, args, context) => {
                try {
                    return context.prisma.fuelCard.delete({
                        where: {
                            id: args.data.id,
                        },
                    });
                }
                catch (error) {
                    throw new Error('Error deleting fuel card');
                }
            },
        });
    },
});


/***/ }),

/***/ 546:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.InfringementMutation = exports.UserQuery = void 0;
const nexus_1 = __webpack_require__(854);
const getUserId_1 = __webpack_require__(412);
const Enum_1 = __webpack_require__(11);
const User_1 = __webpack_require__(853);
const Infringement = (0, nexus_1.objectType)({
    name: 'Infringement',
    definition(t) {
        t.nonNull.id('id');
        t.nonNull.string('description');
        t.nonNull.date('dateOccured');
        t.nonNull.field('status', {
            type: Enum_1.InfringementStatus,
        });
        t.field('driver', {
            type: User_1.UsersPayload,
            resolve(parent, _, context) {
                return context.prisma.infringement
                    .findUnique({
                    where: { id: parent.id },
                })
                    .driver({
                    select: {
                        id: true,
                        name: true,
                        email: true,
                        role: true,
                        depot: true,
                        infringements: true,
                        password: false,
                    },
                });
            },
        });
    },
});
const AddInfringementInput = (0, nexus_1.inputObjectType)({
    name: 'AddInfringementInput',
    definition(t) {
        t.nonNull.id('driverId');
        t.nonNull.string('description');
        t.nonNull.date('dateOccured');
    },
});
const UpdateInfringementInput = (0, nexus_1.inputObjectType)({
    name: 'UpdateInfringementInput',
    definition(t) {
        t.nonNull.id('id');
        t.nonNull.string('description');
        t.nonNull.date('dateOccured');
        t.nonNull.field('status', { type: Enum_1.InfringementStatus });
    },
});
const DeleteInfringementInput = (0, nexus_1.inputObjectType)({
    name: 'DeleteInfringementInput',
    definition(t) {
        t.nonNull.id('id');
    },
});
const UpdateInfringementStasusInput = (0, nexus_1.inputObjectType)({
    name: 'UpdateInfringementStasusInput',
    definition(t) {
        t.nonNull.string('id');
    },
});
exports.UserQuery = (0, nexus_1.extendType)({
    type: 'Query',
    definition(t) {
        t.list.field('infringements', {
            type: Infringement,
            resolve: async (_, __, context) => {
                const userId = (0, getUserId_1.getUserId)(context);
                if (!userId) {
                    throw new Error('Unable to retrieve infringements. You are not logged in.');
                }
                return context.prisma.infringement.findMany({
                    orderBy: {
                        dateOccured: 'desc',
                    },
                });
            },
        });
    },
});
exports.InfringementMutation = (0, nexus_1.extendType)({
    type: 'Mutation',
    definition(t) {
        t.nonNull.field('addInfringement', {
            type: Infringement,
            args: {
                data: (0, nexus_1.nonNull)((0, nexus_1.arg)({
                    type: AddInfringementInput,
                })),
            },
            resolve: async (_, args, context) => {
                const userId = (0, getUserId_1.getUserId)(context);
                if (!userId) {
                    throw new Error('Unable to add fuel card. You are not logged in.');
                }
                const driver = await context.prisma.user.findUnique({
                    where: {
                        id: args.data.driverId,
                    },
                });
                if (!driver) {
                    throw new Error('Unable to add infringemnt. Driver not found.');
                }
                if (driver.role !== 'DRIVER') {
                    throw new Error('Unable to add infringemnt. Infringements can only be added to a driver');
                }
                return context.prisma.infringement.create({
                    data: {
                        description: args.data.description,
                        dateOccured: args.data.dateOccured,
                        status: 'UNSIGNED',
                        driver: {
                            connect: {
                                id: args.data.driverId,
                            },
                        },
                    },
                });
            },
        });
        t.nonNull.field('updateInfringement', {
            type: Infringement,
            args: {
                data: (0, nexus_1.nonNull)((0, nexus_1.arg)({
                    type: UpdateInfringementInput,
                })),
            },
            resolve: async (_, args, context) => {
                try {
                    return context.prisma.infringement.update({
                        where: {
                            id: args.data.id,
                        },
                        data: {
                            description: args.data.description,
                            dateOccured: args.data.dateOccured,
                            status: args.data.status,
                        },
                    });
                }
                catch (error) {
                    throw new Error('Error updating infringement');
                }
            },
        });
        t.nonNull.field('deleteInfringement', {
            type: Infringement,
            args: {
                data: (0, nexus_1.nonNull)((0, nexus_1.arg)({
                    type: DeleteInfringementInput,
                })),
            },
            resolve: (_, args, context) => {
                try {
                    return context.prisma.infringement.delete({
                        where: {
                            id: args.data.id,
                        },
                    });
                }
                catch (error) {
                    throw new Error('Error deleting infringement');
                }
            },
        });
        t.nonNull.field('updateInfringementStatus', {
            type: Infringement,
            args: {
                data: (0, nexus_1.nonNull)((0, nexus_1.arg)({
                    type: UpdateInfringementStasusInput,
                })),
            },
            resolve: (_, args, context) => {
                try {
                    return context.prisma.infringement.update({
                        where: {
                            id: args.data.id,
                        },
                        data: {
                            status: 'SIGNED',
                        },
                    });
                }
                catch (error) {
                    throw new Error('Error updating infringements status');
                }
            },
        });
    },
});
exports["default"] = Infringement;


/***/ }),

/***/ 559:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.OrganisationMutation = exports.AddOrganisationPayload = exports.OrganisationQuery = exports.Organisation = void 0;
const bcrypt_1 = __webpack_require__(96);
const nexus_1 = __webpack_require__(854);
const Depot_1 = __webpack_require__(842);
const FuelCard_1 = __webpack_require__(847);
const TollTag_1 = __webpack_require__(20);
const Vehicle_1 = __webpack_require__(545);
const User_1 = __webpack_require__(853);
const generateAccessToken_1 = __importDefault(__webpack_require__(49));
const generateRefreshToken_1 = __importDefault(__webpack_require__(972));
exports.Organisation = (0, nexus_1.objectType)({
    name: 'Organisation',
    definition(t) {
        t.nonNull.id('id');
        t.nonNull.string('name');
        t.nonNull.list.nonNull.field('users', {
            type: User_1.User,
            resolve(parent, _, context) {
                return context.prisma.organisation
                    .findUnique({
                    where: { id: parent.id },
                })
                    .users();
            },
        });
        t.nonNull.list.nonNull.field('vehicles', {
            type: Vehicle_1.Vehicle,
            resolve(parent, _, context) {
                return context.prisma.organisation
                    .findUnique({
                    where: { id: parent.id },
                })
                    .vehicles();
            },
        });
        t.nonNull.list.nonNull.field('depots', {
            type: Depot_1.Depot,
            resolve(parent, _, context) {
                return context.prisma.organisation
                    .findUnique({
                    where: { id: parent.id },
                })
                    .depots();
            },
        });
        t.nonNull.list.nonNull.field('fuelCards', {
            type: FuelCard_1.FuelCard,
            resolve(parent, _, context) {
                return context.prisma.organisation
                    .findUnique({
                    where: { id: parent.id },
                })
                    .fuelCards();
            },
        });
        t.nonNull.list.nonNull.field('tollTags', {
            type: TollTag_1.TollTag,
            resolve(parent, _, context) {
                return context.prisma.organisation
                    .findUnique({
                    where: { id: parent.id },
                })
                    .tollTags();
            },
        });
    },
});
exports.OrganisationQuery = (0, nexus_1.extendType)({
    type: 'Query',
    definition(t) {
        // t.field('organisation', {
        //   type: Organisation,
        //   args: {
        //     organisationId: nonNull(idArg()),
        //   },
        //   resolve: (_, { organisationId }, context: Context) =>
        //     context.prisma.organisation.findUnique({
        //       where: {
        //         id: organisationId,
        //       },
        //     }),
        // });
        // t.list.field('users', {
        //   type: User,
        //   args: {
        //     organisationId: nonNull(idArg()),
        //   },
        //   resolve: (_, { organisationId }, context: Context) =>
        //     context.prisma.organisation
        //       .findUnique({
        //         where: {
        //           id: organisationId,
        //         },
        //       })
        //       .users(),
        // });
        // t.list.field('vehicles', {
        //   type: Vehicle,
        //   args: {
        //     organisationId: nonNull(idArg()),
        //   },
        //   resolve: (_, { organisationId }, context: Context) =>
        //     context.prisma.organisation
        //       .findUnique({
        //         where: {
        //           id: organisationId,
        //         },
        //       })
        //       .vehicles(),
        // });
        // t.list.field('depots', {
        //   type: Depot,
        //   args: {
        //     organisationId: nonNull(idArg()),
        //   },
        //   resolve: (_, { organisationId }, context: Context) =>
        //     context.prisma.organisation
        //       .findUnique({
        //         where: {
        //           id: organisationId,
        //         },
        //       })
        //       .depots(),
        // });
        // t.list.field('fuelCards', {
        //   type: FuelCard,
        //   args: {
        //     organisationId: nonNull(idArg()),
        //   },
        //   resolve: (_, { organisationId }, context: Context) =>
        //     context.prisma.organisation
        //       .findUnique({
        //         where: {
        //           id: organisationId,
        //         },
        //       })
        //       .fuelCards(),
        // });
        // t.list.field('tollTags', {
        //   type: TollTag,
        //   args: {
        //     organisationId: nonNull(idArg()),
        //   },
        //   resolve: (_, { organisationId }, context: Context) =>
        //     context.prisma.organisation
        //       .findUnique({
        //         where: {
        //           id: organisationId,
        //         },
        //       })
        //       .tollTags(),
        // });
    },
});
const AddOrganisationInput = (0, nexus_1.inputObjectType)({
    name: 'AddOrganisationInput',
    definition(t) {
        t.nonNull.string('name');
        t.nonNull.string('adminName');
        t.nonNull.string('email');
        t.nonNull.string('password');
    },
});
exports.AddOrganisationPayload = (0, nexus_1.objectType)({
    name: 'AddOrganisationPayload',
    definition(t) {
        t.field('organisation', {
            type: exports.Organisation,
        });
        t.field('user', {
            type: User_1.UsersPayload,
        });
        t.nonNull.string('accessToken');
    },
});
exports.OrganisationMutation = (0, nexus_1.extendType)({
    type: 'Mutation',
    definition(t) {
        t.nonNull.field('addOrganisation', {
            type: exports.AddOrganisationPayload,
            args: {
                data: (0, nexus_1.nonNull)((0, nexus_1.arg)({
                    type: AddOrganisationInput,
                })),
            },
            resolve: async (_, args, context) => {
                const existingUser = await context.prisma.user.findUnique({
                    where: {
                        email: args.data.email,
                    },
                });
                if (existingUser) {
                    throw new Error('ERROR: Account already exists with this email');
                }
                const hashedPassword = await (0, bcrypt_1.hash)(args.data.password, 10);
                const organisation = await context.prisma.organisation.create({
                    data: {
                        name: args.data.name,
                        users: {
                            create: [
                                {
                                    name: args.data.adminName,
                                    email: args.data.email,
                                    password: hashedPassword,
                                    role: 'ADMIN',
                                },
                            ],
                        },
                    },
                });
                const user = await context.prisma.user.findUnique({
                    where: {
                        email: args.data.email,
                    },
                    select: {
                        id: true,
                        name: true,
                        email: true,
                        role: true,
                        depot: true,
                        infringements: true,
                        password: false,
                        organisation: false,
                    },
                });
                if (!user) {
                    throw new Error('Error');
                }
                const accessToken = (0, generateAccessToken_1.default)(user.id);
                const refreshToken = (0, generateRefreshToken_1.default)(user.id);
                context.res.cookie('refreshToken', refreshToken, {
                    httpOnly: true,
                    secure: true,
                    sameSite: 'strict',
                });
                return {
                    organisation,
                    user,
                    accessToken,
                };
            },
        });
    },
});


/***/ }),

/***/ 20:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.TollTagMutation = exports.TollTagQuery = exports.TollTag = void 0;
const nexus_1 = __webpack_require__(854);
const getUserId_1 = __webpack_require__(412);
const Organisation_1 = __webpack_require__(559);
const Vehicle_1 = __webpack_require__(545);
exports.TollTag = (0, nexus_1.objectType)({
    name: 'TollTag',
    definition(t) {
        t.nonNull.id('id');
        t.nonNull.string('tagNumber');
        t.nonNull.string('tagProvider');
        t.nonNull.field('organisation', {
            type: Organisation_1.Organisation,
            resolve: async (parent, _, context) => {
                const organisation = await context.prisma.tollTag
                    .findUnique({
                    where: { id: parent.id },
                })
                    .organisation();
                if (!organisation) {
                    throw new Error('Organisation not found');
                }
                return organisation;
            },
        });
        t.field('vehicle', {
            type: Vehicle_1.Vehicle,
            resolve(parent, _, context) {
                return context.prisma.tollTag
                    .findUnique({
                    where: { id: parent.id },
                })
                    .vehicle();
            },
        });
    },
});
const TollTagInputFilter = (0, nexus_1.inputObjectType)({
    name: 'TollTagInputFilter',
    definition(t) {
        t.string('searchCriteria');
    },
});
exports.TollTagQuery = (0, nexus_1.extendType)({
    type: 'Query',
    definition(t) {
        t.list.field('tollTags', {
            type: exports.TollTag,
            args: {
                data: (0, nexus_1.arg)({
                    type: TollTagInputFilter,
                }),
            },
            resolve: async (_, args, context) => {
                var _a;
                const userId = (0, getUserId_1.getUserId)(context);
                if (!userId) {
                    throw new Error('Unable to retrieve toll tags. You are not logged in.');
                }
                const organisation = await context.prisma.user
                    .findUnique({
                    where: {
                        id: userId != null ? userId : undefined,
                    },
                })
                    .organisation();
                return context.prisma.tollTag.findMany({
                    where: {
                        AND: [
                            { organisationId: organisation === null || organisation === void 0 ? void 0 : organisation.id },
                            {
                                tagNumber: {
                                    contains: ((_a = args.data) === null || _a === void 0 ? void 0 : _a.searchCriteria) != null
                                        ? args.data.searchCriteria
                                        : undefined,
                                    mode: 'insensitive',
                                },
                            },
                        ],
                    },
                    orderBy: {
                        tagNumber: 'asc',
                    },
                });
            },
        });
        t.list.field('tollTagsNotAssigned', {
            type: exports.TollTag,
            resolve: async (_, __, context) => {
                const userId = (0, getUserId_1.getUserId)(context);
                if (!userId) {
                    throw new Error('Unable to retrieve unassigned toll tags. You are not logged in.');
                }
                const organisation = await context.prisma.user
                    .findUnique({
                    where: {
                        id: userId != null ? userId : undefined,
                    },
                })
                    .organisation();
                return context.prisma.tollTag.findMany({
                    where: {
                        AND: [{ vehicleId: null }, { organisationId: organisation === null || organisation === void 0 ? void 0 : organisation.id }],
                    },
                    orderBy: {
                        tagNumber: 'asc',
                    },
                });
            },
        });
    },
});
const AddTollTagInput = (0, nexus_1.inputObjectType)({
    name: 'AddTollTagInput',
    definition(t) {
        t.nonNull.string('tagNumber');
        t.nonNull.string('tagProvider');
    },
});
const UpdateTollTagInput = (0, nexus_1.inputObjectType)({
    name: 'UpdateTollTagInput',
    definition(t) {
        t.nonNull.id('id');
        t.nonNull.string('tagNumber');
        t.nonNull.string('tagProvider');
    },
});
const DeleteTollTagInput = (0, nexus_1.inputObjectType)({
    name: 'DeleteTollTagInput',
    definition(t) {
        t.nonNull.id('id');
    },
});
exports.TollTagMutation = (0, nexus_1.extendType)({
    type: 'Mutation',
    definition(t) {
        t.nonNull.field('addTollTag', {
            type: exports.TollTag,
            args: {
                data: (0, nexus_1.nonNull)((0, nexus_1.arg)({
                    type: AddTollTagInput,
                })),
            },
            resolve: async (_, args, context) => {
                const userId = (0, getUserId_1.getUserId)(context);
                if (!userId) {
                    throw new Error('Unable to add toll tag. You are not logged in.');
                }
                const organisation = await context.prisma.user
                    .findUnique({
                    where: {
                        id: userId != null ? userId : undefined,
                    },
                })
                    .organisation();
                const existingTag = await context.prisma.tollTag.findUnique({
                    where: {
                        tagNumber: args.data.tagNumber,
                    },
                });
                if (existingTag) {
                    throw new Error('Tag already exists with this number');
                }
                return context.prisma.tollTag.create({
                    data: {
                        tagNumber: args.data.tagNumber,
                        tagProvider: args.data.tagProvider,
                        organisation: {
                            connect: {
                                id: organisation === null || organisation === void 0 ? void 0 : organisation.id,
                            },
                        },
                    },
                });
            },
        });
        t.nonNull.field('updateTollTag', {
            type: exports.TollTag,
            args: {
                data: (0, nexus_1.nonNull)((0, nexus_1.arg)({
                    type: UpdateTollTagInput,
                })),
            },
            resolve: async (_, args, context) => {
                try {
                    return context.prisma.tollTag.update({
                        where: {
                            id: args.data.id,
                        },
                        data: {
                            tagNumber: args.data.tagNumber,
                            tagProvider: args.data.tagProvider,
                        },
                    });
                }
                catch (error) {
                    throw new Error('Error updating toll tag');
                }
            },
        });
        t.nonNull.field('deleteTollTag', {
            type: exports.TollTag,
            args: {
                data: (0, nexus_1.nonNull)((0, nexus_1.arg)({
                    type: DeleteTollTagInput,
                })),
            },
            resolve: (_, args, context) => {
                try {
                    return context.prisma.tollTag.delete({
                        where: {
                            id: args.data.id,
                        },
                    });
                }
                catch (error) {
                    throw new Error('Error deleting toll tag');
                }
            },
        });
    },
});


/***/ }),

/***/ 853:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.UserMutation = exports.UserQuery = exports.RefreshTokenPayload = exports.LogoutPayload = exports.AuthPayload = exports.UsersPayload = exports.User = void 0;
const nexus_1 = __webpack_require__(854);
const bcrypt_1 = __webpack_require__(96);
const Depot_1 = __webpack_require__(842);
const Organisation_1 = __webpack_require__(559);
const getUserId_1 = __webpack_require__(412);
const createConnection_1 = __importDefault(__webpack_require__(115));
const upsertConnection_1 = __importDefault(__webpack_require__(251));
const generateAccessToken_1 = __importDefault(__webpack_require__(49));
const Enum_1 = __webpack_require__(11);
const Infringement_1 = __importDefault(__webpack_require__(546));
const generateRefreshToken_1 = __importDefault(__webpack_require__(972));
const getRefreshUserId_1 = __importDefault(__webpack_require__(170));
exports.User = (0, nexus_1.objectType)({
    name: 'User',
    definition(t) {
        t.nonNull.id('id');
        t.nonNull.string('name');
        t.nonNull.string('email');
        t.nonNull.string('password');
        t.nonNull.field('role', {
            type: Enum_1.Role,
        });
        t.nonNull.field('organisation', {
            type: Organisation_1.Organisation,
            resolve: async (parent, _, context) => {
                const organisation = await context.prisma.user
                    .findUnique({
                    where: { id: parent.id },
                })
                    .organisation();
                if (!organisation) {
                    throw new Error('Organisation not found');
                }
                return organisation;
            },
        });
        t.field('depot', {
            type: Depot_1.Depot,
            resolve(parent, _, context) {
                return context.prisma.user
                    .findUnique({
                    where: { id: parent.id },
                })
                    .depot();
            },
        });
        t.nonNull.list.nonNull.field('infringements', {
            type: Infringement_1.default,
            resolve(parent, _, context) {
                return context.prisma.user
                    .findUnique({
                    where: { id: parent.id },
                })
                    .infringements();
            },
        });
    },
});
exports.UsersPayload = (0, nexus_1.objectType)({
    name: 'UsersPayload',
    definition(t) {
        t.nonNull.string('id');
        t.nonNull.string('name');
        t.nonNull.string('email');
        t.nonNull.field('role', { type: Enum_1.Role });
        t.field('depot', {
            type: Depot_1.Depot,
        });
        t.nonNull.list.nonNull.field('infringements', {
            type: Infringement_1.default,
        });
    },
});
exports.AuthPayload = (0, nexus_1.objectType)({
    name: 'AuthPayload',
    definition(t) {
        t.field('user', {
            type: exports.UsersPayload,
        });
        t.nonNull.string('accessToken');
    },
});
exports.LogoutPayload = (0, nexus_1.objectType)({
    name: 'LogoutPayload',
    definition(t) {
        t.nonNull.string('message');
    },
});
exports.RefreshTokenPayload = (0, nexus_1.objectType)({
    name: 'RefreshTokenPayload',
    definition(t) {
        t.nonNull.string('accessToken');
    },
});
const LoginInput = (0, nexus_1.inputObjectType)({
    name: 'LoginInput',
    definition(t) {
        t.nonNull.string('email');
        t.nonNull.string('password');
    },
});
const UsersInputFilter = (0, nexus_1.inputObjectType)({
    name: 'UsersInputFilter',
    definition(t) {
        t.string('searchCriteria');
    },
});
const AddUserInput = (0, nexus_1.inputObjectType)({
    name: 'AddUserInput',
    definition(t) {
        t.nonNull.string('email');
        t.nonNull.string('password');
        t.nonNull.string('name');
        t.nonNull.string('depotId');
        t.nonNull.field('role', { type: Enum_1.Role });
    },
});
const DeleteUserInput = (0, nexus_1.inputObjectType)({
    name: 'DeleteUserInput',
    definition(t) {
        t.nonNull.id('id');
    },
});
const UpdateUserInput = (0, nexus_1.inputObjectType)({
    name: 'UpdateUserInput',
    definition(t) {
        t.nonNull.id('id');
        t.nonNull.string('email');
        t.nonNull.string('name');
        t.nonNull.string('depotId');
        t.nonNull.field('role', { type: Enum_1.Role });
    },
});
exports.UserQuery = (0, nexus_1.extendType)({
    type: 'Query',
    definition(t) {
        t.field('user', {
            type: exports.UsersPayload,
            args: {
                userId: (0, nexus_1.nonNull)((0, nexus_1.idArg)()),
            },
            resolve: (_, { userId }, context) => {
                try {
                    return context.prisma.user.findUnique({
                        where: {
                            id: userId,
                        },
                        select: {
                            id: true,
                            name: true,
                            email: true,
                            role: true,
                            depot: true,
                            infringements: true,
                            password: false,
                            organisation: false,
                        },
                    });
                }
                catch (_a) {
                    throw new Error('Error retrieving user');
                }
            },
        });
        t.field('me', {
            type: exports.UsersPayload,
            resolve: (_, __, context) => {
                const userId = (0, getUserId_1.getUserId)(context);
                if (!userId) {
                    throw new Error('Unable to retrieve your account info. You are not logged in.');
                }
                return context.prisma.user.findUnique({
                    where: {
                        id: String(userId),
                    },
                    select: {
                        id: true,
                        name: true,
                        email: true,
                        role: true,
                        depot: true,
                        infringements: true,
                        password: false,
                        organisation: false,
                    },
                });
            },
        });
        t.list.field('users', {
            type: exports.UsersPayload,
            args: {
                data: (0, nexus_1.arg)({
                    type: UsersInputFilter,
                }),
            },
            resolve: async (_, args, context) => {
                var _a;
                const userId = (0, getUserId_1.getUserId)(context);
                if (!userId) {
                    throw new Error('Unable to retrieve users. You are not logged in.');
                }
                const organisation = await context.prisma.user
                    .findUnique({
                    where: {
                        id: userId != null ? userId : undefined,
                    },
                })
                    .organisation();
                return context.prisma.user.findMany({
                    where: {
                        AND: [
                            { organisationId: organisation === null || organisation === void 0 ? void 0 : organisation.id },
                            {
                                role: {
                                    not: 'ADMIN',
                                },
                            },
                            {
                                name: {
                                    contains: ((_a = args.data) === null || _a === void 0 ? void 0 : _a.searchCriteria) != null
                                        ? args.data.searchCriteria
                                        : undefined,
                                    mode: 'insensitive',
                                },
                            },
                        ],
                    },
                    select: {
                        id: true,
                        name: true,
                        email: true,
                        role: true,
                        depot: true,
                        infringements: true,
                        password: false,
                        organisation: false,
                    },
                    orderBy: {
                        name: 'asc',
                    },
                });
            },
        });
        t.nonNull.list.nonNull.field('drivers', {
            type: exports.UsersPayload,
            resolve: async (_, __, context) => {
                const userId = (0, getUserId_1.getUserId)(context);
                if (!userId) {
                    throw new Error('Unable to retrieve users. You are not logged in.');
                }
                const organisation = await context.prisma.user
                    .findUnique({
                    where: {
                        id: userId != null ? userId : undefined,
                    },
                })
                    .organisation();
                return context.prisma.user.findMany({
                    where: {
                        AND: [
                            { organisationId: organisation === null || organisation === void 0 ? void 0 : organisation.id },
                            {
                                role: 'DRIVER',
                            },
                        ],
                    },
                    select: {
                        id: true,
                        name: true,
                        email: true,
                        role: true,
                        depot: true,
                        infringements: true,
                        password: false,
                        organisation: false,
                    },
                    orderBy: {
                        name: 'asc',
                    },
                });
            },
        });
    },
});
exports.UserMutation = (0, nexus_1.extendType)({
    type: 'Mutation',
    definition(t) {
        t.nonNull.field('login', {
            type: exports.AuthPayload,
            args: {
                data: (0, nexus_1.nonNull)((0, nexus_1.arg)({
                    type: LoginInput,
                })),
            },
            resolve: async (_, args, context) => {
                const user = await context.prisma.user.findUnique({
                    where: {
                        email: args.data.email,
                    },
                    include: {
                        depot: true,
                        infringements: true,
                    },
                });
                if (!user) {
                    throw new Error('Email or password is incorrect');
                }
                const valid = await (0, bcrypt_1.compare)(args.data.password, user.password);
                if (!valid) {
                    throw new Error('Email or password is incorrect');
                }
                const accessToken = (0, generateAccessToken_1.default)(user.id);
                const refreshToken = (0, generateRefreshToken_1.default)(user.id);
                context.res.cookie('refreshToken', refreshToken, {
                    httpOnly: true,
                    secure: true,
                    sameSite: 'strict',
                });
                return {
                    user: {
                        id: user.id,
                        name: user.name,
                        email: user.email,
                        role: user.role,
                        depot: user.depot,
                        infringements: user.infringements,
                    },
                    accessToken,
                };
            },
        });
        t.nonNull.field('logout', {
            type: exports.LogoutPayload,
            resolve: async (_, __, context) => {
                context.res.cookie('refreshToken', '', {
                    httpOnly: true,
                    secure: true,
                    sameSite: 'strict',
                    expires: new Date(0),
                });
                return {
                    message: 'Logged out successfully',
                };
            },
        });
        t.nonNull.field('refreshToken', {
            type: exports.RefreshTokenPayload,
            resolve: async (_, __, context) => {
                const userId = (0, getRefreshUserId_1.default)(context);
                if (!userId) {
                    throw new Error('User could not be found');
                }
                const accessToken = (0, generateAccessToken_1.default)(userId);
                const refreshToken = (0, generateRefreshToken_1.default)(userId);
                context.res.cookie('refreshToken', refreshToken, {
                    httpOnly: true,
                    secure: true,
                    sameSite: 'strict',
                });
                return {
                    accessToken,
                };
            },
        });
        // t.nonNull.field('register', {
        //   type: AuthPayload,
        //   args: {
        //     data: nonNull(
        //       arg({
        //         type: RegisterInput,
        //       })
        //     ),
        //   },
        //   resolve: async (_, args, context: Context) => {
        //     const existingUser = await context.prisma.user.findUnique({
        //       where: {
        //         email: args.data.email,
        //       },
        //     });
        //     if (existingUser) {
        //       throw new Error('ERROR: Account already exists with this email');
        //     }
        //     const hashedPassword = await hash(args.data.password, 10);
        //     const user = await context.prisma.user.create({
        //       data: {
        //         email: args.data.email,
        //         password: hashedPassword,
        //         name: args.data.name,
        //         role: 'USER',
        //         organisation: {
        //           connect: {
        //             id: args.data.organisationId,
        //           },
        //         },
        //       },
        //     });
        //     if (!user) {
        //       throw new Error('Error');
        //     }
        //     const token = generateToken(user.id);
        //     return {
        //       token,
        //       user,
        //     };
        //   },
        // });
        t.nonNull.field('addUser', {
            type: exports.UsersPayload,
            args: {
                data: (0, nexus_1.nonNull)((0, nexus_1.arg)({
                    type: AddUserInput,
                })),
            },
            resolve: async (_, args, context) => {
                const userId = (0, getUserId_1.getUserId)(context);
                const organisation = await context.prisma.user
                    .findUnique({
                    where: {
                        id: userId != null ? userId : undefined,
                    },
                })
                    .organisation();
                const existingUser = await context.prisma.user.findUnique({
                    where: {
                        email: args.data.email,
                    },
                });
                if (existingUser) {
                    throw new Error('Account already exists with this email');
                }
                const hashedPassword = await (0, bcrypt_1.hash)(args.data.password, 10);
                const user = await context.prisma.user.create({
                    data: {
                        email: args.data.email,
                        password: hashedPassword,
                        name: args.data.name,
                        role: args.data.role,
                        ...(0, createConnection_1.default)('depot', args.data.depotId),
                        organisation: {
                            connect: {
                                id: organisation === null || organisation === void 0 ? void 0 : organisation.id,
                            },
                        },
                    },
                    include: {
                        depot: true,
                        infringements: true,
                    },
                });
                return {
                    id: user.id,
                    name: user.name,
                    email: user.email,
                    role: user.role,
                    depot: user.depot,
                    infringements: user.infringements,
                };
            },
        });
        t.nonNull.field('deleteUser', {
            type: exports.User,
            args: {
                data: (0, nexus_1.nonNull)((0, nexus_1.arg)({
                    type: DeleteUserInput,
                })),
            },
            resolve: (_, args, context) => {
                try {
                    return context.prisma.user.delete({
                        where: {
                            id: args.data.id,
                        },
                    });
                }
                catch (error) {
                    throw new Error('Error deleting user');
                }
            },
        });
        t.nonNull.field('updateUser', {
            type: exports.UsersPayload,
            args: {
                data: (0, nexus_1.nonNull)((0, nexus_1.arg)({
                    type: UpdateUserInput,
                })),
            },
            resolve: async (_, args, context) => {
                var _a;
                try {
                    const oldUser = await context.prisma.user.findUnique({
                        where: {
                            id: args.data.id,
                        },
                        include: {
                            depot: {
                                select: {
                                    id: true,
                                },
                            },
                        },
                    });
                    const user = await context.prisma.user.update({
                        where: {
                            id: args.data.id,
                        },
                        data: {
                            name: args.data.name,
                            email: args.data.email,
                            role: args.data.role,
                            ...(0, upsertConnection_1.default)('depot', (_a = oldUser === null || oldUser === void 0 ? void 0 : oldUser.depot) === null || _a === void 0 ? void 0 : _a.id, args.data.depotId),
                        },
                        include: {
                            depot: true,
                            infringements: true,
                        },
                    });
                    return {
                        id: user.id,
                        name: user.name,
                        email: user.email,
                        role: user.role,
                        depot: user.depot,
                        infringements: user.infringements,
                    };
                }
                catch (error) {
                    throw new Error('Error updating user');
                }
            },
        });
    },
});


/***/ }),

/***/ 545:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.VehicleMutation = exports.VehicleQuery = exports.Vehicle = void 0;
const nexus_1 = __webpack_require__(854);
const createConnection_1 = __importDefault(__webpack_require__(115));
const getDateTwoWeeks_1 = __importDefault(__webpack_require__(919));
const getUserId_1 = __webpack_require__(412);
const upsertConnection_1 = __importDefault(__webpack_require__(251));
const Organisation_1 = __webpack_require__(559);
const Defect_1 = __webpack_require__(244);
const Depot_1 = __webpack_require__(842);
const Enum_1 = __webpack_require__(11);
const FuelCard_1 = __webpack_require__(847);
const TollTag_1 = __webpack_require__(20);
exports.Vehicle = (0, nexus_1.objectType)({
    name: 'Vehicle',
    definition(t) {
        t.nonNull.id('id');
        t.nonNull.field('type', {
            type: Enum_1.VehicleType,
        });
        t.nonNull.string('registration');
        t.nonNull.string('make');
        t.nonNull.string('model');
        t.nonNull.string('owner');
        t.date('cvrt');
        t.date('thirteenWeekInspection');
        t.date('tachoCalibration');
        t.nonNull.field('organisation', {
            type: Organisation_1.Organisation,
            resolve: async (parent, _, context) => {
                const organisation = await context.prisma.vehicle
                    .findUnique({
                    where: { id: parent.id },
                })
                    .organisation();
                if (!organisation) {
                    throw new Error('Organisation not found');
                }
                return organisation;
            },
        });
        t.field('depot', {
            type: Depot_1.Depot,
            resolve(parent, _, context) {
                return context.prisma.vehicle
                    .findUnique({
                    where: { id: parent.id },
                })
                    .depot();
            },
        });
        t.nonNull.list.nonNull.field('defects', {
            type: Defect_1.Defect,
            resolve(parent, _, context) {
                return context.prisma.vehicle
                    .findUnique({
                    where: { id: parent.id },
                })
                    .defects();
            },
        });
        t.field('fuelCard', {
            type: FuelCard_1.FuelCard,
            resolve(parent, _, context) {
                return context.prisma.vehicle
                    .findUnique({
                    where: { id: parent.id },
                })
                    .fuelCard();
            },
        });
        t.field('tollTag', {
            type: TollTag_1.TollTag,
            resolve(parent, _, context) {
                return context.prisma.vehicle
                    .findUnique({
                    where: { id: parent.id },
                })
                    .tollTag();
            },
        });
    },
});
const VehicleInputFilter = (0, nexus_1.inputObjectType)({
    name: 'VehicleInputFilter',
    definition(t) {
        t.string('searchCriteria');
    },
});
exports.VehicleQuery = (0, nexus_1.extendType)({
    type: 'Query',
    definition(t) {
        t.field('vehicle', {
            type: exports.Vehicle,
            args: {
                vehicleId: (0, nexus_1.nonNull)((0, nexus_1.idArg)()),
            },
            resolve: (_, { vehicleId }, context) => {
                try {
                    return context.prisma.vehicle.findUnique({
                        where: {
                            id: vehicleId,
                        },
                    });
                }
                catch (error) {
                    throw new Error('Error retrieving vehicle');
                }
            },
        });
        t.list.field('vehicles', {
            type: exports.Vehicle,
            args: {
                data: (0, nexus_1.arg)({
                    type: VehicleInputFilter,
                }),
            },
            resolve: async (_, args, context) => {
                var _a;
                const userId = (0, getUserId_1.getUserId)(context);
                if (!userId) {
                    throw new Error('Unable to retrieve vehicles. You are not logged in.');
                }
                const organisation = await context.prisma.user
                    .findUnique({
                    where: {
                        id: userId != null ? userId : undefined,
                    },
                })
                    .organisation();
                return context.prisma.vehicle.findMany({
                    where: {
                        AND: [
                            { organisationId: organisation === null || organisation === void 0 ? void 0 : organisation.id },
                            {
                                registration: {
                                    contains: ((_a = args.data) === null || _a === void 0 ? void 0 : _a.searchCriteria) != null
                                        ? args.data.searchCriteria
                                        : undefined,
                                    mode: 'insensitive',
                                },
                            },
                        ],
                    },
                    orderBy: {
                        registration: 'asc',
                    },
                });
            },
        });
        t.list.field('defectsForVehicle', {
            type: Defect_1.Defect,
            args: {
                vehicleId: (0, nexus_1.nonNull)((0, nexus_1.idArg)()),
            },
            resolve: (_, { vehicleId }, context) => {
                try {
                    return context.prisma.vehicle
                        .findUnique({
                        where: {
                            id: vehicleId,
                        },
                    })
                        .defects();
                }
                catch (error) {
                    throw new Error('There was an error retrieving defects for vehicle');
                }
            },
        });
        t.list.field('upcomingCVRT', {
            type: exports.Vehicle,
            resolve: async (_, __, context) => {
                const userId = (0, getUserId_1.getUserId)(context);
                if (!userId) {
                    throw new Error('Unable to retrieve vehicles with upcoming CVRTs. You are not logged in.');
                }
                const organisation = await context.prisma.user
                    .findUnique({
                    where: {
                        id: userId != null ? userId : undefined,
                    },
                })
                    .organisation();
                return context.prisma.vehicle.findMany({
                    where: {
                        AND: [
                            { organisationId: organisation === null || organisation === void 0 ? void 0 : organisation.id },
                            {
                                cvrt: {
                                    lte: (0, getDateTwoWeeks_1.default)(),
                                },
                            },
                        ],
                    },
                    orderBy: {
                        cvrt: 'asc',
                    },
                });
            },
        });
        t.list.field('upcomingThirteenWeek', {
            type: exports.Vehicle,
            resolve: async (_, __, context) => {
                const userId = (0, getUserId_1.getUserId)(context);
                if (!userId) {
                    throw new Error('Unable to retrieve vehicles with upcoming thirteen weeks. You are not logged in.');
                }
                const organisation = await context.prisma.user
                    .findUnique({
                    where: {
                        id: userId != null ? userId : undefined,
                    },
                })
                    .organisation();
                return context.prisma.vehicle.findMany({
                    where: {
                        AND: [
                            { organisationId: organisation === null || organisation === void 0 ? void 0 : organisation.id },
                            {
                                thirteenWeekInspection: {
                                    lte: (0, getDateTwoWeeks_1.default)(),
                                },
                            },
                        ],
                    },
                    orderBy: {
                        thirteenWeekInspection: 'asc',
                    },
                });
            },
        });
        t.list.field('upcomingTachoCalibration', {
            type: exports.Vehicle,
            resolve: async (_, __, context) => {
                const userId = (0, getUserId_1.getUserId)(context);
                if (!userId) {
                    throw new Error('Unable to retrieve vehicles with upcoming tacho calibration. You are not logged in.');
                }
                const organisation = await context.prisma.user
                    .findUnique({
                    where: {
                        id: userId != null ? userId : undefined,
                    },
                })
                    .organisation();
                return context.prisma.vehicle.findMany({
                    where: {
                        AND: [
                            { organisationId: organisation === null || organisation === void 0 ? void 0 : organisation.id },
                            {
                                tachoCalibration: {
                                    lte: (0, getDateTwoWeeks_1.default)(),
                                },
                            },
                        ],
                    },
                    orderBy: {
                        tachoCalibration: 'asc',
                    },
                });
            },
        });
    },
});
const AddVehicleInput = (0, nexus_1.inputObjectType)({
    name: 'AddVehicleInput',
    definition(t) {
        t.nonNull.field('type', { type: Enum_1.VehicleType });
        t.nonNull.string('registration');
        t.nonNull.string('make');
        t.nonNull.string('model');
        t.nonNull.string('owner');
        t.date('cvrt');
        t.date('thirteenWeekInspection');
        t.date('tachoCalibration');
        t.string('depotId');
        t.string('fuelCardId');
        t.string('tollTagId');
    },
});
const UpdateVehicleInput = (0, nexus_1.inputObjectType)({
    name: 'UpdateVehicleInput',
    definition(t) {
        t.nonNull.string('id');
        t.nonNull.field('type', { type: Enum_1.VehicleType });
        t.nonNull.string('registration');
        t.nonNull.string('make');
        t.nonNull.string('model');
        t.nonNull.string('owner');
        t.date('cvrt');
        t.date('thirteenWeekInspection');
        t.date('tachoCalibration');
        t.string('depotId');
        t.string('fuelCardId');
        t.string('tollTagId');
    },
});
const DeleteVehicleInput = (0, nexus_1.inputObjectType)({
    name: 'DeleteVehicleInput',
    definition(t) {
        t.nonNull.id('id');
    },
});
const UpdateVehicleDates = (0, nexus_1.inputObjectType)({
    name: 'UpdateVehicleDates',
    definition(t) {
        t.nonNull.string('id');
    },
});
const UpdateVehicleDatesWithCompletion = (0, nexus_1.inputObjectType)({
    name: 'UpdateVehicleDatesWithCompletion',
    definition(t) {
        t.nonNull.string('id');
        t.nonNull.date('completionDate');
    },
});
exports.VehicleMutation = (0, nexus_1.extendType)({
    type: 'Mutation',
    definition(t) {
        t.nonNull.field('addVehicle', {
            type: exports.Vehicle,
            args: {
                data: (0, nexus_1.nonNull)((0, nexus_1.arg)({
                    type: AddVehicleInput,
                })),
            },
            resolve: async (_, args, context) => {
                const userId = (0, getUserId_1.getUserId)(context);
                if (!userId) {
                    throw new Error('Unable to add vehicle. You are not logged in.');
                }
                const organisation = await context.prisma.user
                    .findUnique({
                    where: {
                        id: userId != null ? userId : undefined,
                    },
                })
                    .organisation();
                const existingVehicle = await context.prisma.vehicle.findUnique({
                    where: {
                        registration: args.data.registration,
                    },
                });
                if (existingVehicle) {
                    throw new Error('Vehicle already exists with this registration');
                }
                return context.prisma.vehicle.create({
                    data: {
                        type: args.data.type,
                        registration: args.data.registration,
                        make: args.data.make,
                        model: args.data.model,
                        owner: args.data.owner,
                        organisation: {
                            connect: {
                                id: organisation === null || organisation === void 0 ? void 0 : organisation.id,
                            },
                        },
                        cvrt: args.data.cvrt,
                        thirteenWeekInspection: args.data.thirteenWeekInspection,
                        tachoCalibration: args.data.tachoCalibration,
                        ...(0, createConnection_1.default)('depot', args.data.depotId),
                        ...(0, createConnection_1.default)('fuelCard', args.data.fuelCardId),
                        ...(0, createConnection_1.default)('tollTag', args.data.tollTagId),
                    },
                });
            },
        });
        t.nonNull.field('deleteVehicle', {
            type: exports.Vehicle,
            args: {
                data: (0, nexus_1.nonNull)((0, nexus_1.arg)({
                    type: DeleteVehicleInput,
                })),
            },
            resolve: (_, args, context) => {
                try {
                    return context.prisma.vehicle.delete({
                        where: {
                            id: args.data.id,
                        },
                    });
                }
                catch (error) {
                    throw new Error('Error deleting vehicle');
                }
            },
        });
        t.nonNull.field('updateVehicle', {
            type: exports.Vehicle,
            args: {
                data: (0, nexus_1.nonNull)((0, nexus_1.arg)({
                    type: UpdateVehicleInput,
                })),
            },
            resolve: async (_, args, context) => {
                var _a, _b, _c;
                try {
                    const oldVehicle = await context.prisma.vehicle.findUnique({
                        where: {
                            id: args.data.id,
                        },
                        include: {
                            fuelCard: {
                                select: {
                                    id: true,
                                },
                            },
                            tollTag: {
                                select: {
                                    id: true,
                                },
                            },
                            depot: {
                                select: {
                                    id: true,
                                },
                            },
                        },
                    });
                    const vehicle = context.prisma.vehicle.update({
                        where: {
                            id: args.data.id,
                        },
                        data: {
                            type: args.data.type,
                            registration: args.data.registration,
                            make: args.data.make,
                            model: args.data.model,
                            owner: args.data.owner,
                            cvrt: args.data.cvrt,
                            thirteenWeekInspection: args.data.thirteenWeekInspection,
                            tachoCalibration: args.data.tachoCalibration,
                            ...(0, upsertConnection_1.default)('depot', (_a = oldVehicle === null || oldVehicle === void 0 ? void 0 : oldVehicle.depot) === null || _a === void 0 ? void 0 : _a.id, args.data.depotId),
                            ...(0, upsertConnection_1.default)('fuelCard', (_b = oldVehicle === null || oldVehicle === void 0 ? void 0 : oldVehicle.fuelCard) === null || _b === void 0 ? void 0 : _b.id, args.data.fuelCardId),
                            ...(0, upsertConnection_1.default)('tollTag', (_c = oldVehicle === null || oldVehicle === void 0 ? void 0 : oldVehicle.tollTag) === null || _c === void 0 ? void 0 : _c.id, args.data.tollTagId),
                        },
                    });
                    return vehicle;
                }
                catch (_d) {
                    throw new Error('Error updating vehicle');
                }
            },
        });
        t.nonNull.field('updateVehicleCVRT', {
            type: exports.Vehicle,
            args: {
                data: (0, nexus_1.nonNull)((0, nexus_1.arg)({
                    type: UpdateVehicleDates,
                })),
            },
            resolve: async (_, args, context) => {
                const vehicle = await context.prisma.vehicle.findUnique({
                    where: {
                        id: args.data.id,
                    },
                });
                if (!vehicle) {
                    throw new Error('This vehicle does not exist.');
                }
                if (!vehicle.cvrt) {
                    throw new Error('This vehicle does not have a cvrt due date set.');
                }
                const year = vehicle.cvrt.getFullYear();
                const month = vehicle.cvrt.getMonth();
                const day = vehicle.cvrt.getDate();
                const nextCVRT = new Date(year + 1, month, day);
                const updatedVehicle = await context.prisma.vehicle.update({
                    where: {
                        id: args.data.id,
                    },
                    data: {
                        cvrt: nextCVRT,
                    },
                });
                return updatedVehicle;
            },
        });
        t.nonNull.field('updateVehicleThirteenWeekInspection', {
            type: exports.Vehicle,
            args: {
                data: (0, nexus_1.nonNull)((0, nexus_1.arg)({
                    type: UpdateVehicleDatesWithCompletion,
                })),
            },
            resolve: async (_, args, context) => {
                const vehicle = await context.prisma.vehicle.findUnique({
                    where: {
                        id: args.data.id,
                    },
                });
                if (!vehicle) {
                    throw new Error('This vehicle does not exist.');
                }
                if (!vehicle.thirteenWeekInspection) {
                    throw new Error('This vehicle does not have a thirteen week inspection due date set.');
                }
                const weeksToAdd = 13;
                const completionDate = new Date(args.data.completionDate);
                const nextThirteenWeekInspection = new Date(completionDate.setDate(completionDate.getDate() + weeksToAdd * 7));
                const updatedVehicle = await context.prisma.vehicle.update({
                    where: {
                        id: args.data.id,
                    },
                    data: {
                        thirteenWeekInspection: nextThirteenWeekInspection,
                    },
                });
                return updatedVehicle;
            },
        });
        t.nonNull.field('updateVehicleTachoCalibration', {
            type: exports.Vehicle,
            args: {
                data: (0, nexus_1.nonNull)((0, nexus_1.arg)({
                    type: UpdateVehicleDatesWithCompletion,
                })),
            },
            resolve: async (_, args, context) => {
                const vehicle = await context.prisma.vehicle.findUnique({
                    where: {
                        id: args.data.id,
                    },
                });
                if (!vehicle) {
                    throw new Error('This vehicle does not exist.');
                }
                if (!vehicle.tachoCalibration) {
                    throw new Error('This vehicle does not have a thirteen week inspection due date set.');
                }
                const yearsToAdd = 2;
                const completionDate = new Date(args.data.completionDate);
                const nextTachoCalibration = new Date(completionDate.setFullYear(completionDate.getFullYear() + yearsToAdd));
                const updatedVehicle = await context.prisma.vehicle.update({
                    where: {
                        id: args.data.id,
                    },
                    data: {
                        tachoCalibration: nextTachoCalibration,
                    },
                });
                return updatedVehicle;
            },
        });
    },
});


/***/ }),

/***/ 728:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.REFRESH_TOKEN_SECRET = exports.ACCESS_TOKEN_SECRET = void 0;
const express_1 = __importDefault(__webpack_require__(860));
const cookie_parser_1 = __importDefault(__webpack_require__(710));
const cors_1 = __importDefault(__webpack_require__(582));
const apollo_server_lambda_1 = __webpack_require__(270);
const schema_1 = __importDefault(__webpack_require__(734));
const context_1 = __webpack_require__(523);
exports.ACCESS_TOKEN_SECRET = 'xudvholxjekszefvsuvosuegv';
exports.REFRESH_TOKEN_SECRET = 'akjwdhliuawdlUWladuhawud';
// const corsOptions = {
//   origin: 'http://localhost:3000',
//   credentials: true,
// };
// const app = express();
// app.use(cookieParser());
// app.use(cors());
// const httpServer = http.createServer(app);
const server = new apollo_server_lambda_1.ApolloServer({
    schema: schema_1.default,
    context: context_1.context,
    // plugins: [ApolloServerPluginDrainHttpServer({ httpServer })],
});
// server.applyMiddleware({
//   app,
//   path: '/',
//   cors: false,
// });
// await new Promise<void>((resolve) =>
//   httpServer.listen({ port: 4000 }, resolve)
// );
exports.graphqlHandler = server.createHandler({
    expressAppFromMiddleware() {
        const app = (0, express_1.default)();
        app.use((0, cookie_parser_1.default)());
        app.use((0, cors_1.default)());
        return app;
    },
});
console.log(`
    🚀  Server is running!
    🔉  Listening on port 4000
    📭  Query at https://studio.apollographql.com/dev
  `);


/***/ }),

/***/ 115:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
function createConnection(name, value) {
    const shouldModify = value !== null;
    return (shouldModify &&
        {
            [name]: value ? { connect: { id: value } } : undefined,
        });
}
exports["default"] = createConnection;


/***/ }),

/***/ 49:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
const jsonwebtoken_1 = __webpack_require__(344);
const server_1 = __webpack_require__(728);
const generateAccessToken = (userId) => {
    const token = (0, jsonwebtoken_1.sign)({
        userId,
    }, server_1.ACCESS_TOKEN_SECRET, {
        expiresIn: '15m',
    });
    return token;
};
exports["default"] = generateAccessToken;


/***/ }),

/***/ 972:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
const jsonwebtoken_1 = __webpack_require__(344);
const server_1 = __webpack_require__(728);
const generateRefreshToken = (userId) => {
    const token = (0, jsonwebtoken_1.sign)({
        userId,
    }, server_1.REFRESH_TOKEN_SECRET, {
        expiresIn: '30d',
    });
    return token;
};
exports["default"] = generateRefreshToken;


/***/ }),

/***/ 919:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getDateTwoWeeks = void 0;
const getDateTwoWeeks = () => {
    const weeks = 2;
    const date = new Date();
    date.setDate(date.getDate() + weeks * 7);
    return date;
};
exports.getDateTwoWeeks = getDateTwoWeeks;
exports["default"] = exports.getDateTwoWeeks;


/***/ }),

/***/ 170:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getRefreshUserId = void 0;
const jsonwebtoken_1 = __webpack_require__(344);
const server_1 = __webpack_require__(728);
const getRefreshUserId = (context) => {
    const { refreshToken } = context.req.cookies;
    if (refreshToken) {
        const token = refreshToken.replace('Bearer ', '');
        const verifiedToken = (0, jsonwebtoken_1.verify)(token, server_1.REFRESH_TOKEN_SECRET);
        return verifiedToken && verifiedToken.userId;
    }
    return null;
};
exports.getRefreshUserId = getRefreshUserId;
exports["default"] = exports.getRefreshUserId;


/***/ }),

/***/ 412:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getUserId = void 0;
const jsonwebtoken_1 = __webpack_require__(344);
const server_1 = __webpack_require__(728);
const getUserId = (context) => {
    const authHeader = context.req.get('Authorization');
    if (authHeader) {
        const token = authHeader.replace('Bearer ', '');
        const verifiedToken = (0, jsonwebtoken_1.verify)(token, server_1.ACCESS_TOKEN_SECRET);
        return verifiedToken && verifiedToken.userId;
    }
    return null;
};
exports.getUserId = getUserId;
exports["default"] = exports.getUserId;


/***/ }),

/***/ 251:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
function upsertConnection(name, oldValue, newValue) {
    // we need to mutate if we're changing the value or if going from set -> unset or unset -> set
    // NOTE: coerce to boolean because db is null and args are undefined
    const shouldModify = oldValue !== newValue || !!oldValue !== !!newValue;
    return (shouldModify &&
        {
            [name]: newValue ? { connect: { id: newValue } } : { disconnect: true },
        });
}
exports["default"] = upsertConnection;


/***/ }),

/***/ 524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 270:
/***/ ((module) => {

module.exports = require("apollo-server-lambda");

/***/ }),

/***/ 96:
/***/ ((module) => {

module.exports = require("bcrypt");

/***/ }),

/***/ 710:
/***/ ((module) => {

module.exports = require("cookie-parser");

/***/ }),

/***/ 582:
/***/ ((module) => {

module.exports = require("cors");

/***/ }),

/***/ 860:
/***/ ((module) => {

module.exports = require("express");

/***/ }),

/***/ 290:
/***/ ((module) => {

module.exports = require("graphql-middleware");

/***/ }),

/***/ 189:
/***/ ((module) => {

module.exports = require("graphql-scalars");

/***/ }),

/***/ 973:
/***/ ((module) => {

module.exports = require("graphql-shield");

/***/ }),

/***/ 344:
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ 854:
/***/ ((module) => {

module.exports = require("nexus");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__(728);
/******/ 	var __webpack_export_target__ = exports;
/******/ 	for(var i in __webpack_exports__) __webpack_export_target__[i] = __webpack_exports__[i];
/******/ 	if(__webpack_exports__.__esModule) Object.defineProperty(__webpack_export_target__, "__esModule", { value: true });
/******/ 	
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3JjL3NlcnZlci5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7O0FDWkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7O0FDbkRBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7O0FDdEVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7QUN4SkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7OztBQ2hPQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7OztBQ2xDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7OztBQy9OQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7OztBQ3BNQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7O0FDeFBBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7O0FDL05BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7OztBQ3poQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7OztBQ3ZpQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7OztBQy9DQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7QUNUQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7QUNaQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7QUNaQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7OztBQ1ZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7OztBQ2ZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7OztBQ2ZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7QUNYQTs7Ozs7OztBQ0FBOzs7Ozs7O0FDQUE7Ozs7Ozs7QUNBQTs7Ozs7OztBQ0FBOzs7Ozs7O0FDQUE7Ozs7Ozs7QUNBQTs7Ozs7OztBQ0FBOzs7Ozs7O0FDQUE7Ozs7Ozs7QUNBQTs7Ozs7OztBQ0FBOzs7Ozs7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBRXZCQTtBQUNBO0FBQ0E7QUFDQSIsInNvdXJjZXMiOlsid2VicGFjazovL2ZsZWV0LW1hbmFnZW1lbnQtYmFja2VuZC8uL3NyYy9jb250ZXh0LnRzIiwid2VicGFjazovL2ZsZWV0LW1hbmFnZW1lbnQtYmFja2VuZC8uL3NyYy9wZXJtaXNzaW9ucy50cyIsIndlYnBhY2s6Ly9mbGVldC1tYW5hZ2VtZW50LWJhY2tlbmQvLi9zcmMvc2NoZW1hLnRzIiwid2VicGFjazovL2ZsZWV0LW1hbmFnZW1lbnQtYmFja2VuZC8uL3NyYy9zY2hlbWEvRGVmZWN0LnRzIiwid2VicGFjazovL2ZsZWV0LW1hbmFnZW1lbnQtYmFja2VuZC8uL3NyYy9zY2hlbWEvRGVwb3QudHMiLCJ3ZWJwYWNrOi8vZmxlZXQtbWFuYWdlbWVudC1iYWNrZW5kLy4vc3JjL3NjaGVtYS9FbnVtLnRzIiwid2VicGFjazovL2ZsZWV0LW1hbmFnZW1lbnQtYmFja2VuZC8uL3NyYy9zY2hlbWEvRnVlbENhcmQudHMiLCJ3ZWJwYWNrOi8vZmxlZXQtbWFuYWdlbWVudC1iYWNrZW5kLy4vc3JjL3NjaGVtYS9JbmZyaW5nZW1lbnQudHMiLCJ3ZWJwYWNrOi8vZmxlZXQtbWFuYWdlbWVudC1iYWNrZW5kLy4vc3JjL3NjaGVtYS9PcmdhbmlzYXRpb24udHMiLCJ3ZWJwYWNrOi8vZmxlZXQtbWFuYWdlbWVudC1iYWNrZW5kLy4vc3JjL3NjaGVtYS9Ub2xsVGFnLnRzIiwid2VicGFjazovL2ZsZWV0LW1hbmFnZW1lbnQtYmFja2VuZC8uL3NyYy9zY2hlbWEvVXNlci50cyIsIndlYnBhY2s6Ly9mbGVldC1tYW5hZ2VtZW50LWJhY2tlbmQvLi9zcmMvc2NoZW1hL1ZlaGljbGUudHMiLCJ3ZWJwYWNrOi8vZmxlZXQtbWFuYWdlbWVudC1iYWNrZW5kLy4vc3JjL3NlcnZlci50cyIsIndlYnBhY2s6Ly9mbGVldC1tYW5hZ2VtZW50LWJhY2tlbmQvLi9zcmMvdXRpbGl0aWVzL2NyZWF0ZUNvbm5lY3Rpb24udHMiLCJ3ZWJwYWNrOi8vZmxlZXQtbWFuYWdlbWVudC1iYWNrZW5kLy4vc3JjL3V0aWxpdGllcy9nZW5lcmF0ZUFjY2Vzc1Rva2VuLnRzIiwid2VicGFjazovL2ZsZWV0LW1hbmFnZW1lbnQtYmFja2VuZC8uL3NyYy91dGlsaXRpZXMvZ2VuZXJhdGVSZWZyZXNoVG9rZW4udHMiLCJ3ZWJwYWNrOi8vZmxlZXQtbWFuYWdlbWVudC1iYWNrZW5kLy4vc3JjL3V0aWxpdGllcy9nZXREYXRlVHdvV2Vla3MudHMiLCJ3ZWJwYWNrOi8vZmxlZXQtbWFuYWdlbWVudC1iYWNrZW5kLy4vc3JjL3V0aWxpdGllcy9nZXRSZWZyZXNoVXNlcklkLnRzIiwid2VicGFjazovL2ZsZWV0LW1hbmFnZW1lbnQtYmFja2VuZC8uL3NyYy91dGlsaXRpZXMvZ2V0VXNlcklkLnRzIiwid2VicGFjazovL2ZsZWV0LW1hbmFnZW1lbnQtYmFja2VuZC8uL3NyYy91dGlsaXRpZXMvdXBzZXJ0Q29ubmVjdGlvbi50cyIsIndlYnBhY2s6Ly9mbGVldC1tYW5hZ2VtZW50LWJhY2tlbmQvZXh0ZXJuYWwgY29tbW9uanMgXCJAcHJpc21hL2NsaWVudFwiIiwid2VicGFjazovL2ZsZWV0LW1hbmFnZW1lbnQtYmFja2VuZC9leHRlcm5hbCBjb21tb25qcyBcImFwb2xsby1zZXJ2ZXItbGFtYmRhXCIiLCJ3ZWJwYWNrOi8vZmxlZXQtbWFuYWdlbWVudC1iYWNrZW5kL2V4dGVybmFsIGNvbW1vbmpzIFwiYmNyeXB0XCIiLCJ3ZWJwYWNrOi8vZmxlZXQtbWFuYWdlbWVudC1iYWNrZW5kL2V4dGVybmFsIGNvbW1vbmpzIFwiY29va2llLXBhcnNlclwiIiwid2VicGFjazovL2ZsZWV0LW1hbmFnZW1lbnQtYmFja2VuZC9leHRlcm5hbCBjb21tb25qcyBcImNvcnNcIiIsIndlYnBhY2s6Ly9mbGVldC1tYW5hZ2VtZW50LWJhY2tlbmQvZXh0ZXJuYWwgY29tbW9uanMgXCJleHByZXNzXCIiLCJ3ZWJwYWNrOi8vZmxlZXQtbWFuYWdlbWVudC1iYWNrZW5kL2V4dGVybmFsIGNvbW1vbmpzIFwiZ3JhcGhxbC1taWRkbGV3YXJlXCIiLCJ3ZWJwYWNrOi8vZmxlZXQtbWFuYWdlbWVudC1iYWNrZW5kL2V4dGVybmFsIGNvbW1vbmpzIFwiZ3JhcGhxbC1zY2FsYXJzXCIiLCJ3ZWJwYWNrOi8vZmxlZXQtbWFuYWdlbWVudC1iYWNrZW5kL2V4dGVybmFsIGNvbW1vbmpzIFwiZ3JhcGhxbC1zaGllbGRcIiIsIndlYnBhY2s6Ly9mbGVldC1tYW5hZ2VtZW50LWJhY2tlbmQvZXh0ZXJuYWwgY29tbW9uanMgXCJqc29ud2VidG9rZW5cIiIsIndlYnBhY2s6Ly9mbGVldC1tYW5hZ2VtZW50LWJhY2tlbmQvZXh0ZXJuYWwgY29tbW9uanMgXCJuZXh1c1wiIiwid2VicGFjazovL2ZsZWV0LW1hbmFnZW1lbnQtYmFja2VuZC93ZWJwYWNrL2Jvb3RzdHJhcCIsIndlYnBhY2s6Ly9mbGVldC1tYW5hZ2VtZW50LWJhY2tlbmQvd2VicGFjay9iZWZvcmUtc3RhcnR1cCIsIndlYnBhY2s6Ly9mbGVldC1tYW5hZ2VtZW50LWJhY2tlbmQvd2VicGFjay9zdGFydHVwIiwid2VicGFjazovL2ZsZWV0LW1hbmFnZW1lbnQtYmFja2VuZC93ZWJwYWNrL2FmdGVyLXN0YXJ0dXAiXSwic291cmNlc0NvbnRlbnQiOlsiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG5leHBvcnRzLmNvbnRleHQgPSB2b2lkIDA7XG5jb25zdCBjbGllbnRfMSA9IHJlcXVpcmUoXCJAcHJpc21hL2NsaWVudFwiKTtcbmNvbnN0IHByaXNtYSA9IG5ldyBjbGllbnRfMS5QcmlzbWFDbGllbnQoKTtcbmZ1bmN0aW9uIGNvbnRleHQocmVxLCByZXNwb25zZSkge1xuICAgIHJldHVybiB7XG4gICAgICAgIC4uLnJlcSxcbiAgICAgICAgLi4ucmVzcG9uc2UsXG4gICAgICAgIHByaXNtYSxcbiAgICB9O1xufVxuZXhwb3J0cy5jb250ZXh0ID0gY29udGV4dDtcbiIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuY29uc3QgZ3JhcGhxbF9zaGllbGRfMSA9IHJlcXVpcmUoXCJncmFwaHFsLXNoaWVsZFwiKTtcbmNvbnN0IGdldFVzZXJJZF8xID0gcmVxdWlyZShcIi4vdXRpbGl0aWVzL2dldFVzZXJJZFwiKTtcbmNvbnN0IHJ1bGVzID0ge1xuICAgIGlzQXV0aGVudGljYXRlZFVzZXI6ICgwLCBncmFwaHFsX3NoaWVsZF8xLnJ1bGUpKCkoKF8sIF9fLCBjb250ZXh0KSA9PiB7XG4gICAgICAgIGNvbnN0IHVzZXJJZCA9ICgwLCBnZXRVc2VySWRfMS5nZXRVc2VySWQpKGNvbnRleHQpO1xuICAgICAgICByZXR1cm4gQm9vbGVhbih1c2VySWQpO1xuICAgIH0pLFxuICAgIGlzQWRtaW46ICgwLCBncmFwaHFsX3NoaWVsZF8xLnJ1bGUpKCkoYXN5bmMgKF8sIF9fLCBjb250ZXh0KSA9PiB7XG4gICAgICAgIGNvbnN0IHVzZXJJZCA9ICgwLCBnZXRVc2VySWRfMS5nZXRVc2VySWQpKGNvbnRleHQpO1xuICAgICAgICBjb25zdCB1c2VyID0gYXdhaXQgY29udGV4dC5wcmlzbWEudXNlci5maW5kVW5pcXVlKHtcbiAgICAgICAgICAgIHdoZXJlOiB7XG4gICAgICAgICAgICAgICAgaWQ6IFN0cmluZyh1c2VySWQpLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiAodXNlciA9PT0gbnVsbCB8fCB1c2VyID09PSB2b2lkIDAgPyB2b2lkIDAgOiB1c2VyLnJvbGUpID09PSAnQURNSU4nO1xuICAgIH0pLFxufTtcbmNvbnN0IHBlcm1pc3Npb25zID0gKDAsIGdyYXBocWxfc2hpZWxkXzEuc2hpZWxkKSh7XG4gICAgUXVlcnk6IHtcbiAgICAgICAgdmVoaWNsZTogcnVsZXMuaXNBdXRoZW50aWNhdGVkVXNlcixcbiAgICAgICAgdmVoaWNsZXM6IHJ1bGVzLmlzQXV0aGVudGljYXRlZFVzZXIsXG4gICAgICAgIGRlZmVjdHNGb3JWZWhpY2xlOiBydWxlcy5pc0F1dGhlbnRpY2F0ZWRVc2VyLFxuICAgICAgICB1cGNvbWluZ0NWUlQ6IHJ1bGVzLmlzQXV0aGVudGljYXRlZFVzZXIsXG4gICAgICAgIHRvbGxUYWdzOiBydWxlcy5pc0F1dGhlbnRpY2F0ZWRVc2VyLFxuICAgICAgICB0b2xsVGFnc05vdEFzc2lnbmVkOiBydWxlcy5pc0F1dGhlbnRpY2F0ZWRVc2VyLFxuICAgICAgICBmdWVsQ2FyZHM6IHJ1bGVzLmlzQXV0aGVudGljYXRlZFVzZXIsXG4gICAgICAgIGZ1ZWxDYXJkc05vdEFzc2lnbmVkOiBydWxlcy5pc0F1dGhlbnRpY2F0ZWRVc2VyLFxuICAgICAgICBkZXBvdHM6ICgwLCBncmFwaHFsX3NoaWVsZF8xLmFuZCkocnVsZXMuaXNBdXRoZW50aWNhdGVkVXNlciwgcnVsZXMuaXNBZG1pbiksXG4gICAgICAgIHZlaGljbGVzSW5EZXBvdDogcnVsZXMuaXNBdXRoZW50aWNhdGVkVXNlcixcbiAgICAgICAgdXNlcnM6ICgwLCBncmFwaHFsX3NoaWVsZF8xLmFuZCkocnVsZXMuaXNBdXRoZW50aWNhdGVkVXNlciwgcnVsZXMuaXNBZG1pbiksXG4gICAgfSxcbiAgICBNdXRhdGlvbjoge1xuICAgICAgICBhZGRWZWhpY2xlOiAoMCwgZ3JhcGhxbF9zaGllbGRfMS5hbmQpKHJ1bGVzLmlzQXV0aGVudGljYXRlZFVzZXIsIHJ1bGVzLmlzQWRtaW4pLFxuICAgICAgICB1cGRhdGVWZWhpY2xlOiAoMCwgZ3JhcGhxbF9zaGllbGRfMS5hbmQpKHJ1bGVzLmlzQXV0aGVudGljYXRlZFVzZXIsIHJ1bGVzLmlzQWRtaW4pLFxuICAgICAgICBkZWxldGVWZWhpY2xlOiAoMCwgZ3JhcGhxbF9zaGllbGRfMS5hbmQpKHJ1bGVzLmlzQXV0aGVudGljYXRlZFVzZXIsIHJ1bGVzLmlzQWRtaW4pLFxuICAgICAgICBhZGRUb2xsVGFnOiAoMCwgZ3JhcGhxbF9zaGllbGRfMS5hbmQpKHJ1bGVzLmlzQXV0aGVudGljYXRlZFVzZXIsIHJ1bGVzLmlzQWRtaW4pLFxuICAgICAgICB1cGRhdGVUb2xsVGFnOiAoMCwgZ3JhcGhxbF9zaGllbGRfMS5hbmQpKHJ1bGVzLmlzQXV0aGVudGljYXRlZFVzZXIsIHJ1bGVzLmlzQWRtaW4pLFxuICAgICAgICBkZWxldGVUb2xsVGFnOiAoMCwgZ3JhcGhxbF9zaGllbGRfMS5hbmQpKHJ1bGVzLmlzQXV0aGVudGljYXRlZFVzZXIsIHJ1bGVzLmlzQWRtaW4pLFxuICAgICAgICBhZGRGdWVsQ2FyZDogKDAsIGdyYXBocWxfc2hpZWxkXzEuYW5kKShydWxlcy5pc0F1dGhlbnRpY2F0ZWRVc2VyLCBydWxlcy5pc0FkbWluKSxcbiAgICAgICAgdXBkYXRlRnVlbENhcmQ6ICgwLCBncmFwaHFsX3NoaWVsZF8xLmFuZCkocnVsZXMuaXNBdXRoZW50aWNhdGVkVXNlciwgcnVsZXMuaXNBZG1pbiksXG4gICAgICAgIGRlbGV0ZUZ1ZWxDYXJkOiAoMCwgZ3JhcGhxbF9zaGllbGRfMS5hbmQpKHJ1bGVzLmlzQXV0aGVudGljYXRlZFVzZXIsIHJ1bGVzLmlzQWRtaW4pLFxuICAgICAgICBhZGREZXBvdDogKDAsIGdyYXBocWxfc2hpZWxkXzEuYW5kKShydWxlcy5pc0F1dGhlbnRpY2F0ZWRVc2VyLCBydWxlcy5pc0FkbWluKSxcbiAgICAgICAgdXBkYXRlRGVwb3Q6ICgwLCBncmFwaHFsX3NoaWVsZF8xLmFuZCkocnVsZXMuaXNBdXRoZW50aWNhdGVkVXNlciwgcnVsZXMuaXNBZG1pbiksXG4gICAgICAgIGRlbGV0ZURlcG90OiAoMCwgZ3JhcGhxbF9zaGllbGRfMS5hbmQpKHJ1bGVzLmlzQXV0aGVudGljYXRlZFVzZXIsIHJ1bGVzLmlzQWRtaW4pLFxuICAgICAgICBhZGREZWZlY3Q6IHJ1bGVzLmlzQXV0aGVudGljYXRlZFVzZXIsXG4gICAgICAgIGFkZFVzZXI6ICgwLCBncmFwaHFsX3NoaWVsZF8xLmFuZCkocnVsZXMuaXNBdXRoZW50aWNhdGVkVXNlciwgcnVsZXMuaXNBZG1pbiksXG4gICAgICAgIGRlbGV0ZVVzZXI6ICgwLCBncmFwaHFsX3NoaWVsZF8xLmFuZCkocnVsZXMuaXNBdXRoZW50aWNhdGVkVXNlciwgcnVsZXMuaXNBZG1pbiksXG4gICAgfSxcbn0sIHsgYWxsb3dFeHRlcm5hbEVycm9yczogdHJ1ZSB9KTtcbmV4cG9ydHMuZGVmYXVsdCA9IHBlcm1pc3Npb25zO1xuIiwiXCJ1c2Ugc3RyaWN0XCI7XG52YXIgX19jcmVhdGVCaW5kaW5nID0gKHRoaXMgJiYgdGhpcy5fX2NyZWF0ZUJpbmRpbmcpIHx8IChPYmplY3QuY3JlYXRlID8gKGZ1bmN0aW9uKG8sIG0sIGssIGsyKSB7XG4gICAgaWYgKGsyID09PSB1bmRlZmluZWQpIGsyID0gaztcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkobywgazIsIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBmdW5jdGlvbigpIHsgcmV0dXJuIG1ba107IH0gfSk7XG59KSA6IChmdW5jdGlvbihvLCBtLCBrLCBrMikge1xuICAgIGlmIChrMiA9PT0gdW5kZWZpbmVkKSBrMiA9IGs7XG4gICAgb1trMl0gPSBtW2tdO1xufSkpO1xudmFyIF9fc2V0TW9kdWxlRGVmYXVsdCA9ICh0aGlzICYmIHRoaXMuX19zZXRNb2R1bGVEZWZhdWx0KSB8fCAoT2JqZWN0LmNyZWF0ZSA/IChmdW5jdGlvbihvLCB2KSB7XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KG8sIFwiZGVmYXVsdFwiLCB7IGVudW1lcmFibGU6IHRydWUsIHZhbHVlOiB2IH0pO1xufSkgOiBmdW5jdGlvbihvLCB2KSB7XG4gICAgb1tcImRlZmF1bHRcIl0gPSB2O1xufSk7XG52YXIgX19pbXBvcnRTdGFyID0gKHRoaXMgJiYgdGhpcy5fX2ltcG9ydFN0YXIpIHx8IGZ1bmN0aW9uIChtb2QpIHtcbiAgICBpZiAobW9kICYmIG1vZC5fX2VzTW9kdWxlKSByZXR1cm4gbW9kO1xuICAgIHZhciByZXN1bHQgPSB7fTtcbiAgICBpZiAobW9kICE9IG51bGwpIGZvciAodmFyIGsgaW4gbW9kKSBpZiAoayAhPT0gXCJkZWZhdWx0XCIgJiYgT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG1vZCwgaykpIF9fY3JlYXRlQmluZGluZyhyZXN1bHQsIG1vZCwgayk7XG4gICAgX19zZXRNb2R1bGVEZWZhdWx0KHJlc3VsdCwgbW9kKTtcbiAgICByZXR1cm4gcmVzdWx0O1xufTtcbnZhciBfX2ltcG9ydERlZmF1bHQgPSAodGhpcyAmJiB0aGlzLl9faW1wb3J0RGVmYXVsdCkgfHwgZnVuY3Rpb24gKG1vZCkge1xuICAgIHJldHVybiAobW9kICYmIG1vZC5fX2VzTW9kdWxlKSA/IG1vZCA6IHsgXCJkZWZhdWx0XCI6IG1vZCB9O1xufTtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbmV4cG9ydHMuRGF0ZVRpbWVTY2FsYXIgPSB2b2lkIDA7XG5jb25zdCBncmFwaHFsX3NjYWxhcnNfMSA9IHJlcXVpcmUoXCJncmFwaHFsLXNjYWxhcnNcIik7XG5jb25zdCBuZXh1c18xID0gcmVxdWlyZShcIm5leHVzXCIpO1xuY29uc3QgZ3JhcGhxbF9taWRkbGV3YXJlXzEgPSByZXF1aXJlKFwiZ3JhcGhxbC1taWRkbGV3YXJlXCIpO1xuY29uc3QgZGVmZWN0VHlwZXMgPSBfX2ltcG9ydFN0YXIocmVxdWlyZShcIi4vc2NoZW1hL0RlZmVjdFwiKSk7XG5jb25zdCBkZXBvdFR5cGVzID0gX19pbXBvcnRTdGFyKHJlcXVpcmUoXCIuL3NjaGVtYS9EZXBvdFwiKSk7XG5jb25zdCBmdWVsQ2FyZFR5cGVzID0gX19pbXBvcnRTdGFyKHJlcXVpcmUoXCIuL3NjaGVtYS9GdWVsQ2FyZFwiKSk7XG5jb25zdCB0b2xsVGFnVHlwZXMgPSBfX2ltcG9ydFN0YXIocmVxdWlyZShcIi4vc2NoZW1hL1RvbGxUYWdcIikpO1xuY29uc3QgdmVoaWNsZVR5cGVzID0gX19pbXBvcnRTdGFyKHJlcXVpcmUoXCIuL3NjaGVtYS9WZWhpY2xlXCIpKTtcbmNvbnN0IHVzZXJUeXBlcyA9IF9faW1wb3J0U3RhcihyZXF1aXJlKFwiLi9zY2hlbWEvVXNlclwiKSk7XG5jb25zdCBvcmdhbmlzYXRpb25UeXBlcyA9IF9faW1wb3J0U3RhcihyZXF1aXJlKFwiLi9zY2hlbWEvT3JnYW5pc2F0aW9uXCIpKTtcbmNvbnN0IGluZnJpbmdlbWVudFR5cGVzID0gX19pbXBvcnRTdGFyKHJlcXVpcmUoXCIuL3NjaGVtYS9JbmZyaW5nZW1lbnRcIikpO1xuY29uc3QgZW51bVR5cGVzID0gX19pbXBvcnRTdGFyKHJlcXVpcmUoXCIuL3NjaGVtYS9FbnVtXCIpKTtcbmNvbnN0IHBlcm1pc3Npb25zXzEgPSBfX2ltcG9ydERlZmF1bHQocmVxdWlyZShcIi4vcGVybWlzc2lvbnNcIikpO1xuZXhwb3J0cy5EYXRlVGltZVNjYWxhciA9ICgwLCBuZXh1c18xLmFzTmV4dXNNZXRob2QpKGdyYXBocWxfc2NhbGFyc18xLkRhdGVUaW1lUmVzb2x2ZXIsICdkYXRlJyk7XG5jb25zdCBzY2hlbWFXaXRob3V0UGVybWlzc2lvbnMgPSAoMCwgbmV4dXNfMS5tYWtlU2NoZW1hKSh7XG4gICAgdHlwZXM6IFtcbiAgICAgICAgZGVmZWN0VHlwZXMsXG4gICAgICAgIGRlcG90VHlwZXMsXG4gICAgICAgIGZ1ZWxDYXJkVHlwZXMsXG4gICAgICAgIHRvbGxUYWdUeXBlcyxcbiAgICAgICAgdmVoaWNsZVR5cGVzLFxuICAgICAgICB1c2VyVHlwZXMsXG4gICAgICAgIG9yZ2FuaXNhdGlvblR5cGVzLFxuICAgICAgICBpbmZyaW5nZW1lbnRUeXBlcyxcbiAgICAgICAgZW51bVR5cGVzLFxuICAgICAgICBleHBvcnRzLkRhdGVUaW1lU2NhbGFyLFxuICAgIF0sXG4gICAgb3V0cHV0czoge1xuICAgICAgICBzY2hlbWE6IGAke19fZGlybmFtZX0vLi4vZ2VuZXJhdGVkL3NjaGVtYS5ncmFwaHFsYCxcbiAgICAgICAgdHlwZWdlbjogYCR7X19kaXJuYW1lfS8uLi9nZW5lcmF0ZWQvdHlwZXMudHNgLFxuICAgIH0sXG4gICAgY29udGV4dFR5cGU6IHtcbiAgICAgICAgbW9kdWxlOiByZXF1aXJlLnJlc29sdmUoJy4vY29udGV4dCcpLFxuICAgICAgICBleHBvcnQ6ICdDb250ZXh0JyxcbiAgICB9LFxuICAgIHNvdXJjZVR5cGVzOiB7XG4gICAgICAgIG1vZHVsZXM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBtb2R1bGU6ICdAcHJpc21hL2NsaWVudCcsXG4gICAgICAgICAgICAgICAgYWxpYXM6ICdwcmlzbWEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICB9LFxufSk7XG5jb25zdCBzY2hlbWEgPSAoMCwgZ3JhcGhxbF9taWRkbGV3YXJlXzEuYXBwbHlNaWRkbGV3YXJlKShzY2hlbWFXaXRob3V0UGVybWlzc2lvbnMsIHBlcm1pc3Npb25zXzEuZGVmYXVsdCk7XG5leHBvcnRzLmRlZmF1bHQgPSBzY2hlbWE7XG4iLCJcInVzZSBzdHJpY3RcIjtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbmV4cG9ydHMuRGVmZWN0TXV0YXRpb24gPSBleHBvcnRzLkRlZmVjdFF1ZXJ5ID0gZXhwb3J0cy5EZWZlY3QgPSB2b2lkIDA7XG5jb25zdCBuZXh1c18xID0gcmVxdWlyZShcIm5leHVzXCIpO1xuY29uc3QgZ2V0VXNlcklkXzEgPSByZXF1aXJlKFwiLi4vdXRpbGl0aWVzL2dldFVzZXJJZFwiKTtcbmNvbnN0IEVudW1fMSA9IHJlcXVpcmUoXCIuL0VudW1cIik7XG5leHBvcnRzLkRlZmVjdCA9ICgwLCBuZXh1c18xLm9iamVjdFR5cGUpKHtcbiAgICBuYW1lOiAnRGVmZWN0JyxcbiAgICBkZWZpbml0aW9uKHQpIHtcbiAgICAgICAgdC5ub25OdWxsLmlkKCdpZCcpO1xuICAgICAgICB0Lm5vbk51bGwuc3RyaW5nKCdkZXNjcmlwdGlvbicpO1xuICAgICAgICB0Lm5vbk51bGwuc3RyaW5nKCdyZXBvcnRlcicpO1xuICAgICAgICB0Lm5vbk51bGwuZGF0ZSgnZGF0ZVJlcG9ydGVkJyk7XG4gICAgICAgIHQuZGF0ZSgnZGF0ZUNvbXBsZXRlZCcpO1xuICAgICAgICB0Lm5vbk51bGwuZmllbGQoJ3N0YXR1cycsIHtcbiAgICAgICAgICAgIHR5cGU6IEVudW1fMS5EZWZlY3RTdGF0dXMsXG4gICAgICAgIH0pO1xuICAgIH0sXG59KTtcbmV4cG9ydHMuRGVmZWN0UXVlcnkgPSAoMCwgbmV4dXNfMS5leHRlbmRUeXBlKSh7XG4gICAgdHlwZTogJ1F1ZXJ5JyxcbiAgICBkZWZpbml0aW9uKHQpIHtcbiAgICAgICAgdC5saXN0LmZpZWxkKCdkZWZlY3RzRm9yVmVoaWNsZScsIHtcbiAgICAgICAgICAgIHR5cGU6IGV4cG9ydHMuRGVmZWN0LFxuICAgICAgICAgICAgYXJnczoge1xuICAgICAgICAgICAgICAgIHZlaGljbGVJZDogKDAsIG5leHVzXzEubm9uTnVsbCkoKDAsIG5leHVzXzEuaWRBcmcpKCkpLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHJlc29sdmU6IChfLCB7IHZlaGljbGVJZCB9LCBjb250ZXh0KSA9PiB7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGNvbnRleHQucHJpc21hLnZlaGljbGVcbiAgICAgICAgICAgICAgICAgICAgICAgIC5maW5kVW5pcXVlKHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHdoZXJlOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IHZlaGljbGVJZCxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAuZGVmZWN0cygpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdFcnJvciByZXRyaWV2aW5nIGRlZmVjdHMnKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9LFxufSk7XG5jb25zdCBBZGREZWZlY3RJbnB1dCA9ICgwLCBuZXh1c18xLmlucHV0T2JqZWN0VHlwZSkoe1xuICAgIG5hbWU6ICdBZGREZWZlY3RJbnB1dCcsXG4gICAgZGVmaW5pdGlvbih0KSB7XG4gICAgICAgIHQubm9uTnVsbC5zdHJpbmcoJ2Rlc2NyaXB0aW9uJyk7XG4gICAgICAgIHQubm9uTnVsbC5pZCgndmVoaWNsZUlkJyk7XG4gICAgfSxcbn0pO1xuY29uc3QgVXBkYXRlRGVmZWN0SW5wdXQgPSAoMCwgbmV4dXNfMS5pbnB1dE9iamVjdFR5cGUpKHtcbiAgICBuYW1lOiAnVXBkYXRlRGVmZWN0SW5wdXQnLFxuICAgIGRlZmluaXRpb24odCkge1xuICAgICAgICB0Lm5vbk51bGwuaWQoJ2lkJyk7XG4gICAgICAgIHQubm9uTnVsbC5zdHJpbmcoJ2Rlc2NyaXB0aW9uJyk7XG4gICAgICAgIHQubm9uTnVsbC5maWVsZCgnc3RhdHVzJywge1xuICAgICAgICAgICAgdHlwZTogRW51bV8xLkRlZmVjdFN0YXR1cyxcbiAgICAgICAgfSk7XG4gICAgfSxcbn0pO1xuY29uc3QgRGVsZXRlRGVmZWN0SW5wdXQgPSAoMCwgbmV4dXNfMS5pbnB1dE9iamVjdFR5cGUpKHtcbiAgICBuYW1lOiAnRGVsZXRlRGVmZWN0SW5wdXQnLFxuICAgIGRlZmluaXRpb24odCkge1xuICAgICAgICB0Lm5vbk51bGwuaWQoJ2lkJyk7XG4gICAgfSxcbn0pO1xuZXhwb3J0cy5EZWZlY3RNdXRhdGlvbiA9ICgwLCBuZXh1c18xLmV4dGVuZFR5cGUpKHtcbiAgICB0eXBlOiAnTXV0YXRpb24nLFxuICAgIGRlZmluaXRpb24odCkge1xuICAgICAgICB0Lm5vbk51bGwuZmllbGQoJ2FkZERlZmVjdCcsIHtcbiAgICAgICAgICAgIHR5cGU6IGV4cG9ydHMuRGVmZWN0LFxuICAgICAgICAgICAgYXJnczoge1xuICAgICAgICAgICAgICAgIGRhdGE6ICgwLCBuZXh1c18xLm5vbk51bGwpKCgwLCBuZXh1c18xLmFyZykoe1xuICAgICAgICAgICAgICAgICAgICB0eXBlOiBBZGREZWZlY3RJbnB1dCxcbiAgICAgICAgICAgICAgICB9KSksXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcmVzb2x2ZTogYXN5bmMgKF8sIGFyZ3MsIGNvbnRleHQpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCB1c2VySWQgPSAoMCwgZ2V0VXNlcklkXzEuZ2V0VXNlcklkKShjb250ZXh0KTtcbiAgICAgICAgICAgICAgICBpZiAoIXVzZXJJZCkge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1VuYWJsZSB0byBhZGQgZGVmZWN0LiBZb3UgYXJlIG5vdCBsb2dnZWQgaW4uJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNvbnN0IHVzZXIgPSBhd2FpdCBjb250ZXh0LnByaXNtYS51c2VyLmZpbmRVbmlxdWUoe1xuICAgICAgICAgICAgICAgICAgICB3aGVyZToge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IHVzZXJJZCxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICBpZiAoIXVzZXIpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdVbmFibGUgdG8gYWRkIGRlZmVjdC4gWW91IGFyZSBub3QgbG9nZ2VkIGluLicpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gY29udGV4dC5wcmlzbWEuZGVmZWN0LmNyZWF0ZSh7XG4gICAgICAgICAgICAgICAgICAgIGRhdGE6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBhcmdzLmRhdGEuZGVzY3JpcHRpb24sXG4gICAgICAgICAgICAgICAgICAgICAgICBkYXRlUmVwb3J0ZWQ6IG5ldyBEYXRlKCksXG4gICAgICAgICAgICAgICAgICAgICAgICByZXBvcnRlcjogdXNlci5uYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgc3RhdHVzOiAnSU5DT01QTEVURScsXG4gICAgICAgICAgICAgICAgICAgICAgICB2ZWhpY2xlOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29ubmVjdDoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogYXJncy5kYXRhLnZlaGljbGVJZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICB0Lm5vbk51bGwuZmllbGQoJ3VwZGF0ZURlZmVjdCcsIHtcbiAgICAgICAgICAgIHR5cGU6IGV4cG9ydHMuRGVmZWN0LFxuICAgICAgICAgICAgYXJnczoge1xuICAgICAgICAgICAgICAgIGRhdGE6ICgwLCBuZXh1c18xLm5vbk51bGwpKCgwLCBuZXh1c18xLmFyZykoe1xuICAgICAgICAgICAgICAgICAgICB0eXBlOiBVcGRhdGVEZWZlY3RJbnB1dCxcbiAgICAgICAgICAgICAgICB9KSksXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcmVzb2x2ZTogYXN5bmMgKF8sIGFyZ3MsIGNvbnRleHQpID0+IHtcbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBpc0NvbXBsZXRlID0gYXJncy5kYXRhLnN0YXR1cyA9PT0gJ0NPTVBMRVRFJztcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGNvbnRleHQucHJpc21hLmRlZmVjdC51cGRhdGUoe1xuICAgICAgICAgICAgICAgICAgICAgICAgd2hlcmU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogYXJncy5kYXRhLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGE6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogYXJncy5kYXRhLmRlc2NyaXB0aW9uLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0YXR1czogYXJncy5kYXRhLnN0YXR1cyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRlQ29tcGxldGVkOiBpc0NvbXBsZXRlID8gbmV3IERhdGUoKSA6IG51bGwsXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignRXJyb3IgdXBkYXRpbmcgZnVlbCBjYXJkJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHQubm9uTnVsbC5maWVsZCgnZGVsZXRlRGVmZWN0Jywge1xuICAgICAgICAgICAgdHlwZTogZXhwb3J0cy5EZWZlY3QsXG4gICAgICAgICAgICBhcmdzOiB7XG4gICAgICAgICAgICAgICAgZGF0YTogKDAsIG5leHVzXzEubm9uTnVsbCkoKDAsIG5leHVzXzEuYXJnKSh7XG4gICAgICAgICAgICAgICAgICAgIHR5cGU6IERlbGV0ZURlZmVjdElucHV0LFxuICAgICAgICAgICAgICAgIH0pKSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICByZXNvbHZlOiAoXywgYXJncywgY29udGV4dCkgPT4ge1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBjb250ZXh0LnByaXNtYS5kZWZlY3QuZGVsZXRlKHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHdoZXJlOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IGFyZ3MuZGF0YS5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdFcnJvciBkZWxldGluZyBkZWZlY3QnKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9LFxufSk7XG4iLCJcInVzZSBzdHJpY3RcIjtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbmV4cG9ydHMuRGVwb3RNdXRhdGlvbiA9IGV4cG9ydHMuRGVwb3RRdWVyeSA9IGV4cG9ydHMuRGVwb3QgPSB2b2lkIDA7XG5jb25zdCBuZXh1c18xID0gcmVxdWlyZShcIm5leHVzXCIpO1xuY29uc3QgZ2V0VXNlcklkXzEgPSByZXF1aXJlKFwiLi4vdXRpbGl0aWVzL2dldFVzZXJJZFwiKTtcbmNvbnN0IE9yZ2FuaXNhdGlvbl8xID0gcmVxdWlyZShcIi4vT3JnYW5pc2F0aW9uXCIpO1xuY29uc3QgVmVoaWNsZV8xID0gcmVxdWlyZShcIi4vVmVoaWNsZVwiKTtcbmV4cG9ydHMuRGVwb3QgPSAoMCwgbmV4dXNfMS5vYmplY3RUeXBlKSh7XG4gICAgbmFtZTogJ0RlcG90JyxcbiAgICBkZWZpbml0aW9uKHQpIHtcbiAgICAgICAgdC5ub25OdWxsLmlkKCdpZCcpO1xuICAgICAgICB0Lm5vbk51bGwuc3RyaW5nKCduYW1lJyk7XG4gICAgICAgIHQubm9uTnVsbC5maWVsZCgnb3JnYW5pc2F0aW9uJywge1xuICAgICAgICAgICAgdHlwZTogT3JnYW5pc2F0aW9uXzEuT3JnYW5pc2F0aW9uLFxuICAgICAgICAgICAgcmVzb2x2ZTogYXN5bmMgKHBhcmVudCwgXywgY29udGV4dCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IG9yZ2FuaXNhdGlvbiA9IGF3YWl0IGNvbnRleHQucHJpc21hLmRlcG90XG4gICAgICAgICAgICAgICAgICAgIC5maW5kVW5pcXVlKHtcbiAgICAgICAgICAgICAgICAgICAgd2hlcmU6IHsgaWQ6IHBhcmVudC5pZCB9LFxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgIC5vcmdhbmlzYXRpb24oKTtcbiAgICAgICAgICAgICAgICBpZiAoIW9yZ2FuaXNhdGlvbikge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ09yZ2FuaXNhdGlvbiBub3QgZm91bmQnKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIG9yZ2FuaXNhdGlvbjtcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICB0Lm5vbk51bGwubGlzdC5ub25OdWxsLmZpZWxkKCd2ZWhpY2xlcycsIHtcbiAgICAgICAgICAgIHR5cGU6IFZlaGljbGVfMS5WZWhpY2xlLFxuICAgICAgICAgICAgcmVzb2x2ZShwYXJlbnQsIF8sIGNvbnRleHQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gY29udGV4dC5wcmlzbWEuZGVwb3RcbiAgICAgICAgICAgICAgICAgICAgLmZpbmRVbmlxdWUoe1xuICAgICAgICAgICAgICAgICAgICB3aGVyZTogeyBpZDogcGFyZW50LmlkIH0sXG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgLnZlaGljbGVzKCk7XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9LFxufSk7XG5jb25zdCBEZXBvdElucHV0RmlsdGVyID0gKDAsIG5leHVzXzEuaW5wdXRPYmplY3RUeXBlKSh7XG4gICAgbmFtZTogJ0RlcG90SW5wdXRGaWx0ZXInLFxuICAgIGRlZmluaXRpb24odCkge1xuICAgICAgICB0LnN0cmluZygnc2VhcmNoQ3JpdGVyaWEnKTtcbiAgICB9LFxufSk7XG5leHBvcnRzLkRlcG90UXVlcnkgPSAoMCwgbmV4dXNfMS5leHRlbmRUeXBlKSh7XG4gICAgdHlwZTogJ1F1ZXJ5JyxcbiAgICBkZWZpbml0aW9uKHQpIHtcbiAgICAgICAgdC5saXN0LmZpZWxkKCdkZXBvdHMnLCB7XG4gICAgICAgICAgICB0eXBlOiBleHBvcnRzLkRlcG90LFxuICAgICAgICAgICAgYXJnczoge1xuICAgICAgICAgICAgICAgIGRhdGE6ICgwLCBuZXh1c18xLmFyZykoe1xuICAgICAgICAgICAgICAgICAgICB0eXBlOiBEZXBvdElucHV0RmlsdGVyLFxuICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHJlc29sdmU6IGFzeW5jIChfLCBhcmdzLCBjb250ZXh0KSA9PiB7XG4gICAgICAgICAgICAgICAgdmFyIF9hO1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHVzZXJJZCA9ICgwLCBnZXRVc2VySWRfMS5nZXRVc2VySWQpKGNvbnRleHQpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoIXVzZXJJZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdVbmFibGUgdG8gcmV0cmlldmUgZGVwb3RzLiBZb3UgYXJlIG5vdCBsb2dnZWQgaW4uJyk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgY29uc3Qgb3JnYW5pc2F0aW9uID0gYXdhaXQgY29udGV4dC5wcmlzbWEudXNlclxuICAgICAgICAgICAgICAgICAgICAgICAgLmZpbmRVbmlxdWUoe1xuICAgICAgICAgICAgICAgICAgICAgICAgd2hlcmU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogdXNlcklkICE9IG51bGwgPyB1c2VySWQgOiB1bmRlZmluZWQsXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgLm9yZ2FuaXNhdGlvbigpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gY29udGV4dC5wcmlzbWEuZGVwb3QuZmluZE1hbnkoe1xuICAgICAgICAgICAgICAgICAgICAgICAgd2hlcmU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBBTkQ6IFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBvcmdhbmlzYXRpb25JZDogb3JnYW5pc2F0aW9uID09PSBudWxsIHx8IG9yZ2FuaXNhdGlvbiA9PT0gdm9pZCAwID8gdm9pZCAwIDogb3JnYW5pc2F0aW9uLmlkIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250YWluczogKChfYSA9IGFyZ3MuZGF0YSkgPT09IG51bGwgfHwgX2EgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9hLnNlYXJjaENyaXRlcmlhKSAhPSBudWxsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gYXJncy5kYXRhLnNlYXJjaENyaXRlcmlhXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1vZGU6ICdpbnNlbnNpdGl2ZScsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgb3JkZXJCeToge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6ICdhc2MnLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0Vycm9yIHJldHJpZXZpbmcgZGVwb3RzJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHQubGlzdC5maWVsZCgndmVoaWNsZXNJbkRlcG90Jywge1xuICAgICAgICAgICAgdHlwZTogVmVoaWNsZV8xLlZlaGljbGUsXG4gICAgICAgICAgICBhcmdzOiB7XG4gICAgICAgICAgICAgICAgZGVwb3RJZDogKDAsIG5leHVzXzEubm9uTnVsbCkoKDAsIG5leHVzXzEuaWRBcmcpKCkpLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHJlc29sdmU6IChfLCB7IGRlcG90SWQgfSwgY29udGV4dCkgPT4ge1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBjb250ZXh0LnByaXNtYS5kZXBvdFxuICAgICAgICAgICAgICAgICAgICAgICAgLmZpbmRVbmlxdWUoe1xuICAgICAgICAgICAgICAgICAgICAgICAgd2hlcmU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogZGVwb3RJZCxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAudmVoaWNsZXMoKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignRXJyb3IgcmV0cmlldmluZyB2ZWhpY2xlcyBmb3IgZGVwb3QnKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9LFxufSk7XG5jb25zdCBBZGREZXBvdElucHV0ID0gKDAsIG5leHVzXzEuaW5wdXRPYmplY3RUeXBlKSh7XG4gICAgbmFtZTogJ0FkZERlcG90SW5wdXQnLFxuICAgIGRlZmluaXRpb24odCkge1xuICAgICAgICB0Lm5vbk51bGwuc3RyaW5nKCduYW1lJyk7XG4gICAgfSxcbn0pO1xuY29uc3QgVXBkYXRlRGVwb3RJbnB1dCA9ICgwLCBuZXh1c18xLmlucHV0T2JqZWN0VHlwZSkoe1xuICAgIG5hbWU6ICdVcGRhdGVEZXBvdElucHV0JyxcbiAgICBkZWZpbml0aW9uKHQpIHtcbiAgICAgICAgdC5ub25OdWxsLmlkKCdpZCcpO1xuICAgICAgICB0Lm5vbk51bGwuc3RyaW5nKCduYW1lJyk7XG4gICAgfSxcbn0pO1xuY29uc3QgRGVsZXRlRGVwb3RJbnB1dCA9ICgwLCBuZXh1c18xLmlucHV0T2JqZWN0VHlwZSkoe1xuICAgIG5hbWU6ICdEZWxldGVEZXBvdElucHV0JyxcbiAgICBkZWZpbml0aW9uKHQpIHtcbiAgICAgICAgdC5ub25OdWxsLmlkKCdpZCcpO1xuICAgIH0sXG59KTtcbmV4cG9ydHMuRGVwb3RNdXRhdGlvbiA9ICgwLCBuZXh1c18xLmV4dGVuZFR5cGUpKHtcbiAgICB0eXBlOiAnTXV0YXRpb24nLFxuICAgIGRlZmluaXRpb24odCkge1xuICAgICAgICB0Lm5vbk51bGwuZmllbGQoJ2FkZERlcG90Jywge1xuICAgICAgICAgICAgdHlwZTogZXhwb3J0cy5EZXBvdCxcbiAgICAgICAgICAgIGFyZ3M6IHtcbiAgICAgICAgICAgICAgICBkYXRhOiAoMCwgbmV4dXNfMS5ub25OdWxsKSgoMCwgbmV4dXNfMS5hcmcpKHtcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogQWRkRGVwb3RJbnB1dCxcbiAgICAgICAgICAgICAgICB9KSksXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcmVzb2x2ZTogYXN5bmMgKF8sIGFyZ3MsIGNvbnRleHQpID0+IHtcbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCB1c2VySWQgPSAoMCwgZ2V0VXNlcklkXzEuZ2V0VXNlcklkKShjb250ZXh0KTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKCF1c2VySWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignVW5hYmxlIHRvIGFkZCBkZXBvdC4gWW91IGFyZSBub3QgbG9nZ2VkIGluLicpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IG9yZ2FuaXNhdGlvbiA9IGF3YWl0IGNvbnRleHQucHJpc21hLnVzZXJcbiAgICAgICAgICAgICAgICAgICAgICAgIC5maW5kVW5pcXVlKHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHdoZXJlOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IHVzZXJJZCAhPSBudWxsID8gdXNlcklkIDogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgIC5vcmdhbmlzYXRpb24oKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZXhpc3RpbmdEZXBvdCA9IGF3YWl0IGNvbnRleHQucHJpc21hLmRlcG90LmZpbmRVbmlxdWUoe1xuICAgICAgICAgICAgICAgICAgICAgICAgd2hlcmU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiBhcmdzLmRhdGEubmFtZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICBpZiAoZXhpc3RpbmdEZXBvdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdEZXBvdCBhbHJlYWR5IGV4aXN0cyB3aXRoIHRoaXMgbmFtZScpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBjb250ZXh0LnByaXNtYS5kZXBvdC5jcmVhdGUoe1xuICAgICAgICAgICAgICAgICAgICAgICAgZGF0YToge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6IGFyZ3MuZGF0YS5uYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9yZ2FuaXNhdGlvbjoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25uZWN0OiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogb3JnYW5pc2F0aW9uID09PSBudWxsIHx8IG9yZ2FuaXNhdGlvbiA9PT0gdm9pZCAwID8gdm9pZCAwIDogb3JnYW5pc2F0aW9uLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignRXJyb3IgYWRkaW5nIGRlcG90Jyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHQubm9uTnVsbC5maWVsZCgndXBkYXRlRGVwb3QnLCB7XG4gICAgICAgICAgICB0eXBlOiBleHBvcnRzLkRlcG90LFxuICAgICAgICAgICAgYXJnczoge1xuICAgICAgICAgICAgICAgIGRhdGE6ICgwLCBuZXh1c18xLm5vbk51bGwpKCgwLCBuZXh1c18xLmFyZykoe1xuICAgICAgICAgICAgICAgICAgICB0eXBlOiBVcGRhdGVEZXBvdElucHV0LFxuICAgICAgICAgICAgICAgIH0pKSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICByZXNvbHZlOiBhc3luYyAoXywgYXJncywgY29udGV4dCkgPT4ge1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBjb250ZXh0LnByaXNtYS5kZXBvdC51cGRhdGUoe1xuICAgICAgICAgICAgICAgICAgICAgICAgd2hlcmU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogYXJncy5kYXRhLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGE6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiBhcmdzLmRhdGEubmFtZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdFcnJvciB1cGRhdGluZyBkZXBvdCcpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICB0Lm5vbk51bGwuZmllbGQoJ2RlbGV0ZURlcG90Jywge1xuICAgICAgICAgICAgdHlwZTogZXhwb3J0cy5EZXBvdCxcbiAgICAgICAgICAgIGFyZ3M6IHtcbiAgICAgICAgICAgICAgICBkYXRhOiAoMCwgbmV4dXNfMS5ub25OdWxsKSgoMCwgbmV4dXNfMS5hcmcpKHtcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogRGVsZXRlRGVwb3RJbnB1dCxcbiAgICAgICAgICAgICAgICB9KSksXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcmVzb2x2ZTogKF8sIGFyZ3MsIGNvbnRleHQpID0+IHtcbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gY29udGV4dC5wcmlzbWEuZGVwb3QuZGVsZXRlKHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHdoZXJlOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IGFyZ3MuZGF0YS5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdFcnJvciBkZWxldGluZyBkZXBvdCcpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH0sXG59KTtcbiIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuZXhwb3J0cy5JbmZyaW5nZW1lbnRTdGF0dXMgPSBleHBvcnRzLkRlZmVjdFN0YXR1cyA9IGV4cG9ydHMuVmVoaWNsZVR5cGUgPSBleHBvcnRzLlJvbGUgPSB2b2lkIDA7XG5jb25zdCBuZXh1c18xID0gcmVxdWlyZShcIm5leHVzXCIpO1xuZXhwb3J0cy5Sb2xlID0gKDAsIG5leHVzXzEuZW51bVR5cGUpKHtcbiAgICBuYW1lOiAnUm9sZScsXG4gICAgbWVtYmVyczoge1xuICAgICAgICBPd25lcjogJ09XTkVSJyxcbiAgICAgICAgQWRtaW46ICdBRE1JTicsXG4gICAgICAgIFVzZXI6ICdVU0VSJyxcbiAgICAgICAgRHJpdmVyOiAnRFJJVkVSJyxcbiAgICB9LFxufSk7XG5leHBvcnRzLlZlaGljbGVUeXBlID0gKDAsIG5leHVzXzEuZW51bVR5cGUpKHtcbiAgICBuYW1lOiAnVmVoaWNsZVR5cGUnLFxuICAgIG1lbWJlcnM6IHtcbiAgICAgICAgVmFuOiAnVkFOJyxcbiAgICAgICAgVHJ1Y2s6ICdUUlVDSycsXG4gICAgICAgIFRyYWlsZXI6ICdUUkFJTEVSJyxcbiAgICB9LFxufSk7XG5leHBvcnRzLkRlZmVjdFN0YXR1cyA9ICgwLCBuZXh1c18xLmVudW1UeXBlKSh7XG4gICAgbmFtZTogJ0RlZmVjdFN0YXR1cycsXG4gICAgbWVtYmVyczoge1xuICAgICAgICBJbmNvbXBsZXRlOiAnSU5DT01QTEVURScsXG4gICAgICAgIENvbXBsZXRlOiAnQ09NUExFVEUnLFxuICAgIH0sXG59KTtcbmV4cG9ydHMuSW5mcmluZ2VtZW50U3RhdHVzID0gKDAsIG5leHVzXzEuZW51bVR5cGUpKHtcbiAgICBuYW1lOiAnSW5mcmluZ2VtZW50U3RhdHVzJyxcbiAgICBtZW1iZXJzOiB7XG4gICAgICAgIFVuc2lnbmVkOiAnVU5TSUdORUQnLFxuICAgICAgICBTaWduZWQ6ICdTSUdORUQnLFxuICAgIH0sXG59KTtcbiIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuZXhwb3J0cy5GdWVsQ2FyZE11dGF0aW9uID0gZXhwb3J0cy5GdWVsQ2FyZFF1ZXJ5ID0gZXhwb3J0cy5GdWVsQ2FyZCA9IHZvaWQgMDtcbmNvbnN0IG5leHVzXzEgPSByZXF1aXJlKFwibmV4dXNcIik7XG5jb25zdCBnZXRVc2VySWRfMSA9IHJlcXVpcmUoXCIuLi91dGlsaXRpZXMvZ2V0VXNlcklkXCIpO1xuY29uc3QgT3JnYW5pc2F0aW9uXzEgPSByZXF1aXJlKFwiLi9PcmdhbmlzYXRpb25cIik7XG5jb25zdCBWZWhpY2xlXzEgPSByZXF1aXJlKFwiLi9WZWhpY2xlXCIpO1xuZXhwb3J0cy5GdWVsQ2FyZCA9ICgwLCBuZXh1c18xLm9iamVjdFR5cGUpKHtcbiAgICBuYW1lOiAnRnVlbENhcmQnLFxuICAgIGRlZmluaXRpb24odCkge1xuICAgICAgICB0Lm5vbk51bGwuaWQoJ2lkJyk7XG4gICAgICAgIHQubm9uTnVsbC5zdHJpbmcoJ2NhcmROdW1iZXInKTtcbiAgICAgICAgdC5ub25OdWxsLnN0cmluZygnY2FyZFByb3ZpZGVyJyk7XG4gICAgICAgIHQubm9uTnVsbC5maWVsZCgnb3JnYW5pc2F0aW9uJywge1xuICAgICAgICAgICAgdHlwZTogT3JnYW5pc2F0aW9uXzEuT3JnYW5pc2F0aW9uLFxuICAgICAgICAgICAgcmVzb2x2ZTogYXN5bmMgKHBhcmVudCwgXywgY29udGV4dCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IG9yZ2FuaXNhdGlvbiA9IGF3YWl0IGNvbnRleHQucHJpc21hLmZ1ZWxDYXJkXG4gICAgICAgICAgICAgICAgICAgIC5maW5kVW5pcXVlKHtcbiAgICAgICAgICAgICAgICAgICAgd2hlcmU6IHsgaWQ6IHBhcmVudC5pZCB9LFxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgIC5vcmdhbmlzYXRpb24oKTtcbiAgICAgICAgICAgICAgICBpZiAoIW9yZ2FuaXNhdGlvbikge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ09yZ2FuaXNhdGlvbiBub3QgZm91bmQnKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIG9yZ2FuaXNhdGlvbjtcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICB0LmZpZWxkKCd2ZWhpY2xlJywge1xuICAgICAgICAgICAgdHlwZTogVmVoaWNsZV8xLlZlaGljbGUsXG4gICAgICAgICAgICByZXNvbHZlKHBhcmVudCwgXywgY29udGV4dCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBjb250ZXh0LnByaXNtYS5mdWVsQ2FyZFxuICAgICAgICAgICAgICAgICAgICAuZmluZFVuaXF1ZSh7XG4gICAgICAgICAgICAgICAgICAgIHdoZXJlOiB7IGlkOiBwYXJlbnQuaWQgfSxcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAudmVoaWNsZSgpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfSxcbn0pO1xuY29uc3QgRnVlbENhcmRJbnB1dEZpbHRlciA9ICgwLCBuZXh1c18xLmlucHV0T2JqZWN0VHlwZSkoe1xuICAgIG5hbWU6ICdGdWVsQ2FyZElucHV0RmlsdGVyJyxcbiAgICBkZWZpbml0aW9uKHQpIHtcbiAgICAgICAgdC5zdHJpbmcoJ3NlYXJjaENyaXRlcmlhJyk7XG4gICAgfSxcbn0pO1xuZXhwb3J0cy5GdWVsQ2FyZFF1ZXJ5ID0gKDAsIG5leHVzXzEuZXh0ZW5kVHlwZSkoe1xuICAgIHR5cGU6ICdRdWVyeScsXG4gICAgZGVmaW5pdGlvbih0KSB7XG4gICAgICAgIHQubGlzdC5maWVsZCgnZnVlbENhcmRzJywge1xuICAgICAgICAgICAgdHlwZTogZXhwb3J0cy5GdWVsQ2FyZCxcbiAgICAgICAgICAgIGFyZ3M6IHtcbiAgICAgICAgICAgICAgICBkYXRhOiAoMCwgbmV4dXNfMS5hcmcpKHtcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogRnVlbENhcmRJbnB1dEZpbHRlcixcbiAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICByZXNvbHZlOiBhc3luYyAoXywgYXJncywgY29udGV4dCkgPT4ge1xuICAgICAgICAgICAgICAgIHZhciBfYTtcbiAgICAgICAgICAgICAgICBjb25zdCB1c2VySWQgPSAoMCwgZ2V0VXNlcklkXzEuZ2V0VXNlcklkKShjb250ZXh0KTtcbiAgICAgICAgICAgICAgICBpZiAoIXVzZXJJZCkge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1VuYWJsZSB0byByZXRyaWV2ZSBmdWVsIGNhcmRzLiBZb3UgYXJlIG5vdCBsb2dnZWQgaW4uJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNvbnN0IG9yZ2FuaXNhdGlvbiA9IGF3YWl0IGNvbnRleHQucHJpc21hLnVzZXJcbiAgICAgICAgICAgICAgICAgICAgLmZpbmRVbmlxdWUoe1xuICAgICAgICAgICAgICAgICAgICB3aGVyZToge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IHVzZXJJZCAhPSBudWxsID8gdXNlcklkIDogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgIC5vcmdhbmlzYXRpb24oKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gY29udGV4dC5wcmlzbWEuZnVlbENhcmQuZmluZE1hbnkoe1xuICAgICAgICAgICAgICAgICAgICB3aGVyZToge1xuICAgICAgICAgICAgICAgICAgICAgICAgQU5EOiBbXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBvcmdhbmlzYXRpb25JZDogb3JnYW5pc2F0aW9uID09PSBudWxsIHx8IG9yZ2FuaXNhdGlvbiA9PT0gdm9pZCAwID8gdm9pZCAwIDogb3JnYW5pc2F0aW9uLmlkIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXJkTnVtYmVyOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250YWluczogKChfYSA9IGFyZ3MuZGF0YSkgPT09IG51bGwgfHwgX2EgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9hLnNlYXJjaENyaXRlcmlhKSAhPSBudWxsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBhcmdzLmRhdGEuc2VhcmNoQ3JpdGVyaWFcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1vZGU6ICdpbnNlbnNpdGl2ZScsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIG9yZGVyQnk6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhcmROdW1iZXI6ICdhc2MnLFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHQubGlzdC5maWVsZCgnZnVlbENhcmRzTm90QXNzaWduZWQnLCB7XG4gICAgICAgICAgICB0eXBlOiBleHBvcnRzLkZ1ZWxDYXJkLFxuICAgICAgICAgICAgcmVzb2x2ZTogYXN5bmMgKF8sIF9fLCBjb250ZXh0KSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgdXNlcklkID0gKDAsIGdldFVzZXJJZF8xLmdldFVzZXJJZCkoY29udGV4dCk7XG4gICAgICAgICAgICAgICAgaWYgKCF1c2VySWQpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdVbmFibGUgdG8gcmV0cmlldmUgdW5hc3NpZ25lZCBmdWVsIGNhcmRzLiBZb3UgYXJlIG5vdCBsb2dnZWQgaW4uJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNvbnN0IG9yZ2FuaXNhdGlvbiA9IGF3YWl0IGNvbnRleHQucHJpc21hLnVzZXJcbiAgICAgICAgICAgICAgICAgICAgLmZpbmRVbmlxdWUoe1xuICAgICAgICAgICAgICAgICAgICB3aGVyZToge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IHVzZXJJZCAhPSBudWxsID8gdXNlcklkIDogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgIC5vcmdhbmlzYXRpb24oKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gY29udGV4dC5wcmlzbWEuZnVlbENhcmQuZmluZE1hbnkoe1xuICAgICAgICAgICAgICAgICAgICB3aGVyZToge1xuICAgICAgICAgICAgICAgICAgICAgICAgQU5EOiBbeyB2ZWhpY2xlSWQ6IG51bGwgfSwgeyBvcmdhbmlzYXRpb25JZDogb3JnYW5pc2F0aW9uID09PSBudWxsIHx8IG9yZ2FuaXNhdGlvbiA9PT0gdm9pZCAwID8gdm9pZCAwIDogb3JnYW5pc2F0aW9uLmlkIH1dLFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICBvcmRlckJ5OiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjYXJkTnVtYmVyOiAnYXNjJyxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH0sXG59KTtcbmNvbnN0IEFkZEZ1ZWxDYXJkSW5wdXQgPSAoMCwgbmV4dXNfMS5pbnB1dE9iamVjdFR5cGUpKHtcbiAgICBuYW1lOiAnQWRkRnVlbENhcmRJbnB1dCcsXG4gICAgZGVmaW5pdGlvbih0KSB7XG4gICAgICAgIHQubm9uTnVsbC5zdHJpbmcoJ2NhcmROdW1iZXInKTtcbiAgICAgICAgdC5ub25OdWxsLnN0cmluZygnY2FyZFByb3ZpZGVyJyk7XG4gICAgfSxcbn0pO1xuY29uc3QgVXBkYXRlRnVlbENhcmRJbnB1dCA9ICgwLCBuZXh1c18xLmlucHV0T2JqZWN0VHlwZSkoe1xuICAgIG5hbWU6ICdVcGRhdGVGdWVsQ2FyZElucHV0JyxcbiAgICBkZWZpbml0aW9uKHQpIHtcbiAgICAgICAgdC5ub25OdWxsLmlkKCdpZCcpO1xuICAgICAgICB0Lm5vbk51bGwuc3RyaW5nKCdjYXJkTnVtYmVyJyk7XG4gICAgICAgIHQubm9uTnVsbC5zdHJpbmcoJ2NhcmRQcm92aWRlcicpO1xuICAgIH0sXG59KTtcbmNvbnN0IERlbGV0ZUZ1ZWxDYXJkSW5wdXQgPSAoMCwgbmV4dXNfMS5pbnB1dE9iamVjdFR5cGUpKHtcbiAgICBuYW1lOiAnRGVsZXRlRnVlbENhcmRJbnB1dCcsXG4gICAgZGVmaW5pdGlvbih0KSB7XG4gICAgICAgIHQubm9uTnVsbC5pZCgnaWQnKTtcbiAgICB9LFxufSk7XG5leHBvcnRzLkZ1ZWxDYXJkTXV0YXRpb24gPSAoMCwgbmV4dXNfMS5leHRlbmRUeXBlKSh7XG4gICAgdHlwZTogJ011dGF0aW9uJyxcbiAgICBkZWZpbml0aW9uKHQpIHtcbiAgICAgICAgdC5ub25OdWxsLmZpZWxkKCdhZGRGdWVsQ2FyZCcsIHtcbiAgICAgICAgICAgIHR5cGU6IGV4cG9ydHMuRnVlbENhcmQsXG4gICAgICAgICAgICBhcmdzOiB7XG4gICAgICAgICAgICAgICAgZGF0YTogKDAsIG5leHVzXzEubm9uTnVsbCkoKDAsIG5leHVzXzEuYXJnKSh7XG4gICAgICAgICAgICAgICAgICAgIHR5cGU6IEFkZEZ1ZWxDYXJkSW5wdXQsXG4gICAgICAgICAgICAgICAgfSkpLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHJlc29sdmU6IGFzeW5jIChfLCBhcmdzLCBjb250ZXh0KSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgdXNlcklkID0gKDAsIGdldFVzZXJJZF8xLmdldFVzZXJJZCkoY29udGV4dCk7XG4gICAgICAgICAgICAgICAgaWYgKCF1c2VySWQpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdVbmFibGUgdG8gYWRkIGZ1ZWwgY2FyZC4gWW91IGFyZSBub3QgbG9nZ2VkIGluLicpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjb25zdCBvcmdhbmlzYXRpb24gPSBhd2FpdCBjb250ZXh0LnByaXNtYS51c2VyXG4gICAgICAgICAgICAgICAgICAgIC5maW5kVW5pcXVlKHtcbiAgICAgICAgICAgICAgICAgICAgd2hlcmU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkOiB1c2VySWQgIT0gbnVsbCA/IHVzZXJJZCA6IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAub3JnYW5pc2F0aW9uKCk7XG4gICAgICAgICAgICAgICAgY29uc3QgZXhpc3RpbmdDYXJkID0gYXdhaXQgY29udGV4dC5wcmlzbWEuZnVlbENhcmQuZmluZFVuaXF1ZSh7XG4gICAgICAgICAgICAgICAgICAgIHdoZXJlOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjYXJkTnVtYmVyOiBhcmdzLmRhdGEuY2FyZE51bWJlcixcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICBpZiAoZXhpc3RpbmdDYXJkKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignQ2FyZCBhbHJlYWR5IGV4aXN0cyB3aXRoIHRoaXMgcmVnaXN0cmF0aW9uJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiBjb250ZXh0LnByaXNtYS5mdWVsQ2FyZC5jcmVhdGUoe1xuICAgICAgICAgICAgICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjYXJkTnVtYmVyOiBhcmdzLmRhdGEuY2FyZE51bWJlcixcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhcmRQcm92aWRlcjogYXJncy5kYXRhLmNhcmRQcm92aWRlcixcbiAgICAgICAgICAgICAgICAgICAgICAgIG9yZ2FuaXNhdGlvbjoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbm5lY3Q6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IG9yZ2FuaXNhdGlvbiA9PT0gbnVsbCB8fCBvcmdhbmlzYXRpb24gPT09IHZvaWQgMCA/IHZvaWQgMCA6IG9yZ2FuaXNhdGlvbi5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICB0Lm5vbk51bGwuZmllbGQoJ3VwZGF0ZUZ1ZWxDYXJkJywge1xuICAgICAgICAgICAgdHlwZTogZXhwb3J0cy5GdWVsQ2FyZCxcbiAgICAgICAgICAgIGFyZ3M6IHtcbiAgICAgICAgICAgICAgICBkYXRhOiAoMCwgbmV4dXNfMS5ub25OdWxsKSgoMCwgbmV4dXNfMS5hcmcpKHtcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogVXBkYXRlRnVlbENhcmRJbnB1dCxcbiAgICAgICAgICAgICAgICB9KSksXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcmVzb2x2ZTogYXN5bmMgKF8sIGFyZ3MsIGNvbnRleHQpID0+IHtcbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gY29udGV4dC5wcmlzbWEuZnVlbENhcmQudXBkYXRlKHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHdoZXJlOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IGFyZ3MuZGF0YS5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FyZE51bWJlcjogYXJncy5kYXRhLmNhcmROdW1iZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FyZFByb3ZpZGVyOiBhcmdzLmRhdGEuY2FyZFByb3ZpZGVyLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0Vycm9yIHVwZGF0aW5nIGZ1ZWwgY2FyZCcpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICB0Lm5vbk51bGwuZmllbGQoJ2RlbGV0ZUZ1ZWxDYXJkJywge1xuICAgICAgICAgICAgdHlwZTogZXhwb3J0cy5GdWVsQ2FyZCxcbiAgICAgICAgICAgIGFyZ3M6IHtcbiAgICAgICAgICAgICAgICBkYXRhOiAoMCwgbmV4dXNfMS5ub25OdWxsKSgoMCwgbmV4dXNfMS5hcmcpKHtcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogRGVsZXRlRnVlbENhcmRJbnB1dCxcbiAgICAgICAgICAgICAgICB9KSksXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcmVzb2x2ZTogKF8sIGFyZ3MsIGNvbnRleHQpID0+IHtcbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gY29udGV4dC5wcmlzbWEuZnVlbENhcmQuZGVsZXRlKHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHdoZXJlOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IGFyZ3MuZGF0YS5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdFcnJvciBkZWxldGluZyBmdWVsIGNhcmQnKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9LFxufSk7XG4iLCJcInVzZSBzdHJpY3RcIjtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbmV4cG9ydHMuSW5mcmluZ2VtZW50TXV0YXRpb24gPSBleHBvcnRzLlVzZXJRdWVyeSA9IHZvaWQgMDtcbmNvbnN0IG5leHVzXzEgPSByZXF1aXJlKFwibmV4dXNcIik7XG5jb25zdCBnZXRVc2VySWRfMSA9IHJlcXVpcmUoXCIuLi91dGlsaXRpZXMvZ2V0VXNlcklkXCIpO1xuY29uc3QgRW51bV8xID0gcmVxdWlyZShcIi4vRW51bVwiKTtcbmNvbnN0IFVzZXJfMSA9IHJlcXVpcmUoXCIuL1VzZXJcIik7XG5jb25zdCBJbmZyaW5nZW1lbnQgPSAoMCwgbmV4dXNfMS5vYmplY3RUeXBlKSh7XG4gICAgbmFtZTogJ0luZnJpbmdlbWVudCcsXG4gICAgZGVmaW5pdGlvbih0KSB7XG4gICAgICAgIHQubm9uTnVsbC5pZCgnaWQnKTtcbiAgICAgICAgdC5ub25OdWxsLnN0cmluZygnZGVzY3JpcHRpb24nKTtcbiAgICAgICAgdC5ub25OdWxsLmRhdGUoJ2RhdGVPY2N1cmVkJyk7XG4gICAgICAgIHQubm9uTnVsbC5maWVsZCgnc3RhdHVzJywge1xuICAgICAgICAgICAgdHlwZTogRW51bV8xLkluZnJpbmdlbWVudFN0YXR1cyxcbiAgICAgICAgfSk7XG4gICAgICAgIHQuZmllbGQoJ2RyaXZlcicsIHtcbiAgICAgICAgICAgIHR5cGU6IFVzZXJfMS5Vc2Vyc1BheWxvYWQsXG4gICAgICAgICAgICByZXNvbHZlKHBhcmVudCwgXywgY29udGV4dCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBjb250ZXh0LnByaXNtYS5pbmZyaW5nZW1lbnRcbiAgICAgICAgICAgICAgICAgICAgLmZpbmRVbmlxdWUoe1xuICAgICAgICAgICAgICAgICAgICB3aGVyZTogeyBpZDogcGFyZW50LmlkIH0sXG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgLmRyaXZlcih7XG4gICAgICAgICAgICAgICAgICAgIHNlbGVjdDoge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgZW1haWw6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICByb2xlOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgZGVwb3Q6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBpbmZyaW5nZW1lbnRzOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgcGFzc3dvcmQ6IGZhbHNlLFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfSxcbn0pO1xuY29uc3QgQWRkSW5mcmluZ2VtZW50SW5wdXQgPSAoMCwgbmV4dXNfMS5pbnB1dE9iamVjdFR5cGUpKHtcbiAgICBuYW1lOiAnQWRkSW5mcmluZ2VtZW50SW5wdXQnLFxuICAgIGRlZmluaXRpb24odCkge1xuICAgICAgICB0Lm5vbk51bGwuaWQoJ2RyaXZlcklkJyk7XG4gICAgICAgIHQubm9uTnVsbC5zdHJpbmcoJ2Rlc2NyaXB0aW9uJyk7XG4gICAgICAgIHQubm9uTnVsbC5kYXRlKCdkYXRlT2NjdXJlZCcpO1xuICAgIH0sXG59KTtcbmNvbnN0IFVwZGF0ZUluZnJpbmdlbWVudElucHV0ID0gKDAsIG5leHVzXzEuaW5wdXRPYmplY3RUeXBlKSh7XG4gICAgbmFtZTogJ1VwZGF0ZUluZnJpbmdlbWVudElucHV0JyxcbiAgICBkZWZpbml0aW9uKHQpIHtcbiAgICAgICAgdC5ub25OdWxsLmlkKCdpZCcpO1xuICAgICAgICB0Lm5vbk51bGwuc3RyaW5nKCdkZXNjcmlwdGlvbicpO1xuICAgICAgICB0Lm5vbk51bGwuZGF0ZSgnZGF0ZU9jY3VyZWQnKTtcbiAgICAgICAgdC5ub25OdWxsLmZpZWxkKCdzdGF0dXMnLCB7IHR5cGU6IEVudW1fMS5JbmZyaW5nZW1lbnRTdGF0dXMgfSk7XG4gICAgfSxcbn0pO1xuY29uc3QgRGVsZXRlSW5mcmluZ2VtZW50SW5wdXQgPSAoMCwgbmV4dXNfMS5pbnB1dE9iamVjdFR5cGUpKHtcbiAgICBuYW1lOiAnRGVsZXRlSW5mcmluZ2VtZW50SW5wdXQnLFxuICAgIGRlZmluaXRpb24odCkge1xuICAgICAgICB0Lm5vbk51bGwuaWQoJ2lkJyk7XG4gICAgfSxcbn0pO1xuY29uc3QgVXBkYXRlSW5mcmluZ2VtZW50U3Rhc3VzSW5wdXQgPSAoMCwgbmV4dXNfMS5pbnB1dE9iamVjdFR5cGUpKHtcbiAgICBuYW1lOiAnVXBkYXRlSW5mcmluZ2VtZW50U3Rhc3VzSW5wdXQnLFxuICAgIGRlZmluaXRpb24odCkge1xuICAgICAgICB0Lm5vbk51bGwuc3RyaW5nKCdpZCcpO1xuICAgIH0sXG59KTtcbmV4cG9ydHMuVXNlclF1ZXJ5ID0gKDAsIG5leHVzXzEuZXh0ZW5kVHlwZSkoe1xuICAgIHR5cGU6ICdRdWVyeScsXG4gICAgZGVmaW5pdGlvbih0KSB7XG4gICAgICAgIHQubGlzdC5maWVsZCgnaW5mcmluZ2VtZW50cycsIHtcbiAgICAgICAgICAgIHR5cGU6IEluZnJpbmdlbWVudCxcbiAgICAgICAgICAgIHJlc29sdmU6IGFzeW5jIChfLCBfXywgY29udGV4dCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHVzZXJJZCA9ICgwLCBnZXRVc2VySWRfMS5nZXRVc2VySWQpKGNvbnRleHQpO1xuICAgICAgICAgICAgICAgIGlmICghdXNlcklkKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignVW5hYmxlIHRvIHJldHJpZXZlIGluZnJpbmdlbWVudHMuIFlvdSBhcmUgbm90IGxvZ2dlZCBpbi4nKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIGNvbnRleHQucHJpc21hLmluZnJpbmdlbWVudC5maW5kTWFueSh7XG4gICAgICAgICAgICAgICAgICAgIG9yZGVyQnk6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGVPY2N1cmVkOiAnZGVzYycsXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9LFxufSk7XG5leHBvcnRzLkluZnJpbmdlbWVudE11dGF0aW9uID0gKDAsIG5leHVzXzEuZXh0ZW5kVHlwZSkoe1xuICAgIHR5cGU6ICdNdXRhdGlvbicsXG4gICAgZGVmaW5pdGlvbih0KSB7XG4gICAgICAgIHQubm9uTnVsbC5maWVsZCgnYWRkSW5mcmluZ2VtZW50Jywge1xuICAgICAgICAgICAgdHlwZTogSW5mcmluZ2VtZW50LFxuICAgICAgICAgICAgYXJnczoge1xuICAgICAgICAgICAgICAgIGRhdGE6ICgwLCBuZXh1c18xLm5vbk51bGwpKCgwLCBuZXh1c18xLmFyZykoe1xuICAgICAgICAgICAgICAgICAgICB0eXBlOiBBZGRJbmZyaW5nZW1lbnRJbnB1dCxcbiAgICAgICAgICAgICAgICB9KSksXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcmVzb2x2ZTogYXN5bmMgKF8sIGFyZ3MsIGNvbnRleHQpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCB1c2VySWQgPSAoMCwgZ2V0VXNlcklkXzEuZ2V0VXNlcklkKShjb250ZXh0KTtcbiAgICAgICAgICAgICAgICBpZiAoIXVzZXJJZCkge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1VuYWJsZSB0byBhZGQgZnVlbCBjYXJkLiBZb3UgYXJlIG5vdCBsb2dnZWQgaW4uJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNvbnN0IGRyaXZlciA9IGF3YWl0IGNvbnRleHQucHJpc21hLnVzZXIuZmluZFVuaXF1ZSh7XG4gICAgICAgICAgICAgICAgICAgIHdoZXJlOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZDogYXJncy5kYXRhLmRyaXZlcklkLFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIGlmICghZHJpdmVyKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignVW5hYmxlIHRvIGFkZCBpbmZyaW5nZW1udC4gRHJpdmVyIG5vdCBmb3VuZC4nKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKGRyaXZlci5yb2xlICE9PSAnRFJJVkVSJykge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1VuYWJsZSB0byBhZGQgaW5mcmluZ2VtbnQuIEluZnJpbmdlbWVudHMgY2FuIG9ubHkgYmUgYWRkZWQgdG8gYSBkcml2ZXInKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIGNvbnRleHQucHJpc21hLmluZnJpbmdlbWVudC5jcmVhdGUoe1xuICAgICAgICAgICAgICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogYXJncy5kYXRhLmRlc2NyaXB0aW9uLFxuICAgICAgICAgICAgICAgICAgICAgICAgZGF0ZU9jY3VyZWQ6IGFyZ3MuZGF0YS5kYXRlT2NjdXJlZCxcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0YXR1czogJ1VOU0lHTkVEJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGRyaXZlcjoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbm5lY3Q6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IGFyZ3MuZGF0YS5kcml2ZXJJZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICB0Lm5vbk51bGwuZmllbGQoJ3VwZGF0ZUluZnJpbmdlbWVudCcsIHtcbiAgICAgICAgICAgIHR5cGU6IEluZnJpbmdlbWVudCxcbiAgICAgICAgICAgIGFyZ3M6IHtcbiAgICAgICAgICAgICAgICBkYXRhOiAoMCwgbmV4dXNfMS5ub25OdWxsKSgoMCwgbmV4dXNfMS5hcmcpKHtcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogVXBkYXRlSW5mcmluZ2VtZW50SW5wdXQsXG4gICAgICAgICAgICAgICAgfSkpLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHJlc29sdmU6IGFzeW5jIChfLCBhcmdzLCBjb250ZXh0KSA9PiB7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGNvbnRleHQucHJpc21hLmluZnJpbmdlbWVudC51cGRhdGUoe1xuICAgICAgICAgICAgICAgICAgICAgICAgd2hlcmU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogYXJncy5kYXRhLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGE6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogYXJncy5kYXRhLmRlc2NyaXB0aW9uLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGVPY2N1cmVkOiBhcmdzLmRhdGEuZGF0ZU9jY3VyZWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhdHVzOiBhcmdzLmRhdGEuc3RhdHVzLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0Vycm9yIHVwZGF0aW5nIGluZnJpbmdlbWVudCcpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICB0Lm5vbk51bGwuZmllbGQoJ2RlbGV0ZUluZnJpbmdlbWVudCcsIHtcbiAgICAgICAgICAgIHR5cGU6IEluZnJpbmdlbWVudCxcbiAgICAgICAgICAgIGFyZ3M6IHtcbiAgICAgICAgICAgICAgICBkYXRhOiAoMCwgbmV4dXNfMS5ub25OdWxsKSgoMCwgbmV4dXNfMS5hcmcpKHtcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogRGVsZXRlSW5mcmluZ2VtZW50SW5wdXQsXG4gICAgICAgICAgICAgICAgfSkpLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHJlc29sdmU6IChfLCBhcmdzLCBjb250ZXh0KSA9PiB7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGNvbnRleHQucHJpc21hLmluZnJpbmdlbWVudC5kZWxldGUoe1xuICAgICAgICAgICAgICAgICAgICAgICAgd2hlcmU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogYXJncy5kYXRhLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0Vycm9yIGRlbGV0aW5nIGluZnJpbmdlbWVudCcpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICB0Lm5vbk51bGwuZmllbGQoJ3VwZGF0ZUluZnJpbmdlbWVudFN0YXR1cycsIHtcbiAgICAgICAgICAgIHR5cGU6IEluZnJpbmdlbWVudCxcbiAgICAgICAgICAgIGFyZ3M6IHtcbiAgICAgICAgICAgICAgICBkYXRhOiAoMCwgbmV4dXNfMS5ub25OdWxsKSgoMCwgbmV4dXNfMS5hcmcpKHtcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogVXBkYXRlSW5mcmluZ2VtZW50U3Rhc3VzSW5wdXQsXG4gICAgICAgICAgICAgICAgfSkpLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHJlc29sdmU6IChfLCBhcmdzLCBjb250ZXh0KSA9PiB7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGNvbnRleHQucHJpc21hLmluZnJpbmdlbWVudC51cGRhdGUoe1xuICAgICAgICAgICAgICAgICAgICAgICAgd2hlcmU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogYXJncy5kYXRhLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGE6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGF0dXM6ICdTSUdORUQnLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0Vycm9yIHVwZGF0aW5nIGluZnJpbmdlbWVudHMgc3RhdHVzJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfSxcbn0pO1xuZXhwb3J0cy5kZWZhdWx0ID0gSW5mcmluZ2VtZW50O1xuIiwiXCJ1c2Ugc3RyaWN0XCI7XG52YXIgX19pbXBvcnREZWZhdWx0ID0gKHRoaXMgJiYgdGhpcy5fX2ltcG9ydERlZmF1bHQpIHx8IGZ1bmN0aW9uIChtb2QpIHtcbiAgICByZXR1cm4gKG1vZCAmJiBtb2QuX19lc01vZHVsZSkgPyBtb2QgOiB7IFwiZGVmYXVsdFwiOiBtb2QgfTtcbn07XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG5leHBvcnRzLk9yZ2FuaXNhdGlvbk11dGF0aW9uID0gZXhwb3J0cy5BZGRPcmdhbmlzYXRpb25QYXlsb2FkID0gZXhwb3J0cy5PcmdhbmlzYXRpb25RdWVyeSA9IGV4cG9ydHMuT3JnYW5pc2F0aW9uID0gdm9pZCAwO1xuY29uc3QgYmNyeXB0XzEgPSByZXF1aXJlKFwiYmNyeXB0XCIpO1xuY29uc3QgbmV4dXNfMSA9IHJlcXVpcmUoXCJuZXh1c1wiKTtcbmNvbnN0IERlcG90XzEgPSByZXF1aXJlKFwiLi9EZXBvdFwiKTtcbmNvbnN0IEZ1ZWxDYXJkXzEgPSByZXF1aXJlKFwiLi9GdWVsQ2FyZFwiKTtcbmNvbnN0IFRvbGxUYWdfMSA9IHJlcXVpcmUoXCIuL1RvbGxUYWdcIik7XG5jb25zdCBWZWhpY2xlXzEgPSByZXF1aXJlKFwiLi9WZWhpY2xlXCIpO1xuY29uc3QgVXNlcl8xID0gcmVxdWlyZShcIi4vVXNlclwiKTtcbmNvbnN0IGdlbmVyYXRlQWNjZXNzVG9rZW5fMSA9IF9faW1wb3J0RGVmYXVsdChyZXF1aXJlKFwiLi4vdXRpbGl0aWVzL2dlbmVyYXRlQWNjZXNzVG9rZW5cIikpO1xuY29uc3QgZ2VuZXJhdGVSZWZyZXNoVG9rZW5fMSA9IF9faW1wb3J0RGVmYXVsdChyZXF1aXJlKFwiLi4vdXRpbGl0aWVzL2dlbmVyYXRlUmVmcmVzaFRva2VuXCIpKTtcbmV4cG9ydHMuT3JnYW5pc2F0aW9uID0gKDAsIG5leHVzXzEub2JqZWN0VHlwZSkoe1xuICAgIG5hbWU6ICdPcmdhbmlzYXRpb24nLFxuICAgIGRlZmluaXRpb24odCkge1xuICAgICAgICB0Lm5vbk51bGwuaWQoJ2lkJyk7XG4gICAgICAgIHQubm9uTnVsbC5zdHJpbmcoJ25hbWUnKTtcbiAgICAgICAgdC5ub25OdWxsLmxpc3Qubm9uTnVsbC5maWVsZCgndXNlcnMnLCB7XG4gICAgICAgICAgICB0eXBlOiBVc2VyXzEuVXNlcixcbiAgICAgICAgICAgIHJlc29sdmUocGFyZW50LCBfLCBjb250ZXh0KSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGNvbnRleHQucHJpc21hLm9yZ2FuaXNhdGlvblxuICAgICAgICAgICAgICAgICAgICAuZmluZFVuaXF1ZSh7XG4gICAgICAgICAgICAgICAgICAgIHdoZXJlOiB7IGlkOiBwYXJlbnQuaWQgfSxcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAudXNlcnMoKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICB0Lm5vbk51bGwubGlzdC5ub25OdWxsLmZpZWxkKCd2ZWhpY2xlcycsIHtcbiAgICAgICAgICAgIHR5cGU6IFZlaGljbGVfMS5WZWhpY2xlLFxuICAgICAgICAgICAgcmVzb2x2ZShwYXJlbnQsIF8sIGNvbnRleHQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gY29udGV4dC5wcmlzbWEub3JnYW5pc2F0aW9uXG4gICAgICAgICAgICAgICAgICAgIC5maW5kVW5pcXVlKHtcbiAgICAgICAgICAgICAgICAgICAgd2hlcmU6IHsgaWQ6IHBhcmVudC5pZCB9LFxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgIC52ZWhpY2xlcygpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHQubm9uTnVsbC5saXN0Lm5vbk51bGwuZmllbGQoJ2RlcG90cycsIHtcbiAgICAgICAgICAgIHR5cGU6IERlcG90XzEuRGVwb3QsXG4gICAgICAgICAgICByZXNvbHZlKHBhcmVudCwgXywgY29udGV4dCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBjb250ZXh0LnByaXNtYS5vcmdhbmlzYXRpb25cbiAgICAgICAgICAgICAgICAgICAgLmZpbmRVbmlxdWUoe1xuICAgICAgICAgICAgICAgICAgICB3aGVyZTogeyBpZDogcGFyZW50LmlkIH0sXG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgLmRlcG90cygpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHQubm9uTnVsbC5saXN0Lm5vbk51bGwuZmllbGQoJ2Z1ZWxDYXJkcycsIHtcbiAgICAgICAgICAgIHR5cGU6IEZ1ZWxDYXJkXzEuRnVlbENhcmQsXG4gICAgICAgICAgICByZXNvbHZlKHBhcmVudCwgXywgY29udGV4dCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBjb250ZXh0LnByaXNtYS5vcmdhbmlzYXRpb25cbiAgICAgICAgICAgICAgICAgICAgLmZpbmRVbmlxdWUoe1xuICAgICAgICAgICAgICAgICAgICB3aGVyZTogeyBpZDogcGFyZW50LmlkIH0sXG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgLmZ1ZWxDYXJkcygpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHQubm9uTnVsbC5saXN0Lm5vbk51bGwuZmllbGQoJ3RvbGxUYWdzJywge1xuICAgICAgICAgICAgdHlwZTogVG9sbFRhZ18xLlRvbGxUYWcsXG4gICAgICAgICAgICByZXNvbHZlKHBhcmVudCwgXywgY29udGV4dCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBjb250ZXh0LnByaXNtYS5vcmdhbmlzYXRpb25cbiAgICAgICAgICAgICAgICAgICAgLmZpbmRVbmlxdWUoe1xuICAgICAgICAgICAgICAgICAgICB3aGVyZTogeyBpZDogcGFyZW50LmlkIH0sXG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgLnRvbGxUYWdzKCk7XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9LFxufSk7XG5leHBvcnRzLk9yZ2FuaXNhdGlvblF1ZXJ5ID0gKDAsIG5leHVzXzEuZXh0ZW5kVHlwZSkoe1xuICAgIHR5cGU6ICdRdWVyeScsXG4gICAgZGVmaW5pdGlvbih0KSB7XG4gICAgICAgIC8vIHQuZmllbGQoJ29yZ2FuaXNhdGlvbicsIHtcbiAgICAgICAgLy8gICB0eXBlOiBPcmdhbmlzYXRpb24sXG4gICAgICAgIC8vICAgYXJnczoge1xuICAgICAgICAvLyAgICAgb3JnYW5pc2F0aW9uSWQ6IG5vbk51bGwoaWRBcmcoKSksXG4gICAgICAgIC8vICAgfSxcbiAgICAgICAgLy8gICByZXNvbHZlOiAoXywgeyBvcmdhbmlzYXRpb25JZCB9LCBjb250ZXh0OiBDb250ZXh0KSA9PlxuICAgICAgICAvLyAgICAgY29udGV4dC5wcmlzbWEub3JnYW5pc2F0aW9uLmZpbmRVbmlxdWUoe1xuICAgICAgICAvLyAgICAgICB3aGVyZToge1xuICAgICAgICAvLyAgICAgICAgIGlkOiBvcmdhbmlzYXRpb25JZCxcbiAgICAgICAgLy8gICAgICAgfSxcbiAgICAgICAgLy8gICAgIH0pLFxuICAgICAgICAvLyB9KTtcbiAgICAgICAgLy8gdC5saXN0LmZpZWxkKCd1c2VycycsIHtcbiAgICAgICAgLy8gICB0eXBlOiBVc2VyLFxuICAgICAgICAvLyAgIGFyZ3M6IHtcbiAgICAgICAgLy8gICAgIG9yZ2FuaXNhdGlvbklkOiBub25OdWxsKGlkQXJnKCkpLFxuICAgICAgICAvLyAgIH0sXG4gICAgICAgIC8vICAgcmVzb2x2ZTogKF8sIHsgb3JnYW5pc2F0aW9uSWQgfSwgY29udGV4dDogQ29udGV4dCkgPT5cbiAgICAgICAgLy8gICAgIGNvbnRleHQucHJpc21hLm9yZ2FuaXNhdGlvblxuICAgICAgICAvLyAgICAgICAuZmluZFVuaXF1ZSh7XG4gICAgICAgIC8vICAgICAgICAgd2hlcmU6IHtcbiAgICAgICAgLy8gICAgICAgICAgIGlkOiBvcmdhbmlzYXRpb25JZCxcbiAgICAgICAgLy8gICAgICAgICB9LFxuICAgICAgICAvLyAgICAgICB9KVxuICAgICAgICAvLyAgICAgICAudXNlcnMoKSxcbiAgICAgICAgLy8gfSk7XG4gICAgICAgIC8vIHQubGlzdC5maWVsZCgndmVoaWNsZXMnLCB7XG4gICAgICAgIC8vICAgdHlwZTogVmVoaWNsZSxcbiAgICAgICAgLy8gICBhcmdzOiB7XG4gICAgICAgIC8vICAgICBvcmdhbmlzYXRpb25JZDogbm9uTnVsbChpZEFyZygpKSxcbiAgICAgICAgLy8gICB9LFxuICAgICAgICAvLyAgIHJlc29sdmU6IChfLCB7IG9yZ2FuaXNhdGlvbklkIH0sIGNvbnRleHQ6IENvbnRleHQpID0+XG4gICAgICAgIC8vICAgICBjb250ZXh0LnByaXNtYS5vcmdhbmlzYXRpb25cbiAgICAgICAgLy8gICAgICAgLmZpbmRVbmlxdWUoe1xuICAgICAgICAvLyAgICAgICAgIHdoZXJlOiB7XG4gICAgICAgIC8vICAgICAgICAgICBpZDogb3JnYW5pc2F0aW9uSWQsXG4gICAgICAgIC8vICAgICAgICAgfSxcbiAgICAgICAgLy8gICAgICAgfSlcbiAgICAgICAgLy8gICAgICAgLnZlaGljbGVzKCksXG4gICAgICAgIC8vIH0pO1xuICAgICAgICAvLyB0Lmxpc3QuZmllbGQoJ2RlcG90cycsIHtcbiAgICAgICAgLy8gICB0eXBlOiBEZXBvdCxcbiAgICAgICAgLy8gICBhcmdzOiB7XG4gICAgICAgIC8vICAgICBvcmdhbmlzYXRpb25JZDogbm9uTnVsbChpZEFyZygpKSxcbiAgICAgICAgLy8gICB9LFxuICAgICAgICAvLyAgIHJlc29sdmU6IChfLCB7IG9yZ2FuaXNhdGlvbklkIH0sIGNvbnRleHQ6IENvbnRleHQpID0+XG4gICAgICAgIC8vICAgICBjb250ZXh0LnByaXNtYS5vcmdhbmlzYXRpb25cbiAgICAgICAgLy8gICAgICAgLmZpbmRVbmlxdWUoe1xuICAgICAgICAvLyAgICAgICAgIHdoZXJlOiB7XG4gICAgICAgIC8vICAgICAgICAgICBpZDogb3JnYW5pc2F0aW9uSWQsXG4gICAgICAgIC8vICAgICAgICAgfSxcbiAgICAgICAgLy8gICAgICAgfSlcbiAgICAgICAgLy8gICAgICAgLmRlcG90cygpLFxuICAgICAgICAvLyB9KTtcbiAgICAgICAgLy8gdC5saXN0LmZpZWxkKCdmdWVsQ2FyZHMnLCB7XG4gICAgICAgIC8vICAgdHlwZTogRnVlbENhcmQsXG4gICAgICAgIC8vICAgYXJnczoge1xuICAgICAgICAvLyAgICAgb3JnYW5pc2F0aW9uSWQ6IG5vbk51bGwoaWRBcmcoKSksXG4gICAgICAgIC8vICAgfSxcbiAgICAgICAgLy8gICByZXNvbHZlOiAoXywgeyBvcmdhbmlzYXRpb25JZCB9LCBjb250ZXh0OiBDb250ZXh0KSA9PlxuICAgICAgICAvLyAgICAgY29udGV4dC5wcmlzbWEub3JnYW5pc2F0aW9uXG4gICAgICAgIC8vICAgICAgIC5maW5kVW5pcXVlKHtcbiAgICAgICAgLy8gICAgICAgICB3aGVyZToge1xuICAgICAgICAvLyAgICAgICAgICAgaWQ6IG9yZ2FuaXNhdGlvbklkLFxuICAgICAgICAvLyAgICAgICAgIH0sXG4gICAgICAgIC8vICAgICAgIH0pXG4gICAgICAgIC8vICAgICAgIC5mdWVsQ2FyZHMoKSxcbiAgICAgICAgLy8gfSk7XG4gICAgICAgIC8vIHQubGlzdC5maWVsZCgndG9sbFRhZ3MnLCB7XG4gICAgICAgIC8vICAgdHlwZTogVG9sbFRhZyxcbiAgICAgICAgLy8gICBhcmdzOiB7XG4gICAgICAgIC8vICAgICBvcmdhbmlzYXRpb25JZDogbm9uTnVsbChpZEFyZygpKSxcbiAgICAgICAgLy8gICB9LFxuICAgICAgICAvLyAgIHJlc29sdmU6IChfLCB7IG9yZ2FuaXNhdGlvbklkIH0sIGNvbnRleHQ6IENvbnRleHQpID0+XG4gICAgICAgIC8vICAgICBjb250ZXh0LnByaXNtYS5vcmdhbmlzYXRpb25cbiAgICAgICAgLy8gICAgICAgLmZpbmRVbmlxdWUoe1xuICAgICAgICAvLyAgICAgICAgIHdoZXJlOiB7XG4gICAgICAgIC8vICAgICAgICAgICBpZDogb3JnYW5pc2F0aW9uSWQsXG4gICAgICAgIC8vICAgICAgICAgfSxcbiAgICAgICAgLy8gICAgICAgfSlcbiAgICAgICAgLy8gICAgICAgLnRvbGxUYWdzKCksXG4gICAgICAgIC8vIH0pO1xuICAgIH0sXG59KTtcbmNvbnN0IEFkZE9yZ2FuaXNhdGlvbklucHV0ID0gKDAsIG5leHVzXzEuaW5wdXRPYmplY3RUeXBlKSh7XG4gICAgbmFtZTogJ0FkZE9yZ2FuaXNhdGlvbklucHV0JyxcbiAgICBkZWZpbml0aW9uKHQpIHtcbiAgICAgICAgdC5ub25OdWxsLnN0cmluZygnbmFtZScpO1xuICAgICAgICB0Lm5vbk51bGwuc3RyaW5nKCdhZG1pbk5hbWUnKTtcbiAgICAgICAgdC5ub25OdWxsLnN0cmluZygnZW1haWwnKTtcbiAgICAgICAgdC5ub25OdWxsLnN0cmluZygncGFzc3dvcmQnKTtcbiAgICB9LFxufSk7XG5leHBvcnRzLkFkZE9yZ2FuaXNhdGlvblBheWxvYWQgPSAoMCwgbmV4dXNfMS5vYmplY3RUeXBlKSh7XG4gICAgbmFtZTogJ0FkZE9yZ2FuaXNhdGlvblBheWxvYWQnLFxuICAgIGRlZmluaXRpb24odCkge1xuICAgICAgICB0LmZpZWxkKCdvcmdhbmlzYXRpb24nLCB7XG4gICAgICAgICAgICB0eXBlOiBleHBvcnRzLk9yZ2FuaXNhdGlvbixcbiAgICAgICAgfSk7XG4gICAgICAgIHQuZmllbGQoJ3VzZXInLCB7XG4gICAgICAgICAgICB0eXBlOiBVc2VyXzEuVXNlcnNQYXlsb2FkLFxuICAgICAgICB9KTtcbiAgICAgICAgdC5ub25OdWxsLnN0cmluZygnYWNjZXNzVG9rZW4nKTtcbiAgICB9LFxufSk7XG5leHBvcnRzLk9yZ2FuaXNhdGlvbk11dGF0aW9uID0gKDAsIG5leHVzXzEuZXh0ZW5kVHlwZSkoe1xuICAgIHR5cGU6ICdNdXRhdGlvbicsXG4gICAgZGVmaW5pdGlvbih0KSB7XG4gICAgICAgIHQubm9uTnVsbC5maWVsZCgnYWRkT3JnYW5pc2F0aW9uJywge1xuICAgICAgICAgICAgdHlwZTogZXhwb3J0cy5BZGRPcmdhbmlzYXRpb25QYXlsb2FkLFxuICAgICAgICAgICAgYXJnczoge1xuICAgICAgICAgICAgICAgIGRhdGE6ICgwLCBuZXh1c18xLm5vbk51bGwpKCgwLCBuZXh1c18xLmFyZykoe1xuICAgICAgICAgICAgICAgICAgICB0eXBlOiBBZGRPcmdhbmlzYXRpb25JbnB1dCxcbiAgICAgICAgICAgICAgICB9KSksXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcmVzb2x2ZTogYXN5bmMgKF8sIGFyZ3MsIGNvbnRleHQpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBleGlzdGluZ1VzZXIgPSBhd2FpdCBjb250ZXh0LnByaXNtYS51c2VyLmZpbmRVbmlxdWUoe1xuICAgICAgICAgICAgICAgICAgICB3aGVyZToge1xuICAgICAgICAgICAgICAgICAgICAgICAgZW1haWw6IGFyZ3MuZGF0YS5lbWFpbCxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICBpZiAoZXhpc3RpbmdVc2VyKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignRVJST1I6IEFjY291bnQgYWxyZWFkeSBleGlzdHMgd2l0aCB0aGlzIGVtYWlsJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNvbnN0IGhhc2hlZFBhc3N3b3JkID0gYXdhaXQgKDAsIGJjcnlwdF8xLmhhc2gpKGFyZ3MuZGF0YS5wYXNzd29yZCwgMTApO1xuICAgICAgICAgICAgICAgIGNvbnN0IG9yZ2FuaXNhdGlvbiA9IGF3YWl0IGNvbnRleHQucHJpc21hLm9yZ2FuaXNhdGlvbi5jcmVhdGUoe1xuICAgICAgICAgICAgICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiBhcmdzLmRhdGEubmFtZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHVzZXJzOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY3JlYXRlOiBbXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6IGFyZ3MuZGF0YS5hZG1pbk5hbWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbWFpbDogYXJncy5kYXRhLmVtYWlsLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFzc3dvcmQ6IGhhc2hlZFBhc3N3b3JkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcm9sZTogJ0FETUlOJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICBjb25zdCB1c2VyID0gYXdhaXQgY29udGV4dC5wcmlzbWEudXNlci5maW5kVW5pcXVlKHtcbiAgICAgICAgICAgICAgICAgICAgd2hlcmU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGVtYWlsOiBhcmdzLmRhdGEuZW1haWwsXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIHNlbGVjdDoge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgZW1haWw6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICByb2xlOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgZGVwb3Q6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBpbmZyaW5nZW1lbnRzOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgcGFzc3dvcmQ6IGZhbHNlLFxuICAgICAgICAgICAgICAgICAgICAgICAgb3JnYW5pc2F0aW9uOiBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICBpZiAoIXVzZXIpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdFcnJvcicpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjb25zdCBhY2Nlc3NUb2tlbiA9ICgwLCBnZW5lcmF0ZUFjY2Vzc1Rva2VuXzEuZGVmYXVsdCkodXNlci5pZCk7XG4gICAgICAgICAgICAgICAgY29uc3QgcmVmcmVzaFRva2VuID0gKDAsIGdlbmVyYXRlUmVmcmVzaFRva2VuXzEuZGVmYXVsdCkodXNlci5pZCk7XG4gICAgICAgICAgICAgICAgY29udGV4dC5yZXMuY29va2llKCdyZWZyZXNoVG9rZW4nLCByZWZyZXNoVG9rZW4sIHtcbiAgICAgICAgICAgICAgICAgICAgaHR0cE9ubHk6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgIHNlY3VyZTogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgc2FtZVNpdGU6ICdzdHJpY3QnLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgIG9yZ2FuaXNhdGlvbixcbiAgICAgICAgICAgICAgICAgICAgdXNlcixcbiAgICAgICAgICAgICAgICAgICAgYWNjZXNzVG9rZW4sXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH0sXG59KTtcbiIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuZXhwb3J0cy5Ub2xsVGFnTXV0YXRpb24gPSBleHBvcnRzLlRvbGxUYWdRdWVyeSA9IGV4cG9ydHMuVG9sbFRhZyA9IHZvaWQgMDtcbmNvbnN0IG5leHVzXzEgPSByZXF1aXJlKFwibmV4dXNcIik7XG5jb25zdCBnZXRVc2VySWRfMSA9IHJlcXVpcmUoXCIuLi91dGlsaXRpZXMvZ2V0VXNlcklkXCIpO1xuY29uc3QgT3JnYW5pc2F0aW9uXzEgPSByZXF1aXJlKFwiLi9PcmdhbmlzYXRpb25cIik7XG5jb25zdCBWZWhpY2xlXzEgPSByZXF1aXJlKFwiLi9WZWhpY2xlXCIpO1xuZXhwb3J0cy5Ub2xsVGFnID0gKDAsIG5leHVzXzEub2JqZWN0VHlwZSkoe1xuICAgIG5hbWU6ICdUb2xsVGFnJyxcbiAgICBkZWZpbml0aW9uKHQpIHtcbiAgICAgICAgdC5ub25OdWxsLmlkKCdpZCcpO1xuICAgICAgICB0Lm5vbk51bGwuc3RyaW5nKCd0YWdOdW1iZXInKTtcbiAgICAgICAgdC5ub25OdWxsLnN0cmluZygndGFnUHJvdmlkZXInKTtcbiAgICAgICAgdC5ub25OdWxsLmZpZWxkKCdvcmdhbmlzYXRpb24nLCB7XG4gICAgICAgICAgICB0eXBlOiBPcmdhbmlzYXRpb25fMS5PcmdhbmlzYXRpb24sXG4gICAgICAgICAgICByZXNvbHZlOiBhc3luYyAocGFyZW50LCBfLCBjb250ZXh0KSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3Qgb3JnYW5pc2F0aW9uID0gYXdhaXQgY29udGV4dC5wcmlzbWEudG9sbFRhZ1xuICAgICAgICAgICAgICAgICAgICAuZmluZFVuaXF1ZSh7XG4gICAgICAgICAgICAgICAgICAgIHdoZXJlOiB7IGlkOiBwYXJlbnQuaWQgfSxcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAub3JnYW5pc2F0aW9uKCk7XG4gICAgICAgICAgICAgICAgaWYgKCFvcmdhbmlzYXRpb24pIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdPcmdhbmlzYXRpb24gbm90IGZvdW5kJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiBvcmdhbmlzYXRpb247XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgdC5maWVsZCgndmVoaWNsZScsIHtcbiAgICAgICAgICAgIHR5cGU6IFZlaGljbGVfMS5WZWhpY2xlLFxuICAgICAgICAgICAgcmVzb2x2ZShwYXJlbnQsIF8sIGNvbnRleHQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gY29udGV4dC5wcmlzbWEudG9sbFRhZ1xuICAgICAgICAgICAgICAgICAgICAuZmluZFVuaXF1ZSh7XG4gICAgICAgICAgICAgICAgICAgIHdoZXJlOiB7IGlkOiBwYXJlbnQuaWQgfSxcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAudmVoaWNsZSgpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfSxcbn0pO1xuY29uc3QgVG9sbFRhZ0lucHV0RmlsdGVyID0gKDAsIG5leHVzXzEuaW5wdXRPYmplY3RUeXBlKSh7XG4gICAgbmFtZTogJ1RvbGxUYWdJbnB1dEZpbHRlcicsXG4gICAgZGVmaW5pdGlvbih0KSB7XG4gICAgICAgIHQuc3RyaW5nKCdzZWFyY2hDcml0ZXJpYScpO1xuICAgIH0sXG59KTtcbmV4cG9ydHMuVG9sbFRhZ1F1ZXJ5ID0gKDAsIG5leHVzXzEuZXh0ZW5kVHlwZSkoe1xuICAgIHR5cGU6ICdRdWVyeScsXG4gICAgZGVmaW5pdGlvbih0KSB7XG4gICAgICAgIHQubGlzdC5maWVsZCgndG9sbFRhZ3MnLCB7XG4gICAgICAgICAgICB0eXBlOiBleHBvcnRzLlRvbGxUYWcsXG4gICAgICAgICAgICBhcmdzOiB7XG4gICAgICAgICAgICAgICAgZGF0YTogKDAsIG5leHVzXzEuYXJnKSh7XG4gICAgICAgICAgICAgICAgICAgIHR5cGU6IFRvbGxUYWdJbnB1dEZpbHRlcixcbiAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICByZXNvbHZlOiBhc3luYyAoXywgYXJncywgY29udGV4dCkgPT4ge1xuICAgICAgICAgICAgICAgIHZhciBfYTtcbiAgICAgICAgICAgICAgICBjb25zdCB1c2VySWQgPSAoMCwgZ2V0VXNlcklkXzEuZ2V0VXNlcklkKShjb250ZXh0KTtcbiAgICAgICAgICAgICAgICBpZiAoIXVzZXJJZCkge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1VuYWJsZSB0byByZXRyaWV2ZSB0b2xsIHRhZ3MuIFlvdSBhcmUgbm90IGxvZ2dlZCBpbi4nKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY29uc3Qgb3JnYW5pc2F0aW9uID0gYXdhaXQgY29udGV4dC5wcmlzbWEudXNlclxuICAgICAgICAgICAgICAgICAgICAuZmluZFVuaXF1ZSh7XG4gICAgICAgICAgICAgICAgICAgIHdoZXJlOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZDogdXNlcklkICE9IG51bGwgPyB1c2VySWQgOiB1bmRlZmluZWQsXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgLm9yZ2FuaXNhdGlvbigpO1xuICAgICAgICAgICAgICAgIHJldHVybiBjb250ZXh0LnByaXNtYS50b2xsVGFnLmZpbmRNYW55KHtcbiAgICAgICAgICAgICAgICAgICAgd2hlcmU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIEFORDogW1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgb3JnYW5pc2F0aW9uSWQ6IG9yZ2FuaXNhdGlvbiA9PT0gbnVsbCB8fCBvcmdhbmlzYXRpb24gPT09IHZvaWQgMCA/IHZvaWQgMCA6IG9yZ2FuaXNhdGlvbi5pZCB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGFnTnVtYmVyOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250YWluczogKChfYSA9IGFyZ3MuZGF0YSkgPT09IG51bGwgfHwgX2EgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9hLnNlYXJjaENyaXRlcmlhKSAhPSBudWxsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBhcmdzLmRhdGEuc2VhcmNoQ3JpdGVyaWFcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1vZGU6ICdpbnNlbnNpdGl2ZScsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIG9yZGVyQnk6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRhZ051bWJlcjogJ2FzYycsXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgdC5saXN0LmZpZWxkKCd0b2xsVGFnc05vdEFzc2lnbmVkJywge1xuICAgICAgICAgICAgdHlwZTogZXhwb3J0cy5Ub2xsVGFnLFxuICAgICAgICAgICAgcmVzb2x2ZTogYXN5bmMgKF8sIF9fLCBjb250ZXh0KSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgdXNlcklkID0gKDAsIGdldFVzZXJJZF8xLmdldFVzZXJJZCkoY29udGV4dCk7XG4gICAgICAgICAgICAgICAgaWYgKCF1c2VySWQpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdVbmFibGUgdG8gcmV0cmlldmUgdW5hc3NpZ25lZCB0b2xsIHRhZ3MuIFlvdSBhcmUgbm90IGxvZ2dlZCBpbi4nKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY29uc3Qgb3JnYW5pc2F0aW9uID0gYXdhaXQgY29udGV4dC5wcmlzbWEudXNlclxuICAgICAgICAgICAgICAgICAgICAuZmluZFVuaXF1ZSh7XG4gICAgICAgICAgICAgICAgICAgIHdoZXJlOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZDogdXNlcklkICE9IG51bGwgPyB1c2VySWQgOiB1bmRlZmluZWQsXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgLm9yZ2FuaXNhdGlvbigpO1xuICAgICAgICAgICAgICAgIHJldHVybiBjb250ZXh0LnByaXNtYS50b2xsVGFnLmZpbmRNYW55KHtcbiAgICAgICAgICAgICAgICAgICAgd2hlcmU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIEFORDogW3sgdmVoaWNsZUlkOiBudWxsIH0sIHsgb3JnYW5pc2F0aW9uSWQ6IG9yZ2FuaXNhdGlvbiA9PT0gbnVsbCB8fCBvcmdhbmlzYXRpb24gPT09IHZvaWQgMCA/IHZvaWQgMCA6IG9yZ2FuaXNhdGlvbi5pZCB9XSxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgb3JkZXJCeToge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGFnTnVtYmVyOiAnYXNjJyxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH0sXG59KTtcbmNvbnN0IEFkZFRvbGxUYWdJbnB1dCA9ICgwLCBuZXh1c18xLmlucHV0T2JqZWN0VHlwZSkoe1xuICAgIG5hbWU6ICdBZGRUb2xsVGFnSW5wdXQnLFxuICAgIGRlZmluaXRpb24odCkge1xuICAgICAgICB0Lm5vbk51bGwuc3RyaW5nKCd0YWdOdW1iZXInKTtcbiAgICAgICAgdC5ub25OdWxsLnN0cmluZygndGFnUHJvdmlkZXInKTtcbiAgICB9LFxufSk7XG5jb25zdCBVcGRhdGVUb2xsVGFnSW5wdXQgPSAoMCwgbmV4dXNfMS5pbnB1dE9iamVjdFR5cGUpKHtcbiAgICBuYW1lOiAnVXBkYXRlVG9sbFRhZ0lucHV0JyxcbiAgICBkZWZpbml0aW9uKHQpIHtcbiAgICAgICAgdC5ub25OdWxsLmlkKCdpZCcpO1xuICAgICAgICB0Lm5vbk51bGwuc3RyaW5nKCd0YWdOdW1iZXInKTtcbiAgICAgICAgdC5ub25OdWxsLnN0cmluZygndGFnUHJvdmlkZXInKTtcbiAgICB9LFxufSk7XG5jb25zdCBEZWxldGVUb2xsVGFnSW5wdXQgPSAoMCwgbmV4dXNfMS5pbnB1dE9iamVjdFR5cGUpKHtcbiAgICBuYW1lOiAnRGVsZXRlVG9sbFRhZ0lucHV0JyxcbiAgICBkZWZpbml0aW9uKHQpIHtcbiAgICAgICAgdC5ub25OdWxsLmlkKCdpZCcpO1xuICAgIH0sXG59KTtcbmV4cG9ydHMuVG9sbFRhZ011dGF0aW9uID0gKDAsIG5leHVzXzEuZXh0ZW5kVHlwZSkoe1xuICAgIHR5cGU6ICdNdXRhdGlvbicsXG4gICAgZGVmaW5pdGlvbih0KSB7XG4gICAgICAgIHQubm9uTnVsbC5maWVsZCgnYWRkVG9sbFRhZycsIHtcbiAgICAgICAgICAgIHR5cGU6IGV4cG9ydHMuVG9sbFRhZyxcbiAgICAgICAgICAgIGFyZ3M6IHtcbiAgICAgICAgICAgICAgICBkYXRhOiAoMCwgbmV4dXNfMS5ub25OdWxsKSgoMCwgbmV4dXNfMS5hcmcpKHtcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogQWRkVG9sbFRhZ0lucHV0LFxuICAgICAgICAgICAgICAgIH0pKSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICByZXNvbHZlOiBhc3luYyAoXywgYXJncywgY29udGV4dCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHVzZXJJZCA9ICgwLCBnZXRVc2VySWRfMS5nZXRVc2VySWQpKGNvbnRleHQpO1xuICAgICAgICAgICAgICAgIGlmICghdXNlcklkKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignVW5hYmxlIHRvIGFkZCB0b2xsIHRhZy4gWW91IGFyZSBub3QgbG9nZ2VkIGluLicpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjb25zdCBvcmdhbmlzYXRpb24gPSBhd2FpdCBjb250ZXh0LnByaXNtYS51c2VyXG4gICAgICAgICAgICAgICAgICAgIC5maW5kVW5pcXVlKHtcbiAgICAgICAgICAgICAgICAgICAgd2hlcmU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkOiB1c2VySWQgIT0gbnVsbCA/IHVzZXJJZCA6IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAub3JnYW5pc2F0aW9uKCk7XG4gICAgICAgICAgICAgICAgY29uc3QgZXhpc3RpbmdUYWcgPSBhd2FpdCBjb250ZXh0LnByaXNtYS50b2xsVGFnLmZpbmRVbmlxdWUoe1xuICAgICAgICAgICAgICAgICAgICB3aGVyZToge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGFnTnVtYmVyOiBhcmdzLmRhdGEudGFnTnVtYmVyLFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIGlmIChleGlzdGluZ1RhZykge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1RhZyBhbHJlYWR5IGV4aXN0cyB3aXRoIHRoaXMgbnVtYmVyJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiBjb250ZXh0LnByaXNtYS50b2xsVGFnLmNyZWF0ZSh7XG4gICAgICAgICAgICAgICAgICAgIGRhdGE6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRhZ051bWJlcjogYXJncy5kYXRhLnRhZ051bWJlcixcbiAgICAgICAgICAgICAgICAgICAgICAgIHRhZ1Byb3ZpZGVyOiBhcmdzLmRhdGEudGFnUHJvdmlkZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICBvcmdhbmlzYXRpb246IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25uZWN0OiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkOiBvcmdhbmlzYXRpb24gPT09IG51bGwgfHwgb3JnYW5pc2F0aW9uID09PSB2b2lkIDAgPyB2b2lkIDAgOiBvcmdhbmlzYXRpb24uaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgdC5ub25OdWxsLmZpZWxkKCd1cGRhdGVUb2xsVGFnJywge1xuICAgICAgICAgICAgdHlwZTogZXhwb3J0cy5Ub2xsVGFnLFxuICAgICAgICAgICAgYXJnczoge1xuICAgICAgICAgICAgICAgIGRhdGE6ICgwLCBuZXh1c18xLm5vbk51bGwpKCgwLCBuZXh1c18xLmFyZykoe1xuICAgICAgICAgICAgICAgICAgICB0eXBlOiBVcGRhdGVUb2xsVGFnSW5wdXQsXG4gICAgICAgICAgICAgICAgfSkpLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHJlc29sdmU6IGFzeW5jIChfLCBhcmdzLCBjb250ZXh0KSA9PiB7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGNvbnRleHQucHJpc21hLnRvbGxUYWcudXBkYXRlKHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHdoZXJlOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IGFyZ3MuZGF0YS5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGFnTnVtYmVyOiBhcmdzLmRhdGEudGFnTnVtYmVyLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRhZ1Byb3ZpZGVyOiBhcmdzLmRhdGEudGFnUHJvdmlkZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignRXJyb3IgdXBkYXRpbmcgdG9sbCB0YWcnKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgdC5ub25OdWxsLmZpZWxkKCdkZWxldGVUb2xsVGFnJywge1xuICAgICAgICAgICAgdHlwZTogZXhwb3J0cy5Ub2xsVGFnLFxuICAgICAgICAgICAgYXJnczoge1xuICAgICAgICAgICAgICAgIGRhdGE6ICgwLCBuZXh1c18xLm5vbk51bGwpKCgwLCBuZXh1c18xLmFyZykoe1xuICAgICAgICAgICAgICAgICAgICB0eXBlOiBEZWxldGVUb2xsVGFnSW5wdXQsXG4gICAgICAgICAgICAgICAgfSkpLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHJlc29sdmU6IChfLCBhcmdzLCBjb250ZXh0KSA9PiB7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGNvbnRleHQucHJpc21hLnRvbGxUYWcuZGVsZXRlKHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHdoZXJlOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IGFyZ3MuZGF0YS5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdFcnJvciBkZWxldGluZyB0b2xsIHRhZycpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH0sXG59KTtcbiIsIlwidXNlIHN0cmljdFwiO1xudmFyIF9faW1wb3J0RGVmYXVsdCA9ICh0aGlzICYmIHRoaXMuX19pbXBvcnREZWZhdWx0KSB8fCBmdW5jdGlvbiAobW9kKSB7XG4gICAgcmV0dXJuIChtb2QgJiYgbW9kLl9fZXNNb2R1bGUpID8gbW9kIDogeyBcImRlZmF1bHRcIjogbW9kIH07XG59O1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuZXhwb3J0cy5Vc2VyTXV0YXRpb24gPSBleHBvcnRzLlVzZXJRdWVyeSA9IGV4cG9ydHMuUmVmcmVzaFRva2VuUGF5bG9hZCA9IGV4cG9ydHMuTG9nb3V0UGF5bG9hZCA9IGV4cG9ydHMuQXV0aFBheWxvYWQgPSBleHBvcnRzLlVzZXJzUGF5bG9hZCA9IGV4cG9ydHMuVXNlciA9IHZvaWQgMDtcbmNvbnN0IG5leHVzXzEgPSByZXF1aXJlKFwibmV4dXNcIik7XG5jb25zdCBiY3J5cHRfMSA9IHJlcXVpcmUoXCJiY3J5cHRcIik7XG5jb25zdCBEZXBvdF8xID0gcmVxdWlyZShcIi4vRGVwb3RcIik7XG5jb25zdCBPcmdhbmlzYXRpb25fMSA9IHJlcXVpcmUoXCIuL09yZ2FuaXNhdGlvblwiKTtcbmNvbnN0IGdldFVzZXJJZF8xID0gcmVxdWlyZShcIi4uL3V0aWxpdGllcy9nZXRVc2VySWRcIik7XG5jb25zdCBjcmVhdGVDb25uZWN0aW9uXzEgPSBfX2ltcG9ydERlZmF1bHQocmVxdWlyZShcIi4uL3V0aWxpdGllcy9jcmVhdGVDb25uZWN0aW9uXCIpKTtcbmNvbnN0IHVwc2VydENvbm5lY3Rpb25fMSA9IF9faW1wb3J0RGVmYXVsdChyZXF1aXJlKFwiLi4vdXRpbGl0aWVzL3Vwc2VydENvbm5lY3Rpb25cIikpO1xuY29uc3QgZ2VuZXJhdGVBY2Nlc3NUb2tlbl8xID0gX19pbXBvcnREZWZhdWx0KHJlcXVpcmUoXCIuLi91dGlsaXRpZXMvZ2VuZXJhdGVBY2Nlc3NUb2tlblwiKSk7XG5jb25zdCBFbnVtXzEgPSByZXF1aXJlKFwiLi9FbnVtXCIpO1xuY29uc3QgSW5mcmluZ2VtZW50XzEgPSBfX2ltcG9ydERlZmF1bHQocmVxdWlyZShcIi4vSW5mcmluZ2VtZW50XCIpKTtcbmNvbnN0IGdlbmVyYXRlUmVmcmVzaFRva2VuXzEgPSBfX2ltcG9ydERlZmF1bHQocmVxdWlyZShcIi4uL3V0aWxpdGllcy9nZW5lcmF0ZVJlZnJlc2hUb2tlblwiKSk7XG5jb25zdCBnZXRSZWZyZXNoVXNlcklkXzEgPSBfX2ltcG9ydERlZmF1bHQocmVxdWlyZShcIi4uL3V0aWxpdGllcy9nZXRSZWZyZXNoVXNlcklkXCIpKTtcbmV4cG9ydHMuVXNlciA9ICgwLCBuZXh1c18xLm9iamVjdFR5cGUpKHtcbiAgICBuYW1lOiAnVXNlcicsXG4gICAgZGVmaW5pdGlvbih0KSB7XG4gICAgICAgIHQubm9uTnVsbC5pZCgnaWQnKTtcbiAgICAgICAgdC5ub25OdWxsLnN0cmluZygnbmFtZScpO1xuICAgICAgICB0Lm5vbk51bGwuc3RyaW5nKCdlbWFpbCcpO1xuICAgICAgICB0Lm5vbk51bGwuc3RyaW5nKCdwYXNzd29yZCcpO1xuICAgICAgICB0Lm5vbk51bGwuZmllbGQoJ3JvbGUnLCB7XG4gICAgICAgICAgICB0eXBlOiBFbnVtXzEuUm9sZSxcbiAgICAgICAgfSk7XG4gICAgICAgIHQubm9uTnVsbC5maWVsZCgnb3JnYW5pc2F0aW9uJywge1xuICAgICAgICAgICAgdHlwZTogT3JnYW5pc2F0aW9uXzEuT3JnYW5pc2F0aW9uLFxuICAgICAgICAgICAgcmVzb2x2ZTogYXN5bmMgKHBhcmVudCwgXywgY29udGV4dCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IG9yZ2FuaXNhdGlvbiA9IGF3YWl0IGNvbnRleHQucHJpc21hLnVzZXJcbiAgICAgICAgICAgICAgICAgICAgLmZpbmRVbmlxdWUoe1xuICAgICAgICAgICAgICAgICAgICB3aGVyZTogeyBpZDogcGFyZW50LmlkIH0sXG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgLm9yZ2FuaXNhdGlvbigpO1xuICAgICAgICAgICAgICAgIGlmICghb3JnYW5pc2F0aW9uKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignT3JnYW5pc2F0aW9uIG5vdCBmb3VuZCcpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gb3JnYW5pc2F0aW9uO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHQuZmllbGQoJ2RlcG90Jywge1xuICAgICAgICAgICAgdHlwZTogRGVwb3RfMS5EZXBvdCxcbiAgICAgICAgICAgIHJlc29sdmUocGFyZW50LCBfLCBjb250ZXh0KSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGNvbnRleHQucHJpc21hLnVzZXJcbiAgICAgICAgICAgICAgICAgICAgLmZpbmRVbmlxdWUoe1xuICAgICAgICAgICAgICAgICAgICB3aGVyZTogeyBpZDogcGFyZW50LmlkIH0sXG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgLmRlcG90KCk7XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgdC5ub25OdWxsLmxpc3Qubm9uTnVsbC5maWVsZCgnaW5mcmluZ2VtZW50cycsIHtcbiAgICAgICAgICAgIHR5cGU6IEluZnJpbmdlbWVudF8xLmRlZmF1bHQsXG4gICAgICAgICAgICByZXNvbHZlKHBhcmVudCwgXywgY29udGV4dCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBjb250ZXh0LnByaXNtYS51c2VyXG4gICAgICAgICAgICAgICAgICAgIC5maW5kVW5pcXVlKHtcbiAgICAgICAgICAgICAgICAgICAgd2hlcmU6IHsgaWQ6IHBhcmVudC5pZCB9LFxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgIC5pbmZyaW5nZW1lbnRzKCk7XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9LFxufSk7XG5leHBvcnRzLlVzZXJzUGF5bG9hZCA9ICgwLCBuZXh1c18xLm9iamVjdFR5cGUpKHtcbiAgICBuYW1lOiAnVXNlcnNQYXlsb2FkJyxcbiAgICBkZWZpbml0aW9uKHQpIHtcbiAgICAgICAgdC5ub25OdWxsLnN0cmluZygnaWQnKTtcbiAgICAgICAgdC5ub25OdWxsLnN0cmluZygnbmFtZScpO1xuICAgICAgICB0Lm5vbk51bGwuc3RyaW5nKCdlbWFpbCcpO1xuICAgICAgICB0Lm5vbk51bGwuZmllbGQoJ3JvbGUnLCB7IHR5cGU6IEVudW1fMS5Sb2xlIH0pO1xuICAgICAgICB0LmZpZWxkKCdkZXBvdCcsIHtcbiAgICAgICAgICAgIHR5cGU6IERlcG90XzEuRGVwb3QsXG4gICAgICAgIH0pO1xuICAgICAgICB0Lm5vbk51bGwubGlzdC5ub25OdWxsLmZpZWxkKCdpbmZyaW5nZW1lbnRzJywge1xuICAgICAgICAgICAgdHlwZTogSW5mcmluZ2VtZW50XzEuZGVmYXVsdCxcbiAgICAgICAgfSk7XG4gICAgfSxcbn0pO1xuZXhwb3J0cy5BdXRoUGF5bG9hZCA9ICgwLCBuZXh1c18xLm9iamVjdFR5cGUpKHtcbiAgICBuYW1lOiAnQXV0aFBheWxvYWQnLFxuICAgIGRlZmluaXRpb24odCkge1xuICAgICAgICB0LmZpZWxkKCd1c2VyJywge1xuICAgICAgICAgICAgdHlwZTogZXhwb3J0cy5Vc2Vyc1BheWxvYWQsXG4gICAgICAgIH0pO1xuICAgICAgICB0Lm5vbk51bGwuc3RyaW5nKCdhY2Nlc3NUb2tlbicpO1xuICAgIH0sXG59KTtcbmV4cG9ydHMuTG9nb3V0UGF5bG9hZCA9ICgwLCBuZXh1c18xLm9iamVjdFR5cGUpKHtcbiAgICBuYW1lOiAnTG9nb3V0UGF5bG9hZCcsXG4gICAgZGVmaW5pdGlvbih0KSB7XG4gICAgICAgIHQubm9uTnVsbC5zdHJpbmcoJ21lc3NhZ2UnKTtcbiAgICB9LFxufSk7XG5leHBvcnRzLlJlZnJlc2hUb2tlblBheWxvYWQgPSAoMCwgbmV4dXNfMS5vYmplY3RUeXBlKSh7XG4gICAgbmFtZTogJ1JlZnJlc2hUb2tlblBheWxvYWQnLFxuICAgIGRlZmluaXRpb24odCkge1xuICAgICAgICB0Lm5vbk51bGwuc3RyaW5nKCdhY2Nlc3NUb2tlbicpO1xuICAgIH0sXG59KTtcbmNvbnN0IExvZ2luSW5wdXQgPSAoMCwgbmV4dXNfMS5pbnB1dE9iamVjdFR5cGUpKHtcbiAgICBuYW1lOiAnTG9naW5JbnB1dCcsXG4gICAgZGVmaW5pdGlvbih0KSB7XG4gICAgICAgIHQubm9uTnVsbC5zdHJpbmcoJ2VtYWlsJyk7XG4gICAgICAgIHQubm9uTnVsbC5zdHJpbmcoJ3Bhc3N3b3JkJyk7XG4gICAgfSxcbn0pO1xuY29uc3QgVXNlcnNJbnB1dEZpbHRlciA9ICgwLCBuZXh1c18xLmlucHV0T2JqZWN0VHlwZSkoe1xuICAgIG5hbWU6ICdVc2Vyc0lucHV0RmlsdGVyJyxcbiAgICBkZWZpbml0aW9uKHQpIHtcbiAgICAgICAgdC5zdHJpbmcoJ3NlYXJjaENyaXRlcmlhJyk7XG4gICAgfSxcbn0pO1xuY29uc3QgQWRkVXNlcklucHV0ID0gKDAsIG5leHVzXzEuaW5wdXRPYmplY3RUeXBlKSh7XG4gICAgbmFtZTogJ0FkZFVzZXJJbnB1dCcsXG4gICAgZGVmaW5pdGlvbih0KSB7XG4gICAgICAgIHQubm9uTnVsbC5zdHJpbmcoJ2VtYWlsJyk7XG4gICAgICAgIHQubm9uTnVsbC5zdHJpbmcoJ3Bhc3N3b3JkJyk7XG4gICAgICAgIHQubm9uTnVsbC5zdHJpbmcoJ25hbWUnKTtcbiAgICAgICAgdC5ub25OdWxsLnN0cmluZygnZGVwb3RJZCcpO1xuICAgICAgICB0Lm5vbk51bGwuZmllbGQoJ3JvbGUnLCB7IHR5cGU6IEVudW1fMS5Sb2xlIH0pO1xuICAgIH0sXG59KTtcbmNvbnN0IERlbGV0ZVVzZXJJbnB1dCA9ICgwLCBuZXh1c18xLmlucHV0T2JqZWN0VHlwZSkoe1xuICAgIG5hbWU6ICdEZWxldGVVc2VySW5wdXQnLFxuICAgIGRlZmluaXRpb24odCkge1xuICAgICAgICB0Lm5vbk51bGwuaWQoJ2lkJyk7XG4gICAgfSxcbn0pO1xuY29uc3QgVXBkYXRlVXNlcklucHV0ID0gKDAsIG5leHVzXzEuaW5wdXRPYmplY3RUeXBlKSh7XG4gICAgbmFtZTogJ1VwZGF0ZVVzZXJJbnB1dCcsXG4gICAgZGVmaW5pdGlvbih0KSB7XG4gICAgICAgIHQubm9uTnVsbC5pZCgnaWQnKTtcbiAgICAgICAgdC5ub25OdWxsLnN0cmluZygnZW1haWwnKTtcbiAgICAgICAgdC5ub25OdWxsLnN0cmluZygnbmFtZScpO1xuICAgICAgICB0Lm5vbk51bGwuc3RyaW5nKCdkZXBvdElkJyk7XG4gICAgICAgIHQubm9uTnVsbC5maWVsZCgncm9sZScsIHsgdHlwZTogRW51bV8xLlJvbGUgfSk7XG4gICAgfSxcbn0pO1xuZXhwb3J0cy5Vc2VyUXVlcnkgPSAoMCwgbmV4dXNfMS5leHRlbmRUeXBlKSh7XG4gICAgdHlwZTogJ1F1ZXJ5JyxcbiAgICBkZWZpbml0aW9uKHQpIHtcbiAgICAgICAgdC5maWVsZCgndXNlcicsIHtcbiAgICAgICAgICAgIHR5cGU6IGV4cG9ydHMuVXNlcnNQYXlsb2FkLFxuICAgICAgICAgICAgYXJnczoge1xuICAgICAgICAgICAgICAgIHVzZXJJZDogKDAsIG5leHVzXzEubm9uTnVsbCkoKDAsIG5leHVzXzEuaWRBcmcpKCkpLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHJlc29sdmU6IChfLCB7IHVzZXJJZCB9LCBjb250ZXh0KSA9PiB7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGNvbnRleHQucHJpc21hLnVzZXIuZmluZFVuaXF1ZSh7XG4gICAgICAgICAgICAgICAgICAgICAgICB3aGVyZToge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkOiB1c2VySWQsXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgc2VsZWN0OiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZTogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbWFpbDogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByb2xlOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlcG90OiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGluZnJpbmdlbWVudHM6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFzc3dvcmQ6IGZhbHNlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9yZ2FuaXNhdGlvbjogZmFsc2UsXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2F0Y2ggKF9hKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignRXJyb3IgcmV0cmlldmluZyB1c2VyJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHQuZmllbGQoJ21lJywge1xuICAgICAgICAgICAgdHlwZTogZXhwb3J0cy5Vc2Vyc1BheWxvYWQsXG4gICAgICAgICAgICByZXNvbHZlOiAoXywgX18sIGNvbnRleHQpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCB1c2VySWQgPSAoMCwgZ2V0VXNlcklkXzEuZ2V0VXNlcklkKShjb250ZXh0KTtcbiAgICAgICAgICAgICAgICBpZiAoIXVzZXJJZCkge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1VuYWJsZSB0byByZXRyaWV2ZSB5b3VyIGFjY291bnQgaW5mby4gWW91IGFyZSBub3QgbG9nZ2VkIGluLicpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gY29udGV4dC5wcmlzbWEudXNlci5maW5kVW5pcXVlKHtcbiAgICAgICAgICAgICAgICAgICAgd2hlcmU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkOiBTdHJpbmcodXNlcklkKSxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgc2VsZWN0OiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZDogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBlbWFpbDogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHJvbGU6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBkZXBvdDogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGluZnJpbmdlbWVudHM6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBwYXNzd29yZDogZmFsc2UsXG4gICAgICAgICAgICAgICAgICAgICAgICBvcmdhbmlzYXRpb246IGZhbHNlLFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHQubGlzdC5maWVsZCgndXNlcnMnLCB7XG4gICAgICAgICAgICB0eXBlOiBleHBvcnRzLlVzZXJzUGF5bG9hZCxcbiAgICAgICAgICAgIGFyZ3M6IHtcbiAgICAgICAgICAgICAgICBkYXRhOiAoMCwgbmV4dXNfMS5hcmcpKHtcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogVXNlcnNJbnB1dEZpbHRlcixcbiAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICByZXNvbHZlOiBhc3luYyAoXywgYXJncywgY29udGV4dCkgPT4ge1xuICAgICAgICAgICAgICAgIHZhciBfYTtcbiAgICAgICAgICAgICAgICBjb25zdCB1c2VySWQgPSAoMCwgZ2V0VXNlcklkXzEuZ2V0VXNlcklkKShjb250ZXh0KTtcbiAgICAgICAgICAgICAgICBpZiAoIXVzZXJJZCkge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1VuYWJsZSB0byByZXRyaWV2ZSB1c2Vycy4gWW91IGFyZSBub3QgbG9nZ2VkIGluLicpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjb25zdCBvcmdhbmlzYXRpb24gPSBhd2FpdCBjb250ZXh0LnByaXNtYS51c2VyXG4gICAgICAgICAgICAgICAgICAgIC5maW5kVW5pcXVlKHtcbiAgICAgICAgICAgICAgICAgICAgd2hlcmU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkOiB1c2VySWQgIT0gbnVsbCA/IHVzZXJJZCA6IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAub3JnYW5pc2F0aW9uKCk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGNvbnRleHQucHJpc21hLnVzZXIuZmluZE1hbnkoe1xuICAgICAgICAgICAgICAgICAgICB3aGVyZToge1xuICAgICAgICAgICAgICAgICAgICAgICAgQU5EOiBbXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBvcmdhbmlzYXRpb25JZDogb3JnYW5pc2F0aW9uID09PSBudWxsIHx8IG9yZ2FuaXNhdGlvbiA9PT0gdm9pZCAwID8gdm9pZCAwIDogb3JnYW5pc2F0aW9uLmlkIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb2xlOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBub3Q6ICdBRE1JTicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRhaW5zOiAoKF9hID0gYXJncy5kYXRhKSA9PT0gbnVsbCB8fCBfYSA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2Euc2VhcmNoQ3JpdGVyaWEpICE9IG51bGxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IGFyZ3MuZGF0YS5zZWFyY2hDcml0ZXJpYVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbW9kZTogJ2luc2Vuc2l0aXZlJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgc2VsZWN0OiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZDogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBlbWFpbDogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHJvbGU6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBkZXBvdDogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGluZnJpbmdlbWVudHM6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBwYXNzd29yZDogZmFsc2UsXG4gICAgICAgICAgICAgICAgICAgICAgICBvcmdhbmlzYXRpb246IGZhbHNlLFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICBvcmRlckJ5OiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiAnYXNjJyxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICB0Lm5vbk51bGwubGlzdC5ub25OdWxsLmZpZWxkKCdkcml2ZXJzJywge1xuICAgICAgICAgICAgdHlwZTogZXhwb3J0cy5Vc2Vyc1BheWxvYWQsXG4gICAgICAgICAgICByZXNvbHZlOiBhc3luYyAoXywgX18sIGNvbnRleHQpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCB1c2VySWQgPSAoMCwgZ2V0VXNlcklkXzEuZ2V0VXNlcklkKShjb250ZXh0KTtcbiAgICAgICAgICAgICAgICBpZiAoIXVzZXJJZCkge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1VuYWJsZSB0byByZXRyaWV2ZSB1c2Vycy4gWW91IGFyZSBub3QgbG9nZ2VkIGluLicpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjb25zdCBvcmdhbmlzYXRpb24gPSBhd2FpdCBjb250ZXh0LnByaXNtYS51c2VyXG4gICAgICAgICAgICAgICAgICAgIC5maW5kVW5pcXVlKHtcbiAgICAgICAgICAgICAgICAgICAgd2hlcmU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkOiB1c2VySWQgIT0gbnVsbCA/IHVzZXJJZCA6IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAub3JnYW5pc2F0aW9uKCk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGNvbnRleHQucHJpc21hLnVzZXIuZmluZE1hbnkoe1xuICAgICAgICAgICAgICAgICAgICB3aGVyZToge1xuICAgICAgICAgICAgICAgICAgICAgICAgQU5EOiBbXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBvcmdhbmlzYXRpb25JZDogb3JnYW5pc2F0aW9uID09PSBudWxsIHx8IG9yZ2FuaXNhdGlvbiA9PT0gdm9pZCAwID8gdm9pZCAwIDogb3JnYW5pc2F0aW9uLmlkIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb2xlOiAnRFJJVkVSJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgc2VsZWN0OiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZDogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBlbWFpbDogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHJvbGU6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBkZXBvdDogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGluZnJpbmdlbWVudHM6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBwYXNzd29yZDogZmFsc2UsXG4gICAgICAgICAgICAgICAgICAgICAgICBvcmdhbmlzYXRpb246IGZhbHNlLFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICBvcmRlckJ5OiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiAnYXNjJyxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH0sXG59KTtcbmV4cG9ydHMuVXNlck11dGF0aW9uID0gKDAsIG5leHVzXzEuZXh0ZW5kVHlwZSkoe1xuICAgIHR5cGU6ICdNdXRhdGlvbicsXG4gICAgZGVmaW5pdGlvbih0KSB7XG4gICAgICAgIHQubm9uTnVsbC5maWVsZCgnbG9naW4nLCB7XG4gICAgICAgICAgICB0eXBlOiBleHBvcnRzLkF1dGhQYXlsb2FkLFxuICAgICAgICAgICAgYXJnczoge1xuICAgICAgICAgICAgICAgIGRhdGE6ICgwLCBuZXh1c18xLm5vbk51bGwpKCgwLCBuZXh1c18xLmFyZykoe1xuICAgICAgICAgICAgICAgICAgICB0eXBlOiBMb2dpbklucHV0LFxuICAgICAgICAgICAgICAgIH0pKSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICByZXNvbHZlOiBhc3luYyAoXywgYXJncywgY29udGV4dCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHVzZXIgPSBhd2FpdCBjb250ZXh0LnByaXNtYS51c2VyLmZpbmRVbmlxdWUoe1xuICAgICAgICAgICAgICAgICAgICB3aGVyZToge1xuICAgICAgICAgICAgICAgICAgICAgICAgZW1haWw6IGFyZ3MuZGF0YS5lbWFpbCxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgaW5jbHVkZToge1xuICAgICAgICAgICAgICAgICAgICAgICAgZGVwb3Q6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBpbmZyaW5nZW1lbnRzOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIGlmICghdXNlcikge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0VtYWlsIG9yIHBhc3N3b3JkIGlzIGluY29ycmVjdCcpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjb25zdCB2YWxpZCA9IGF3YWl0ICgwLCBiY3J5cHRfMS5jb21wYXJlKShhcmdzLmRhdGEucGFzc3dvcmQsIHVzZXIucGFzc3dvcmQpO1xuICAgICAgICAgICAgICAgIGlmICghdmFsaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdFbWFpbCBvciBwYXNzd29yZCBpcyBpbmNvcnJlY3QnKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY29uc3QgYWNjZXNzVG9rZW4gPSAoMCwgZ2VuZXJhdGVBY2Nlc3NUb2tlbl8xLmRlZmF1bHQpKHVzZXIuaWQpO1xuICAgICAgICAgICAgICAgIGNvbnN0IHJlZnJlc2hUb2tlbiA9ICgwLCBnZW5lcmF0ZVJlZnJlc2hUb2tlbl8xLmRlZmF1bHQpKHVzZXIuaWQpO1xuICAgICAgICAgICAgICAgIGNvbnRleHQucmVzLmNvb2tpZSgncmVmcmVzaFRva2VuJywgcmVmcmVzaFRva2VuLCB7XG4gICAgICAgICAgICAgICAgICAgIGh0dHBPbmx5OiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICBzZWN1cmU6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgIHNhbWVTaXRlOiAnc3RyaWN0JyxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICB1c2VyOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZDogdXNlci5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6IHVzZXIubmFtZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGVtYWlsOiB1c2VyLmVtYWlsLFxuICAgICAgICAgICAgICAgICAgICAgICAgcm9sZTogdXNlci5yb2xlLFxuICAgICAgICAgICAgICAgICAgICAgICAgZGVwb3Q6IHVzZXIuZGVwb3QsXG4gICAgICAgICAgICAgICAgICAgICAgICBpbmZyaW5nZW1lbnRzOiB1c2VyLmluZnJpbmdlbWVudHMsXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIGFjY2Vzc1Rva2VuLFxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgdC5ub25OdWxsLmZpZWxkKCdsb2dvdXQnLCB7XG4gICAgICAgICAgICB0eXBlOiBleHBvcnRzLkxvZ291dFBheWxvYWQsXG4gICAgICAgICAgICByZXNvbHZlOiBhc3luYyAoXywgX18sIGNvbnRleHQpID0+IHtcbiAgICAgICAgICAgICAgICBjb250ZXh0LnJlcy5jb29raWUoJ3JlZnJlc2hUb2tlbicsICcnLCB7XG4gICAgICAgICAgICAgICAgICAgIGh0dHBPbmx5OiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICBzZWN1cmU6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgIHNhbWVTaXRlOiAnc3RyaWN0JyxcbiAgICAgICAgICAgICAgICAgICAgZXhwaXJlczogbmV3IERhdGUoMCksXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogJ0xvZ2dlZCBvdXQgc3VjY2Vzc2Z1bGx5JyxcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHQubm9uTnVsbC5maWVsZCgncmVmcmVzaFRva2VuJywge1xuICAgICAgICAgICAgdHlwZTogZXhwb3J0cy5SZWZyZXNoVG9rZW5QYXlsb2FkLFxuICAgICAgICAgICAgcmVzb2x2ZTogYXN5bmMgKF8sIF9fLCBjb250ZXh0KSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgdXNlcklkID0gKDAsIGdldFJlZnJlc2hVc2VySWRfMS5kZWZhdWx0KShjb250ZXh0KTtcbiAgICAgICAgICAgICAgICBpZiAoIXVzZXJJZCkge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1VzZXIgY291bGQgbm90IGJlIGZvdW5kJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNvbnN0IGFjY2Vzc1Rva2VuID0gKDAsIGdlbmVyYXRlQWNjZXNzVG9rZW5fMS5kZWZhdWx0KSh1c2VySWQpO1xuICAgICAgICAgICAgICAgIGNvbnN0IHJlZnJlc2hUb2tlbiA9ICgwLCBnZW5lcmF0ZVJlZnJlc2hUb2tlbl8xLmRlZmF1bHQpKHVzZXJJZCk7XG4gICAgICAgICAgICAgICAgY29udGV4dC5yZXMuY29va2llKCdyZWZyZXNoVG9rZW4nLCByZWZyZXNoVG9rZW4sIHtcbiAgICAgICAgICAgICAgICAgICAgaHR0cE9ubHk6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgIHNlY3VyZTogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgc2FtZVNpdGU6ICdzdHJpY3QnLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgIGFjY2Vzc1Rva2VuLFxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgLy8gdC5ub25OdWxsLmZpZWxkKCdyZWdpc3RlcicsIHtcbiAgICAgICAgLy8gICB0eXBlOiBBdXRoUGF5bG9hZCxcbiAgICAgICAgLy8gICBhcmdzOiB7XG4gICAgICAgIC8vICAgICBkYXRhOiBub25OdWxsKFxuICAgICAgICAvLyAgICAgICBhcmcoe1xuICAgICAgICAvLyAgICAgICAgIHR5cGU6IFJlZ2lzdGVySW5wdXQsXG4gICAgICAgIC8vICAgICAgIH0pXG4gICAgICAgIC8vICAgICApLFxuICAgICAgICAvLyAgIH0sXG4gICAgICAgIC8vICAgcmVzb2x2ZTogYXN5bmMgKF8sIGFyZ3MsIGNvbnRleHQ6IENvbnRleHQpID0+IHtcbiAgICAgICAgLy8gICAgIGNvbnN0IGV4aXN0aW5nVXNlciA9IGF3YWl0IGNvbnRleHQucHJpc21hLnVzZXIuZmluZFVuaXF1ZSh7XG4gICAgICAgIC8vICAgICAgIHdoZXJlOiB7XG4gICAgICAgIC8vICAgICAgICAgZW1haWw6IGFyZ3MuZGF0YS5lbWFpbCxcbiAgICAgICAgLy8gICAgICAgfSxcbiAgICAgICAgLy8gICAgIH0pO1xuICAgICAgICAvLyAgICAgaWYgKGV4aXN0aW5nVXNlcikge1xuICAgICAgICAvLyAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0VSUk9SOiBBY2NvdW50IGFscmVhZHkgZXhpc3RzIHdpdGggdGhpcyBlbWFpbCcpO1xuICAgICAgICAvLyAgICAgfVxuICAgICAgICAvLyAgICAgY29uc3QgaGFzaGVkUGFzc3dvcmQgPSBhd2FpdCBoYXNoKGFyZ3MuZGF0YS5wYXNzd29yZCwgMTApO1xuICAgICAgICAvLyAgICAgY29uc3QgdXNlciA9IGF3YWl0IGNvbnRleHQucHJpc21hLnVzZXIuY3JlYXRlKHtcbiAgICAgICAgLy8gICAgICAgZGF0YToge1xuICAgICAgICAvLyAgICAgICAgIGVtYWlsOiBhcmdzLmRhdGEuZW1haWwsXG4gICAgICAgIC8vICAgICAgICAgcGFzc3dvcmQ6IGhhc2hlZFBhc3N3b3JkLFxuICAgICAgICAvLyAgICAgICAgIG5hbWU6IGFyZ3MuZGF0YS5uYW1lLFxuICAgICAgICAvLyAgICAgICAgIHJvbGU6ICdVU0VSJyxcbiAgICAgICAgLy8gICAgICAgICBvcmdhbmlzYXRpb246IHtcbiAgICAgICAgLy8gICAgICAgICAgIGNvbm5lY3Q6IHtcbiAgICAgICAgLy8gICAgICAgICAgICAgaWQ6IGFyZ3MuZGF0YS5vcmdhbmlzYXRpb25JZCxcbiAgICAgICAgLy8gICAgICAgICAgIH0sXG4gICAgICAgIC8vICAgICAgICAgfSxcbiAgICAgICAgLy8gICAgICAgfSxcbiAgICAgICAgLy8gICAgIH0pO1xuICAgICAgICAvLyAgICAgaWYgKCF1c2VyKSB7XG4gICAgICAgIC8vICAgICAgIHRocm93IG5ldyBFcnJvcignRXJyb3InKTtcbiAgICAgICAgLy8gICAgIH1cbiAgICAgICAgLy8gICAgIGNvbnN0IHRva2VuID0gZ2VuZXJhdGVUb2tlbih1c2VyLmlkKTtcbiAgICAgICAgLy8gICAgIHJldHVybiB7XG4gICAgICAgIC8vICAgICAgIHRva2VuLFxuICAgICAgICAvLyAgICAgICB1c2VyLFxuICAgICAgICAvLyAgICAgfTtcbiAgICAgICAgLy8gICB9LFxuICAgICAgICAvLyB9KTtcbiAgICAgICAgdC5ub25OdWxsLmZpZWxkKCdhZGRVc2VyJywge1xuICAgICAgICAgICAgdHlwZTogZXhwb3J0cy5Vc2Vyc1BheWxvYWQsXG4gICAgICAgICAgICBhcmdzOiB7XG4gICAgICAgICAgICAgICAgZGF0YTogKDAsIG5leHVzXzEubm9uTnVsbCkoKDAsIG5leHVzXzEuYXJnKSh7XG4gICAgICAgICAgICAgICAgICAgIHR5cGU6IEFkZFVzZXJJbnB1dCxcbiAgICAgICAgICAgICAgICB9KSksXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcmVzb2x2ZTogYXN5bmMgKF8sIGFyZ3MsIGNvbnRleHQpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCB1c2VySWQgPSAoMCwgZ2V0VXNlcklkXzEuZ2V0VXNlcklkKShjb250ZXh0KTtcbiAgICAgICAgICAgICAgICBjb25zdCBvcmdhbmlzYXRpb24gPSBhd2FpdCBjb250ZXh0LnByaXNtYS51c2VyXG4gICAgICAgICAgICAgICAgICAgIC5maW5kVW5pcXVlKHtcbiAgICAgICAgICAgICAgICAgICAgd2hlcmU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkOiB1c2VySWQgIT0gbnVsbCA/IHVzZXJJZCA6IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAub3JnYW5pc2F0aW9uKCk7XG4gICAgICAgICAgICAgICAgY29uc3QgZXhpc3RpbmdVc2VyID0gYXdhaXQgY29udGV4dC5wcmlzbWEudXNlci5maW5kVW5pcXVlKHtcbiAgICAgICAgICAgICAgICAgICAgd2hlcmU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGVtYWlsOiBhcmdzLmRhdGEuZW1haWwsXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgaWYgKGV4aXN0aW5nVXNlcikge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0FjY291bnQgYWxyZWFkeSBleGlzdHMgd2l0aCB0aGlzIGVtYWlsJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNvbnN0IGhhc2hlZFBhc3N3b3JkID0gYXdhaXQgKDAsIGJjcnlwdF8xLmhhc2gpKGFyZ3MuZGF0YS5wYXNzd29yZCwgMTApO1xuICAgICAgICAgICAgICAgIGNvbnN0IHVzZXIgPSBhd2FpdCBjb250ZXh0LnByaXNtYS51c2VyLmNyZWF0ZSh7XG4gICAgICAgICAgICAgICAgICAgIGRhdGE6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGVtYWlsOiBhcmdzLmRhdGEuZW1haWwsXG4gICAgICAgICAgICAgICAgICAgICAgICBwYXNzd29yZDogaGFzaGVkUGFzc3dvcmQsXG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiBhcmdzLmRhdGEubmFtZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHJvbGU6IGFyZ3MuZGF0YS5yb2xlLFxuICAgICAgICAgICAgICAgICAgICAgICAgLi4uKDAsIGNyZWF0ZUNvbm5lY3Rpb25fMS5kZWZhdWx0KSgnZGVwb3QnLCBhcmdzLmRhdGEuZGVwb3RJZCksXG4gICAgICAgICAgICAgICAgICAgICAgICBvcmdhbmlzYXRpb246IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25uZWN0OiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkOiBvcmdhbmlzYXRpb24gPT09IG51bGwgfHwgb3JnYW5pc2F0aW9uID09PSB2b2lkIDAgPyB2b2lkIDAgOiBvcmdhbmlzYXRpb24uaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIGluY2x1ZGU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlcG90OiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgaW5mcmluZ2VtZW50czogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICBpZDogdXNlci5pZCxcbiAgICAgICAgICAgICAgICAgICAgbmFtZTogdXNlci5uYW1lLFxuICAgICAgICAgICAgICAgICAgICBlbWFpbDogdXNlci5lbWFpbCxcbiAgICAgICAgICAgICAgICAgICAgcm9sZTogdXNlci5yb2xlLFxuICAgICAgICAgICAgICAgICAgICBkZXBvdDogdXNlci5kZXBvdCxcbiAgICAgICAgICAgICAgICAgICAgaW5mcmluZ2VtZW50czogdXNlci5pbmZyaW5nZW1lbnRzLFxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgdC5ub25OdWxsLmZpZWxkKCdkZWxldGVVc2VyJywge1xuICAgICAgICAgICAgdHlwZTogZXhwb3J0cy5Vc2VyLFxuICAgICAgICAgICAgYXJnczoge1xuICAgICAgICAgICAgICAgIGRhdGE6ICgwLCBuZXh1c18xLm5vbk51bGwpKCgwLCBuZXh1c18xLmFyZykoe1xuICAgICAgICAgICAgICAgICAgICB0eXBlOiBEZWxldGVVc2VySW5wdXQsXG4gICAgICAgICAgICAgICAgfSkpLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHJlc29sdmU6IChfLCBhcmdzLCBjb250ZXh0KSA9PiB7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGNvbnRleHQucHJpc21hLnVzZXIuZGVsZXRlKHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHdoZXJlOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IGFyZ3MuZGF0YS5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdFcnJvciBkZWxldGluZyB1c2VyJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHQubm9uTnVsbC5maWVsZCgndXBkYXRlVXNlcicsIHtcbiAgICAgICAgICAgIHR5cGU6IGV4cG9ydHMuVXNlcnNQYXlsb2FkLFxuICAgICAgICAgICAgYXJnczoge1xuICAgICAgICAgICAgICAgIGRhdGE6ICgwLCBuZXh1c18xLm5vbk51bGwpKCgwLCBuZXh1c18xLmFyZykoe1xuICAgICAgICAgICAgICAgICAgICB0eXBlOiBVcGRhdGVVc2VySW5wdXQsXG4gICAgICAgICAgICAgICAgfSkpLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHJlc29sdmU6IGFzeW5jIChfLCBhcmdzLCBjb250ZXh0KSA9PiB7XG4gICAgICAgICAgICAgICAgdmFyIF9hO1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IG9sZFVzZXIgPSBhd2FpdCBjb250ZXh0LnByaXNtYS51c2VyLmZpbmRVbmlxdWUoe1xuICAgICAgICAgICAgICAgICAgICAgICAgd2hlcmU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogYXJncy5kYXRhLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGluY2x1ZGU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZXBvdDoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3Q6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgdXNlciA9IGF3YWl0IGNvbnRleHQucHJpc21hLnVzZXIudXBkYXRlKHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHdoZXJlOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IGFyZ3MuZGF0YS5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZTogYXJncy5kYXRhLm5hbWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZW1haWw6IGFyZ3MuZGF0YS5lbWFpbCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByb2xlOiBhcmdzLmRhdGEucm9sZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi4oMCwgdXBzZXJ0Q29ubmVjdGlvbl8xLmRlZmF1bHQpKCdkZXBvdCcsIChfYSA9IG9sZFVzZXIgPT09IG51bGwgfHwgb2xkVXNlciA9PT0gdm9pZCAwID8gdm9pZCAwIDogb2xkVXNlci5kZXBvdCkgPT09IG51bGwgfHwgX2EgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9hLmlkLCBhcmdzLmRhdGEuZGVwb3RJZCksXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgaW5jbHVkZToge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlcG90OiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGluZnJpbmdlbWVudHM6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkOiB1c2VyLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZTogdXNlci5uYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgZW1haWw6IHVzZXIuZW1haWwsXG4gICAgICAgICAgICAgICAgICAgICAgICByb2xlOiB1c2VyLnJvbGUsXG4gICAgICAgICAgICAgICAgICAgICAgICBkZXBvdDogdXNlci5kZXBvdCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGluZnJpbmdlbWVudHM6IHVzZXIuaW5mcmluZ2VtZW50cyxcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignRXJyb3IgdXBkYXRpbmcgdXNlcicpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH0sXG59KTtcbiIsIlwidXNlIHN0cmljdFwiO1xudmFyIF9faW1wb3J0RGVmYXVsdCA9ICh0aGlzICYmIHRoaXMuX19pbXBvcnREZWZhdWx0KSB8fCBmdW5jdGlvbiAobW9kKSB7XG4gICAgcmV0dXJuIChtb2QgJiYgbW9kLl9fZXNNb2R1bGUpID8gbW9kIDogeyBcImRlZmF1bHRcIjogbW9kIH07XG59O1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuZXhwb3J0cy5WZWhpY2xlTXV0YXRpb24gPSBleHBvcnRzLlZlaGljbGVRdWVyeSA9IGV4cG9ydHMuVmVoaWNsZSA9IHZvaWQgMDtcbmNvbnN0IG5leHVzXzEgPSByZXF1aXJlKFwibmV4dXNcIik7XG5jb25zdCBjcmVhdGVDb25uZWN0aW9uXzEgPSBfX2ltcG9ydERlZmF1bHQocmVxdWlyZShcIi4uL3V0aWxpdGllcy9jcmVhdGVDb25uZWN0aW9uXCIpKTtcbmNvbnN0IGdldERhdGVUd29XZWVrc18xID0gX19pbXBvcnREZWZhdWx0KHJlcXVpcmUoXCIuLi91dGlsaXRpZXMvZ2V0RGF0ZVR3b1dlZWtzXCIpKTtcbmNvbnN0IGdldFVzZXJJZF8xID0gcmVxdWlyZShcIi4uL3V0aWxpdGllcy9nZXRVc2VySWRcIik7XG5jb25zdCB1cHNlcnRDb25uZWN0aW9uXzEgPSBfX2ltcG9ydERlZmF1bHQocmVxdWlyZShcIi4uL3V0aWxpdGllcy91cHNlcnRDb25uZWN0aW9uXCIpKTtcbmNvbnN0IE9yZ2FuaXNhdGlvbl8xID0gcmVxdWlyZShcIi4vT3JnYW5pc2F0aW9uXCIpO1xuY29uc3QgRGVmZWN0XzEgPSByZXF1aXJlKFwiLi9EZWZlY3RcIik7XG5jb25zdCBEZXBvdF8xID0gcmVxdWlyZShcIi4vRGVwb3RcIik7XG5jb25zdCBFbnVtXzEgPSByZXF1aXJlKFwiLi9FbnVtXCIpO1xuY29uc3QgRnVlbENhcmRfMSA9IHJlcXVpcmUoXCIuL0Z1ZWxDYXJkXCIpO1xuY29uc3QgVG9sbFRhZ18xID0gcmVxdWlyZShcIi4vVG9sbFRhZ1wiKTtcbmV4cG9ydHMuVmVoaWNsZSA9ICgwLCBuZXh1c18xLm9iamVjdFR5cGUpKHtcbiAgICBuYW1lOiAnVmVoaWNsZScsXG4gICAgZGVmaW5pdGlvbih0KSB7XG4gICAgICAgIHQubm9uTnVsbC5pZCgnaWQnKTtcbiAgICAgICAgdC5ub25OdWxsLmZpZWxkKCd0eXBlJywge1xuICAgICAgICAgICAgdHlwZTogRW51bV8xLlZlaGljbGVUeXBlLFxuICAgICAgICB9KTtcbiAgICAgICAgdC5ub25OdWxsLnN0cmluZygncmVnaXN0cmF0aW9uJyk7XG4gICAgICAgIHQubm9uTnVsbC5zdHJpbmcoJ21ha2UnKTtcbiAgICAgICAgdC5ub25OdWxsLnN0cmluZygnbW9kZWwnKTtcbiAgICAgICAgdC5ub25OdWxsLnN0cmluZygnb3duZXInKTtcbiAgICAgICAgdC5kYXRlKCdjdnJ0Jyk7XG4gICAgICAgIHQuZGF0ZSgndGhpcnRlZW5XZWVrSW5zcGVjdGlvbicpO1xuICAgICAgICB0LmRhdGUoJ3RhY2hvQ2FsaWJyYXRpb24nKTtcbiAgICAgICAgdC5ub25OdWxsLmZpZWxkKCdvcmdhbmlzYXRpb24nLCB7XG4gICAgICAgICAgICB0eXBlOiBPcmdhbmlzYXRpb25fMS5PcmdhbmlzYXRpb24sXG4gICAgICAgICAgICByZXNvbHZlOiBhc3luYyAocGFyZW50LCBfLCBjb250ZXh0KSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3Qgb3JnYW5pc2F0aW9uID0gYXdhaXQgY29udGV4dC5wcmlzbWEudmVoaWNsZVxuICAgICAgICAgICAgICAgICAgICAuZmluZFVuaXF1ZSh7XG4gICAgICAgICAgICAgICAgICAgIHdoZXJlOiB7IGlkOiBwYXJlbnQuaWQgfSxcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAub3JnYW5pc2F0aW9uKCk7XG4gICAgICAgICAgICAgICAgaWYgKCFvcmdhbmlzYXRpb24pIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdPcmdhbmlzYXRpb24gbm90IGZvdW5kJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiBvcmdhbmlzYXRpb247XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgdC5maWVsZCgnZGVwb3QnLCB7XG4gICAgICAgICAgICB0eXBlOiBEZXBvdF8xLkRlcG90LFxuICAgICAgICAgICAgcmVzb2x2ZShwYXJlbnQsIF8sIGNvbnRleHQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gY29udGV4dC5wcmlzbWEudmVoaWNsZVxuICAgICAgICAgICAgICAgICAgICAuZmluZFVuaXF1ZSh7XG4gICAgICAgICAgICAgICAgICAgIHdoZXJlOiB7IGlkOiBwYXJlbnQuaWQgfSxcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAuZGVwb3QoKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICB0Lm5vbk51bGwubGlzdC5ub25OdWxsLmZpZWxkKCdkZWZlY3RzJywge1xuICAgICAgICAgICAgdHlwZTogRGVmZWN0XzEuRGVmZWN0LFxuICAgICAgICAgICAgcmVzb2x2ZShwYXJlbnQsIF8sIGNvbnRleHQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gY29udGV4dC5wcmlzbWEudmVoaWNsZVxuICAgICAgICAgICAgICAgICAgICAuZmluZFVuaXF1ZSh7XG4gICAgICAgICAgICAgICAgICAgIHdoZXJlOiB7IGlkOiBwYXJlbnQuaWQgfSxcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAuZGVmZWN0cygpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHQuZmllbGQoJ2Z1ZWxDYXJkJywge1xuICAgICAgICAgICAgdHlwZTogRnVlbENhcmRfMS5GdWVsQ2FyZCxcbiAgICAgICAgICAgIHJlc29sdmUocGFyZW50LCBfLCBjb250ZXh0KSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGNvbnRleHQucHJpc21hLnZlaGljbGVcbiAgICAgICAgICAgICAgICAgICAgLmZpbmRVbmlxdWUoe1xuICAgICAgICAgICAgICAgICAgICB3aGVyZTogeyBpZDogcGFyZW50LmlkIH0sXG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgLmZ1ZWxDYXJkKCk7XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgdC5maWVsZCgndG9sbFRhZycsIHtcbiAgICAgICAgICAgIHR5cGU6IFRvbGxUYWdfMS5Ub2xsVGFnLFxuICAgICAgICAgICAgcmVzb2x2ZShwYXJlbnQsIF8sIGNvbnRleHQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gY29udGV4dC5wcmlzbWEudmVoaWNsZVxuICAgICAgICAgICAgICAgICAgICAuZmluZFVuaXF1ZSh7XG4gICAgICAgICAgICAgICAgICAgIHdoZXJlOiB7IGlkOiBwYXJlbnQuaWQgfSxcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAudG9sbFRhZygpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfSxcbn0pO1xuY29uc3QgVmVoaWNsZUlucHV0RmlsdGVyID0gKDAsIG5leHVzXzEuaW5wdXRPYmplY3RUeXBlKSh7XG4gICAgbmFtZTogJ1ZlaGljbGVJbnB1dEZpbHRlcicsXG4gICAgZGVmaW5pdGlvbih0KSB7XG4gICAgICAgIHQuc3RyaW5nKCdzZWFyY2hDcml0ZXJpYScpO1xuICAgIH0sXG59KTtcbmV4cG9ydHMuVmVoaWNsZVF1ZXJ5ID0gKDAsIG5leHVzXzEuZXh0ZW5kVHlwZSkoe1xuICAgIHR5cGU6ICdRdWVyeScsXG4gICAgZGVmaW5pdGlvbih0KSB7XG4gICAgICAgIHQuZmllbGQoJ3ZlaGljbGUnLCB7XG4gICAgICAgICAgICB0eXBlOiBleHBvcnRzLlZlaGljbGUsXG4gICAgICAgICAgICBhcmdzOiB7XG4gICAgICAgICAgICAgICAgdmVoaWNsZUlkOiAoMCwgbmV4dXNfMS5ub25OdWxsKSgoMCwgbmV4dXNfMS5pZEFyZykoKSksXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcmVzb2x2ZTogKF8sIHsgdmVoaWNsZUlkIH0sIGNvbnRleHQpID0+IHtcbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gY29udGV4dC5wcmlzbWEudmVoaWNsZS5maW5kVW5pcXVlKHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHdoZXJlOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IHZlaGljbGVJZCxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdFcnJvciByZXRyaWV2aW5nIHZlaGljbGUnKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgdC5saXN0LmZpZWxkKCd2ZWhpY2xlcycsIHtcbiAgICAgICAgICAgIHR5cGU6IGV4cG9ydHMuVmVoaWNsZSxcbiAgICAgICAgICAgIGFyZ3M6IHtcbiAgICAgICAgICAgICAgICBkYXRhOiAoMCwgbmV4dXNfMS5hcmcpKHtcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogVmVoaWNsZUlucHV0RmlsdGVyLFxuICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHJlc29sdmU6IGFzeW5jIChfLCBhcmdzLCBjb250ZXh0KSA9PiB7XG4gICAgICAgICAgICAgICAgdmFyIF9hO1xuICAgICAgICAgICAgICAgIGNvbnN0IHVzZXJJZCA9ICgwLCBnZXRVc2VySWRfMS5nZXRVc2VySWQpKGNvbnRleHQpO1xuICAgICAgICAgICAgICAgIGlmICghdXNlcklkKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignVW5hYmxlIHRvIHJldHJpZXZlIHZlaGljbGVzLiBZb3UgYXJlIG5vdCBsb2dnZWQgaW4uJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNvbnN0IG9yZ2FuaXNhdGlvbiA9IGF3YWl0IGNvbnRleHQucHJpc21hLnVzZXJcbiAgICAgICAgICAgICAgICAgICAgLmZpbmRVbmlxdWUoe1xuICAgICAgICAgICAgICAgICAgICB3aGVyZToge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IHVzZXJJZCAhPSBudWxsID8gdXNlcklkIDogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgIC5vcmdhbmlzYXRpb24oKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gY29udGV4dC5wcmlzbWEudmVoaWNsZS5maW5kTWFueSh7XG4gICAgICAgICAgICAgICAgICAgIHdoZXJlOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBBTkQ6IFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IG9yZ2FuaXNhdGlvbklkOiBvcmdhbmlzYXRpb24gPT09IG51bGwgfHwgb3JnYW5pc2F0aW9uID09PSB2b2lkIDAgPyB2b2lkIDAgOiBvcmdhbmlzYXRpb24uaWQgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlZ2lzdHJhdGlvbjoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udGFpbnM6ICgoX2EgPSBhcmdzLmRhdGEpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS5zZWFyY2hDcml0ZXJpYSkgIT0gbnVsbFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gYXJncy5kYXRhLnNlYXJjaENyaXRlcmlhXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiB1bmRlZmluZWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtb2RlOiAnaW5zZW5zaXRpdmUnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICBvcmRlckJ5OiB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZWdpc3RyYXRpb246ICdhc2MnLFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHQubGlzdC5maWVsZCgnZGVmZWN0c0ZvclZlaGljbGUnLCB7XG4gICAgICAgICAgICB0eXBlOiBEZWZlY3RfMS5EZWZlY3QsXG4gICAgICAgICAgICBhcmdzOiB7XG4gICAgICAgICAgICAgICAgdmVoaWNsZUlkOiAoMCwgbmV4dXNfMS5ub25OdWxsKSgoMCwgbmV4dXNfMS5pZEFyZykoKSksXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcmVzb2x2ZTogKF8sIHsgdmVoaWNsZUlkIH0sIGNvbnRleHQpID0+IHtcbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gY29udGV4dC5wcmlzbWEudmVoaWNsZVxuICAgICAgICAgICAgICAgICAgICAgICAgLmZpbmRVbmlxdWUoe1xuICAgICAgICAgICAgICAgICAgICAgICAgd2hlcmU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogdmVoaWNsZUlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgIC5kZWZlY3RzKCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1RoZXJlIHdhcyBhbiBlcnJvciByZXRyaWV2aW5nIGRlZmVjdHMgZm9yIHZlaGljbGUnKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgdC5saXN0LmZpZWxkKCd1cGNvbWluZ0NWUlQnLCB7XG4gICAgICAgICAgICB0eXBlOiBleHBvcnRzLlZlaGljbGUsXG4gICAgICAgICAgICByZXNvbHZlOiBhc3luYyAoXywgX18sIGNvbnRleHQpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCB1c2VySWQgPSAoMCwgZ2V0VXNlcklkXzEuZ2V0VXNlcklkKShjb250ZXh0KTtcbiAgICAgICAgICAgICAgICBpZiAoIXVzZXJJZCkge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1VuYWJsZSB0byByZXRyaWV2ZSB2ZWhpY2xlcyB3aXRoIHVwY29taW5nIENWUlRzLiBZb3UgYXJlIG5vdCBsb2dnZWQgaW4uJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNvbnN0IG9yZ2FuaXNhdGlvbiA9IGF3YWl0IGNvbnRleHQucHJpc21hLnVzZXJcbiAgICAgICAgICAgICAgICAgICAgLmZpbmRVbmlxdWUoe1xuICAgICAgICAgICAgICAgICAgICB3aGVyZToge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IHVzZXJJZCAhPSBudWxsID8gdXNlcklkIDogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgIC5vcmdhbmlzYXRpb24oKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gY29udGV4dC5wcmlzbWEudmVoaWNsZS5maW5kTWFueSh7XG4gICAgICAgICAgICAgICAgICAgIHdoZXJlOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBBTkQ6IFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IG9yZ2FuaXNhdGlvbklkOiBvcmdhbmlzYXRpb24gPT09IG51bGwgfHwgb3JnYW5pc2F0aW9uID09PSB2b2lkIDAgPyB2b2lkIDAgOiBvcmdhbmlzYXRpb24uaWQgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN2cnQ6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGx0ZTogKDAsIGdldERhdGVUd29XZWVrc18xLmRlZmF1bHQpKCksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIG9yZGVyQnk6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGN2cnQ6ICdhc2MnLFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHQubGlzdC5maWVsZCgndXBjb21pbmdUaGlydGVlbldlZWsnLCB7XG4gICAgICAgICAgICB0eXBlOiBleHBvcnRzLlZlaGljbGUsXG4gICAgICAgICAgICByZXNvbHZlOiBhc3luYyAoXywgX18sIGNvbnRleHQpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCB1c2VySWQgPSAoMCwgZ2V0VXNlcklkXzEuZ2V0VXNlcklkKShjb250ZXh0KTtcbiAgICAgICAgICAgICAgICBpZiAoIXVzZXJJZCkge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1VuYWJsZSB0byByZXRyaWV2ZSB2ZWhpY2xlcyB3aXRoIHVwY29taW5nIHRoaXJ0ZWVuIHdlZWtzLiBZb3UgYXJlIG5vdCBsb2dnZWQgaW4uJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNvbnN0IG9yZ2FuaXNhdGlvbiA9IGF3YWl0IGNvbnRleHQucHJpc21hLnVzZXJcbiAgICAgICAgICAgICAgICAgICAgLmZpbmRVbmlxdWUoe1xuICAgICAgICAgICAgICAgICAgICB3aGVyZToge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IHVzZXJJZCAhPSBudWxsID8gdXNlcklkIDogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgIC5vcmdhbmlzYXRpb24oKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gY29udGV4dC5wcmlzbWEudmVoaWNsZS5maW5kTWFueSh7XG4gICAgICAgICAgICAgICAgICAgIHdoZXJlOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBBTkQ6IFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IG9yZ2FuaXNhdGlvbklkOiBvcmdhbmlzYXRpb24gPT09IG51bGwgfHwgb3JnYW5pc2F0aW9uID09PSB2b2lkIDAgPyB2b2lkIDAgOiBvcmdhbmlzYXRpb24uaWQgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXJ0ZWVuV2Vla0luc3BlY3Rpb246IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGx0ZTogKDAsIGdldERhdGVUd29XZWVrc18xLmRlZmF1bHQpKCksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIG9yZGVyQnk6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXJ0ZWVuV2Vla0luc3BlY3Rpb246ICdhc2MnLFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHQubGlzdC5maWVsZCgndXBjb21pbmdUYWNob0NhbGlicmF0aW9uJywge1xuICAgICAgICAgICAgdHlwZTogZXhwb3J0cy5WZWhpY2xlLFxuICAgICAgICAgICAgcmVzb2x2ZTogYXN5bmMgKF8sIF9fLCBjb250ZXh0KSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgdXNlcklkID0gKDAsIGdldFVzZXJJZF8xLmdldFVzZXJJZCkoY29udGV4dCk7XG4gICAgICAgICAgICAgICAgaWYgKCF1c2VySWQpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdVbmFibGUgdG8gcmV0cmlldmUgdmVoaWNsZXMgd2l0aCB1cGNvbWluZyB0YWNobyBjYWxpYnJhdGlvbi4gWW91IGFyZSBub3QgbG9nZ2VkIGluLicpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjb25zdCBvcmdhbmlzYXRpb24gPSBhd2FpdCBjb250ZXh0LnByaXNtYS51c2VyXG4gICAgICAgICAgICAgICAgICAgIC5maW5kVW5pcXVlKHtcbiAgICAgICAgICAgICAgICAgICAgd2hlcmU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkOiB1c2VySWQgIT0gbnVsbCA/IHVzZXJJZCA6IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAub3JnYW5pc2F0aW9uKCk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGNvbnRleHQucHJpc21hLnZlaGljbGUuZmluZE1hbnkoe1xuICAgICAgICAgICAgICAgICAgICB3aGVyZToge1xuICAgICAgICAgICAgICAgICAgICAgICAgQU5EOiBbXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBvcmdhbmlzYXRpb25JZDogb3JnYW5pc2F0aW9uID09PSBudWxsIHx8IG9yZ2FuaXNhdGlvbiA9PT0gdm9pZCAwID8gdm9pZCAwIDogb3JnYW5pc2F0aW9uLmlkIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YWNob0NhbGlicmF0aW9uOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsdGU6ICgwLCBnZXREYXRlVHdvV2Vla3NfMS5kZWZhdWx0KSgpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICBvcmRlckJ5OiB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0YWNob0NhbGlicmF0aW9uOiAnYXNjJyxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH0sXG59KTtcbmNvbnN0IEFkZFZlaGljbGVJbnB1dCA9ICgwLCBuZXh1c18xLmlucHV0T2JqZWN0VHlwZSkoe1xuICAgIG5hbWU6ICdBZGRWZWhpY2xlSW5wdXQnLFxuICAgIGRlZmluaXRpb24odCkge1xuICAgICAgICB0Lm5vbk51bGwuZmllbGQoJ3R5cGUnLCB7IHR5cGU6IEVudW1fMS5WZWhpY2xlVHlwZSB9KTtcbiAgICAgICAgdC5ub25OdWxsLnN0cmluZygncmVnaXN0cmF0aW9uJyk7XG4gICAgICAgIHQubm9uTnVsbC5zdHJpbmcoJ21ha2UnKTtcbiAgICAgICAgdC5ub25OdWxsLnN0cmluZygnbW9kZWwnKTtcbiAgICAgICAgdC5ub25OdWxsLnN0cmluZygnb3duZXInKTtcbiAgICAgICAgdC5kYXRlKCdjdnJ0Jyk7XG4gICAgICAgIHQuZGF0ZSgndGhpcnRlZW5XZWVrSW5zcGVjdGlvbicpO1xuICAgICAgICB0LmRhdGUoJ3RhY2hvQ2FsaWJyYXRpb24nKTtcbiAgICAgICAgdC5zdHJpbmcoJ2RlcG90SWQnKTtcbiAgICAgICAgdC5zdHJpbmcoJ2Z1ZWxDYXJkSWQnKTtcbiAgICAgICAgdC5zdHJpbmcoJ3RvbGxUYWdJZCcpO1xuICAgIH0sXG59KTtcbmNvbnN0IFVwZGF0ZVZlaGljbGVJbnB1dCA9ICgwLCBuZXh1c18xLmlucHV0T2JqZWN0VHlwZSkoe1xuICAgIG5hbWU6ICdVcGRhdGVWZWhpY2xlSW5wdXQnLFxuICAgIGRlZmluaXRpb24odCkge1xuICAgICAgICB0Lm5vbk51bGwuc3RyaW5nKCdpZCcpO1xuICAgICAgICB0Lm5vbk51bGwuZmllbGQoJ3R5cGUnLCB7IHR5cGU6IEVudW1fMS5WZWhpY2xlVHlwZSB9KTtcbiAgICAgICAgdC5ub25OdWxsLnN0cmluZygncmVnaXN0cmF0aW9uJyk7XG4gICAgICAgIHQubm9uTnVsbC5zdHJpbmcoJ21ha2UnKTtcbiAgICAgICAgdC5ub25OdWxsLnN0cmluZygnbW9kZWwnKTtcbiAgICAgICAgdC5ub25OdWxsLnN0cmluZygnb3duZXInKTtcbiAgICAgICAgdC5kYXRlKCdjdnJ0Jyk7XG4gICAgICAgIHQuZGF0ZSgndGhpcnRlZW5XZWVrSW5zcGVjdGlvbicpO1xuICAgICAgICB0LmRhdGUoJ3RhY2hvQ2FsaWJyYXRpb24nKTtcbiAgICAgICAgdC5zdHJpbmcoJ2RlcG90SWQnKTtcbiAgICAgICAgdC5zdHJpbmcoJ2Z1ZWxDYXJkSWQnKTtcbiAgICAgICAgdC5zdHJpbmcoJ3RvbGxUYWdJZCcpO1xuICAgIH0sXG59KTtcbmNvbnN0IERlbGV0ZVZlaGljbGVJbnB1dCA9ICgwLCBuZXh1c18xLmlucHV0T2JqZWN0VHlwZSkoe1xuICAgIG5hbWU6ICdEZWxldGVWZWhpY2xlSW5wdXQnLFxuICAgIGRlZmluaXRpb24odCkge1xuICAgICAgICB0Lm5vbk51bGwuaWQoJ2lkJyk7XG4gICAgfSxcbn0pO1xuY29uc3QgVXBkYXRlVmVoaWNsZURhdGVzID0gKDAsIG5leHVzXzEuaW5wdXRPYmplY3RUeXBlKSh7XG4gICAgbmFtZTogJ1VwZGF0ZVZlaGljbGVEYXRlcycsXG4gICAgZGVmaW5pdGlvbih0KSB7XG4gICAgICAgIHQubm9uTnVsbC5zdHJpbmcoJ2lkJyk7XG4gICAgfSxcbn0pO1xuY29uc3QgVXBkYXRlVmVoaWNsZURhdGVzV2l0aENvbXBsZXRpb24gPSAoMCwgbmV4dXNfMS5pbnB1dE9iamVjdFR5cGUpKHtcbiAgICBuYW1lOiAnVXBkYXRlVmVoaWNsZURhdGVzV2l0aENvbXBsZXRpb24nLFxuICAgIGRlZmluaXRpb24odCkge1xuICAgICAgICB0Lm5vbk51bGwuc3RyaW5nKCdpZCcpO1xuICAgICAgICB0Lm5vbk51bGwuZGF0ZSgnY29tcGxldGlvbkRhdGUnKTtcbiAgICB9LFxufSk7XG5leHBvcnRzLlZlaGljbGVNdXRhdGlvbiA9ICgwLCBuZXh1c18xLmV4dGVuZFR5cGUpKHtcbiAgICB0eXBlOiAnTXV0YXRpb24nLFxuICAgIGRlZmluaXRpb24odCkge1xuICAgICAgICB0Lm5vbk51bGwuZmllbGQoJ2FkZFZlaGljbGUnLCB7XG4gICAgICAgICAgICB0eXBlOiBleHBvcnRzLlZlaGljbGUsXG4gICAgICAgICAgICBhcmdzOiB7XG4gICAgICAgICAgICAgICAgZGF0YTogKDAsIG5leHVzXzEubm9uTnVsbCkoKDAsIG5leHVzXzEuYXJnKSh7XG4gICAgICAgICAgICAgICAgICAgIHR5cGU6IEFkZFZlaGljbGVJbnB1dCxcbiAgICAgICAgICAgICAgICB9KSksXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcmVzb2x2ZTogYXN5bmMgKF8sIGFyZ3MsIGNvbnRleHQpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCB1c2VySWQgPSAoMCwgZ2V0VXNlcklkXzEuZ2V0VXNlcklkKShjb250ZXh0KTtcbiAgICAgICAgICAgICAgICBpZiAoIXVzZXJJZCkge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1VuYWJsZSB0byBhZGQgdmVoaWNsZS4gWW91IGFyZSBub3QgbG9nZ2VkIGluLicpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjb25zdCBvcmdhbmlzYXRpb24gPSBhd2FpdCBjb250ZXh0LnByaXNtYS51c2VyXG4gICAgICAgICAgICAgICAgICAgIC5maW5kVW5pcXVlKHtcbiAgICAgICAgICAgICAgICAgICAgd2hlcmU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkOiB1c2VySWQgIT0gbnVsbCA/IHVzZXJJZCA6IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAub3JnYW5pc2F0aW9uKCk7XG4gICAgICAgICAgICAgICAgY29uc3QgZXhpc3RpbmdWZWhpY2xlID0gYXdhaXQgY29udGV4dC5wcmlzbWEudmVoaWNsZS5maW5kVW5pcXVlKHtcbiAgICAgICAgICAgICAgICAgICAgd2hlcmU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlZ2lzdHJhdGlvbjogYXJncy5kYXRhLnJlZ2lzdHJhdGlvbixcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICBpZiAoZXhpc3RpbmdWZWhpY2xlKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignVmVoaWNsZSBhbHJlYWR5IGV4aXN0cyB3aXRoIHRoaXMgcmVnaXN0cmF0aW9uJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiBjb250ZXh0LnByaXNtYS52ZWhpY2xlLmNyZWF0ZSh7XG4gICAgICAgICAgICAgICAgICAgIGRhdGE6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6IGFyZ3MuZGF0YS50eXBlLFxuICAgICAgICAgICAgICAgICAgICAgICAgcmVnaXN0cmF0aW9uOiBhcmdzLmRhdGEucmVnaXN0cmF0aW9uLFxuICAgICAgICAgICAgICAgICAgICAgICAgbWFrZTogYXJncy5kYXRhLm1ha2UsXG4gICAgICAgICAgICAgICAgICAgICAgICBtb2RlbDogYXJncy5kYXRhLm1vZGVsLFxuICAgICAgICAgICAgICAgICAgICAgICAgb3duZXI6IGFyZ3MuZGF0YS5vd25lcixcbiAgICAgICAgICAgICAgICAgICAgICAgIG9yZ2FuaXNhdGlvbjoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbm5lY3Q6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IG9yZ2FuaXNhdGlvbiA9PT0gbnVsbCB8fCBvcmdhbmlzYXRpb24gPT09IHZvaWQgMCA/IHZvaWQgMCA6IG9yZ2FuaXNhdGlvbi5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGN2cnQ6IGFyZ3MuZGF0YS5jdnJ0LFxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcnRlZW5XZWVrSW5zcGVjdGlvbjogYXJncy5kYXRhLnRoaXJ0ZWVuV2Vla0luc3BlY3Rpb24sXG4gICAgICAgICAgICAgICAgICAgICAgICB0YWNob0NhbGlicmF0aW9uOiBhcmdzLmRhdGEudGFjaG9DYWxpYnJhdGlvbixcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLigwLCBjcmVhdGVDb25uZWN0aW9uXzEuZGVmYXVsdCkoJ2RlcG90JywgYXJncy5kYXRhLmRlcG90SWQpLFxuICAgICAgICAgICAgICAgICAgICAgICAgLi4uKDAsIGNyZWF0ZUNvbm5lY3Rpb25fMS5kZWZhdWx0KSgnZnVlbENhcmQnLCBhcmdzLmRhdGEuZnVlbENhcmRJZCksXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi4oMCwgY3JlYXRlQ29ubmVjdGlvbl8xLmRlZmF1bHQpKCd0b2xsVGFnJywgYXJncy5kYXRhLnRvbGxUYWdJZCksXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgdC5ub25OdWxsLmZpZWxkKCdkZWxldGVWZWhpY2xlJywge1xuICAgICAgICAgICAgdHlwZTogZXhwb3J0cy5WZWhpY2xlLFxuICAgICAgICAgICAgYXJnczoge1xuICAgICAgICAgICAgICAgIGRhdGE6ICgwLCBuZXh1c18xLm5vbk51bGwpKCgwLCBuZXh1c18xLmFyZykoe1xuICAgICAgICAgICAgICAgICAgICB0eXBlOiBEZWxldGVWZWhpY2xlSW5wdXQsXG4gICAgICAgICAgICAgICAgfSkpLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHJlc29sdmU6IChfLCBhcmdzLCBjb250ZXh0KSA9PiB7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGNvbnRleHQucHJpc21hLnZlaGljbGUuZGVsZXRlKHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHdoZXJlOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IGFyZ3MuZGF0YS5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdFcnJvciBkZWxldGluZyB2ZWhpY2xlJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHQubm9uTnVsbC5maWVsZCgndXBkYXRlVmVoaWNsZScsIHtcbiAgICAgICAgICAgIHR5cGU6IGV4cG9ydHMuVmVoaWNsZSxcbiAgICAgICAgICAgIGFyZ3M6IHtcbiAgICAgICAgICAgICAgICBkYXRhOiAoMCwgbmV4dXNfMS5ub25OdWxsKSgoMCwgbmV4dXNfMS5hcmcpKHtcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogVXBkYXRlVmVoaWNsZUlucHV0LFxuICAgICAgICAgICAgICAgIH0pKSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICByZXNvbHZlOiBhc3luYyAoXywgYXJncywgY29udGV4dCkgPT4ge1xuICAgICAgICAgICAgICAgIHZhciBfYSwgX2IsIF9jO1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IG9sZFZlaGljbGUgPSBhd2FpdCBjb250ZXh0LnByaXNtYS52ZWhpY2xlLmZpbmRVbmlxdWUoe1xuICAgICAgICAgICAgICAgICAgICAgICAgd2hlcmU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogYXJncy5kYXRhLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGluY2x1ZGU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmdWVsQ2FyZDoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3Q6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdG9sbFRhZzoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3Q6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVwb3Q6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZWN0OiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHZlaGljbGUgPSBjb250ZXh0LnByaXNtYS52ZWhpY2xlLnVwZGF0ZSh7XG4gICAgICAgICAgICAgICAgICAgICAgICB3aGVyZToge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkOiBhcmdzLmRhdGEuaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgZGF0YToge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6IGFyZ3MuZGF0YS50eXBlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlZ2lzdHJhdGlvbjogYXJncy5kYXRhLnJlZ2lzdHJhdGlvbixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYWtlOiBhcmdzLmRhdGEubWFrZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtb2RlbDogYXJncy5kYXRhLm1vZGVsLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG93bmVyOiBhcmdzLmRhdGEub3duZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY3ZydDogYXJncy5kYXRhLmN2cnQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcnRlZW5XZWVrSW5zcGVjdGlvbjogYXJncy5kYXRhLnRoaXJ0ZWVuV2Vla0luc3BlY3Rpb24sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGFjaG9DYWxpYnJhdGlvbjogYXJncy5kYXRhLnRhY2hvQ2FsaWJyYXRpb24sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uKDAsIHVwc2VydENvbm5lY3Rpb25fMS5kZWZhdWx0KSgnZGVwb3QnLCAoX2EgPSBvbGRWZWhpY2xlID09PSBudWxsIHx8IG9sZFZlaGljbGUgPT09IHZvaWQgMCA/IHZvaWQgMCA6IG9sZFZlaGljbGUuZGVwb3QpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS5pZCwgYXJncy5kYXRhLmRlcG90SWQpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4uLigwLCB1cHNlcnRDb25uZWN0aW9uXzEuZGVmYXVsdCkoJ2Z1ZWxDYXJkJywgKF9iID0gb2xkVmVoaWNsZSA9PT0gbnVsbCB8fCBvbGRWZWhpY2xlID09PSB2b2lkIDAgPyB2b2lkIDAgOiBvbGRWZWhpY2xlLmZ1ZWxDYXJkKSA9PT0gbnVsbCB8fCBfYiA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2IuaWQsIGFyZ3MuZGF0YS5mdWVsQ2FyZElkKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi4oMCwgdXBzZXJ0Q29ubmVjdGlvbl8xLmRlZmF1bHQpKCd0b2xsVGFnJywgKF9jID0gb2xkVmVoaWNsZSA9PT0gbnVsbCB8fCBvbGRWZWhpY2xlID09PSB2b2lkIDAgPyB2b2lkIDAgOiBvbGRWZWhpY2xlLnRvbGxUYWcpID09PSBudWxsIHx8IF9jID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYy5pZCwgYXJncy5kYXRhLnRvbGxUYWdJZCksXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHZlaGljbGU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoIChfZCkge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0Vycm9yIHVwZGF0aW5nIHZlaGljbGUnKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgdC5ub25OdWxsLmZpZWxkKCd1cGRhdGVWZWhpY2xlQ1ZSVCcsIHtcbiAgICAgICAgICAgIHR5cGU6IGV4cG9ydHMuVmVoaWNsZSxcbiAgICAgICAgICAgIGFyZ3M6IHtcbiAgICAgICAgICAgICAgICBkYXRhOiAoMCwgbmV4dXNfMS5ub25OdWxsKSgoMCwgbmV4dXNfMS5hcmcpKHtcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogVXBkYXRlVmVoaWNsZURhdGVzLFxuICAgICAgICAgICAgICAgIH0pKSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICByZXNvbHZlOiBhc3luYyAoXywgYXJncywgY29udGV4dCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHZlaGljbGUgPSBhd2FpdCBjb250ZXh0LnByaXNtYS52ZWhpY2xlLmZpbmRVbmlxdWUoe1xuICAgICAgICAgICAgICAgICAgICB3aGVyZToge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IGFyZ3MuZGF0YS5pZCxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICBpZiAoIXZlaGljbGUpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdUaGlzIHZlaGljbGUgZG9lcyBub3QgZXhpc3QuJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmICghdmVoaWNsZS5jdnJ0KSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignVGhpcyB2ZWhpY2xlIGRvZXMgbm90IGhhdmUgYSBjdnJ0IGR1ZSBkYXRlIHNldC4nKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY29uc3QgeWVhciA9IHZlaGljbGUuY3ZydC5nZXRGdWxsWWVhcigpO1xuICAgICAgICAgICAgICAgIGNvbnN0IG1vbnRoID0gdmVoaWNsZS5jdnJ0LmdldE1vbnRoKCk7XG4gICAgICAgICAgICAgICAgY29uc3QgZGF5ID0gdmVoaWNsZS5jdnJ0LmdldERhdGUoKTtcbiAgICAgICAgICAgICAgICBjb25zdCBuZXh0Q1ZSVCA9IG5ldyBEYXRlKHllYXIgKyAxLCBtb250aCwgZGF5KTtcbiAgICAgICAgICAgICAgICBjb25zdCB1cGRhdGVkVmVoaWNsZSA9IGF3YWl0IGNvbnRleHQucHJpc21hLnZlaGljbGUudXBkYXRlKHtcbiAgICAgICAgICAgICAgICAgICAgd2hlcmU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkOiBhcmdzLmRhdGEuaWQsXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIGRhdGE6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGN2cnQ6IG5leHRDVlJULFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIHJldHVybiB1cGRhdGVkVmVoaWNsZTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICB0Lm5vbk51bGwuZmllbGQoJ3VwZGF0ZVZlaGljbGVUaGlydGVlbldlZWtJbnNwZWN0aW9uJywge1xuICAgICAgICAgICAgdHlwZTogZXhwb3J0cy5WZWhpY2xlLFxuICAgICAgICAgICAgYXJnczoge1xuICAgICAgICAgICAgICAgIGRhdGE6ICgwLCBuZXh1c18xLm5vbk51bGwpKCgwLCBuZXh1c18xLmFyZykoe1xuICAgICAgICAgICAgICAgICAgICB0eXBlOiBVcGRhdGVWZWhpY2xlRGF0ZXNXaXRoQ29tcGxldGlvbixcbiAgICAgICAgICAgICAgICB9KSksXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcmVzb2x2ZTogYXN5bmMgKF8sIGFyZ3MsIGNvbnRleHQpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCB2ZWhpY2xlID0gYXdhaXQgY29udGV4dC5wcmlzbWEudmVoaWNsZS5maW5kVW5pcXVlKHtcbiAgICAgICAgICAgICAgICAgICAgd2hlcmU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkOiBhcmdzLmRhdGEuaWQsXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgaWYgKCF2ZWhpY2xlKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignVGhpcyB2ZWhpY2xlIGRvZXMgbm90IGV4aXN0LicpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAoIXZlaGljbGUudGhpcnRlZW5XZWVrSW5zcGVjdGlvbikge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1RoaXMgdmVoaWNsZSBkb2VzIG5vdCBoYXZlIGEgdGhpcnRlZW4gd2VlayBpbnNwZWN0aW9uIGR1ZSBkYXRlIHNldC4nKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY29uc3Qgd2Vla3NUb0FkZCA9IDEzO1xuICAgICAgICAgICAgICAgIGNvbnN0IGNvbXBsZXRpb25EYXRlID0gbmV3IERhdGUoYXJncy5kYXRhLmNvbXBsZXRpb25EYXRlKTtcbiAgICAgICAgICAgICAgICBjb25zdCBuZXh0VGhpcnRlZW5XZWVrSW5zcGVjdGlvbiA9IG5ldyBEYXRlKGNvbXBsZXRpb25EYXRlLnNldERhdGUoY29tcGxldGlvbkRhdGUuZ2V0RGF0ZSgpICsgd2Vla3NUb0FkZCAqIDcpKTtcbiAgICAgICAgICAgICAgICBjb25zdCB1cGRhdGVkVmVoaWNsZSA9IGF3YWl0IGNvbnRleHQucHJpc21hLnZlaGljbGUudXBkYXRlKHtcbiAgICAgICAgICAgICAgICAgICAgd2hlcmU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkOiBhcmdzLmRhdGEuaWQsXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIGRhdGE6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXJ0ZWVuV2Vla0luc3BlY3Rpb246IG5leHRUaGlydGVlbldlZWtJbnNwZWN0aW9uLFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIHJldHVybiB1cGRhdGVkVmVoaWNsZTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICB0Lm5vbk51bGwuZmllbGQoJ3VwZGF0ZVZlaGljbGVUYWNob0NhbGlicmF0aW9uJywge1xuICAgICAgICAgICAgdHlwZTogZXhwb3J0cy5WZWhpY2xlLFxuICAgICAgICAgICAgYXJnczoge1xuICAgICAgICAgICAgICAgIGRhdGE6ICgwLCBuZXh1c18xLm5vbk51bGwpKCgwLCBuZXh1c18xLmFyZykoe1xuICAgICAgICAgICAgICAgICAgICB0eXBlOiBVcGRhdGVWZWhpY2xlRGF0ZXNXaXRoQ29tcGxldGlvbixcbiAgICAgICAgICAgICAgICB9KSksXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcmVzb2x2ZTogYXN5bmMgKF8sIGFyZ3MsIGNvbnRleHQpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCB2ZWhpY2xlID0gYXdhaXQgY29udGV4dC5wcmlzbWEudmVoaWNsZS5maW5kVW5pcXVlKHtcbiAgICAgICAgICAgICAgICAgICAgd2hlcmU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkOiBhcmdzLmRhdGEuaWQsXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgaWYgKCF2ZWhpY2xlKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignVGhpcyB2ZWhpY2xlIGRvZXMgbm90IGV4aXN0LicpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAoIXZlaGljbGUudGFjaG9DYWxpYnJhdGlvbikge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1RoaXMgdmVoaWNsZSBkb2VzIG5vdCBoYXZlIGEgdGhpcnRlZW4gd2VlayBpbnNwZWN0aW9uIGR1ZSBkYXRlIHNldC4nKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY29uc3QgeWVhcnNUb0FkZCA9IDI7XG4gICAgICAgICAgICAgICAgY29uc3QgY29tcGxldGlvbkRhdGUgPSBuZXcgRGF0ZShhcmdzLmRhdGEuY29tcGxldGlvbkRhdGUpO1xuICAgICAgICAgICAgICAgIGNvbnN0IG5leHRUYWNob0NhbGlicmF0aW9uID0gbmV3IERhdGUoY29tcGxldGlvbkRhdGUuc2V0RnVsbFllYXIoY29tcGxldGlvbkRhdGUuZ2V0RnVsbFllYXIoKSArIHllYXJzVG9BZGQpKTtcbiAgICAgICAgICAgICAgICBjb25zdCB1cGRhdGVkVmVoaWNsZSA9IGF3YWl0IGNvbnRleHQucHJpc21hLnZlaGljbGUudXBkYXRlKHtcbiAgICAgICAgICAgICAgICAgICAgd2hlcmU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkOiBhcmdzLmRhdGEuaWQsXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIGRhdGE6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRhY2hvQ2FsaWJyYXRpb246IG5leHRUYWNob0NhbGlicmF0aW9uLFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIHJldHVybiB1cGRhdGVkVmVoaWNsZTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH0sXG59KTtcbiIsIlwidXNlIHN0cmljdFwiO1xudmFyIF9faW1wb3J0RGVmYXVsdCA9ICh0aGlzICYmIHRoaXMuX19pbXBvcnREZWZhdWx0KSB8fCBmdW5jdGlvbiAobW9kKSB7XG4gICAgcmV0dXJuIChtb2QgJiYgbW9kLl9fZXNNb2R1bGUpID8gbW9kIDogeyBcImRlZmF1bHRcIjogbW9kIH07XG59O1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuZXhwb3J0cy5SRUZSRVNIX1RPS0VOX1NFQ1JFVCA9IGV4cG9ydHMuQUNDRVNTX1RPS0VOX1NFQ1JFVCA9IHZvaWQgMDtcbmNvbnN0IGV4cHJlc3NfMSA9IF9faW1wb3J0RGVmYXVsdChyZXF1aXJlKFwiZXhwcmVzc1wiKSk7XG5jb25zdCBjb29raWVfcGFyc2VyXzEgPSBfX2ltcG9ydERlZmF1bHQocmVxdWlyZShcImNvb2tpZS1wYXJzZXJcIikpO1xuY29uc3QgY29yc18xID0gX19pbXBvcnREZWZhdWx0KHJlcXVpcmUoXCJjb3JzXCIpKTtcbmNvbnN0IGFwb2xsb19zZXJ2ZXJfbGFtYmRhXzEgPSByZXF1aXJlKFwiYXBvbGxvLXNlcnZlci1sYW1iZGFcIik7XG5jb25zdCBzY2hlbWFfMSA9IF9faW1wb3J0RGVmYXVsdChyZXF1aXJlKFwiLi9zY2hlbWFcIikpO1xuY29uc3QgY29udGV4dF8xID0gcmVxdWlyZShcIi4vY29udGV4dFwiKTtcbmV4cG9ydHMuQUNDRVNTX1RPS0VOX1NFQ1JFVCA9ICd4dWR2aG9seGpla3N6ZWZ2c3V2b3N1ZWd2JztcbmV4cG9ydHMuUkVGUkVTSF9UT0tFTl9TRUNSRVQgPSAnYWtqd2RobGl1YXdkbFVXbGFkdWhhd3VkJztcbi8vIGNvbnN0IGNvcnNPcHRpb25zID0ge1xuLy8gICBvcmlnaW46ICdodHRwOi8vbG9jYWxob3N0OjMwMDAnLFxuLy8gICBjcmVkZW50aWFsczogdHJ1ZSxcbi8vIH07XG4vLyBjb25zdCBhcHAgPSBleHByZXNzKCk7XG4vLyBhcHAudXNlKGNvb2tpZVBhcnNlcigpKTtcbi8vIGFwcC51c2UoY29ycygpKTtcbi8vIGNvbnN0IGh0dHBTZXJ2ZXIgPSBodHRwLmNyZWF0ZVNlcnZlcihhcHApO1xuY29uc3Qgc2VydmVyID0gbmV3IGFwb2xsb19zZXJ2ZXJfbGFtYmRhXzEuQXBvbGxvU2VydmVyKHtcbiAgICBzY2hlbWE6IHNjaGVtYV8xLmRlZmF1bHQsXG4gICAgY29udGV4dDogY29udGV4dF8xLmNvbnRleHQsXG4gICAgLy8gcGx1Z2luczogW0Fwb2xsb1NlcnZlclBsdWdpbkRyYWluSHR0cFNlcnZlcih7IGh0dHBTZXJ2ZXIgfSldLFxufSk7XG4vLyBzZXJ2ZXIuYXBwbHlNaWRkbGV3YXJlKHtcbi8vICAgYXBwLFxuLy8gICBwYXRoOiAnLycsXG4vLyAgIGNvcnM6IGZhbHNlLFxuLy8gfSk7XG4vLyBhd2FpdCBuZXcgUHJvbWlzZTx2b2lkPigocmVzb2x2ZSkgPT5cbi8vICAgaHR0cFNlcnZlci5saXN0ZW4oeyBwb3J0OiA0MDAwIH0sIHJlc29sdmUpXG4vLyApO1xuZXhwb3J0cy5ncmFwaHFsSGFuZGxlciA9IHNlcnZlci5jcmVhdGVIYW5kbGVyKHtcbiAgICBleHByZXNzQXBwRnJvbU1pZGRsZXdhcmUoKSB7XG4gICAgICAgIGNvbnN0IGFwcCA9ICgwLCBleHByZXNzXzEuZGVmYXVsdCkoKTtcbiAgICAgICAgYXBwLnVzZSgoMCwgY29va2llX3BhcnNlcl8xLmRlZmF1bHQpKCkpO1xuICAgICAgICBhcHAudXNlKCgwLCBjb3JzXzEuZGVmYXVsdCkoKSk7XG4gICAgICAgIHJldHVybiBhcHA7XG4gICAgfSxcbn0pO1xuY29uc29sZS5sb2coYFxuICAgIPCfmoAgIFNlcnZlciBpcyBydW5uaW5nIVxuICAgIPCflIkgIExpc3RlbmluZyBvbiBwb3J0IDQwMDBcbiAgICDwn5OtICBRdWVyeSBhdCBodHRwczovL3N0dWRpby5hcG9sbG9ncmFwaHFsLmNvbS9kZXZcbiAgYCk7XG4iLCJcInVzZSBzdHJpY3RcIjtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbmZ1bmN0aW9uIGNyZWF0ZUNvbm5lY3Rpb24obmFtZSwgdmFsdWUpIHtcbiAgICBjb25zdCBzaG91bGRNb2RpZnkgPSB2YWx1ZSAhPT0gbnVsbDtcbiAgICByZXR1cm4gKHNob3VsZE1vZGlmeSAmJlxuICAgICAgICB7XG4gICAgICAgICAgICBbbmFtZV06IHZhbHVlID8geyBjb25uZWN0OiB7IGlkOiB2YWx1ZSB9IH0gOiB1bmRlZmluZWQsXG4gICAgICAgIH0pO1xufVxuZXhwb3J0cy5kZWZhdWx0ID0gY3JlYXRlQ29ubmVjdGlvbjtcbiIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuY29uc3QganNvbndlYnRva2VuXzEgPSByZXF1aXJlKFwianNvbndlYnRva2VuXCIpO1xuY29uc3Qgc2VydmVyXzEgPSByZXF1aXJlKFwiLi4vc2VydmVyXCIpO1xuY29uc3QgZ2VuZXJhdGVBY2Nlc3NUb2tlbiA9ICh1c2VySWQpID0+IHtcbiAgICBjb25zdCB0b2tlbiA9ICgwLCBqc29ud2VidG9rZW5fMS5zaWduKSh7XG4gICAgICAgIHVzZXJJZCxcbiAgICB9LCBzZXJ2ZXJfMS5BQ0NFU1NfVE9LRU5fU0VDUkVULCB7XG4gICAgICAgIGV4cGlyZXNJbjogJzE1bScsXG4gICAgfSk7XG4gICAgcmV0dXJuIHRva2VuO1xufTtcbmV4cG9ydHMuZGVmYXVsdCA9IGdlbmVyYXRlQWNjZXNzVG9rZW47XG4iLCJcInVzZSBzdHJpY3RcIjtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbmNvbnN0IGpzb253ZWJ0b2tlbl8xID0gcmVxdWlyZShcImpzb253ZWJ0b2tlblwiKTtcbmNvbnN0IHNlcnZlcl8xID0gcmVxdWlyZShcIi4uL3NlcnZlclwiKTtcbmNvbnN0IGdlbmVyYXRlUmVmcmVzaFRva2VuID0gKHVzZXJJZCkgPT4ge1xuICAgIGNvbnN0IHRva2VuID0gKDAsIGpzb253ZWJ0b2tlbl8xLnNpZ24pKHtcbiAgICAgICAgdXNlcklkLFxuICAgIH0sIHNlcnZlcl8xLlJFRlJFU0hfVE9LRU5fU0VDUkVULCB7XG4gICAgICAgIGV4cGlyZXNJbjogJzMwZCcsXG4gICAgfSk7XG4gICAgcmV0dXJuIHRva2VuO1xufTtcbmV4cG9ydHMuZGVmYXVsdCA9IGdlbmVyYXRlUmVmcmVzaFRva2VuO1xuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG5leHBvcnRzLmdldERhdGVUd29XZWVrcyA9IHZvaWQgMDtcbmNvbnN0IGdldERhdGVUd29XZWVrcyA9ICgpID0+IHtcbiAgICBjb25zdCB3ZWVrcyA9IDI7XG4gICAgY29uc3QgZGF0ZSA9IG5ldyBEYXRlKCk7XG4gICAgZGF0ZS5zZXREYXRlKGRhdGUuZ2V0RGF0ZSgpICsgd2Vla3MgKiA3KTtcbiAgICByZXR1cm4gZGF0ZTtcbn07XG5leHBvcnRzLmdldERhdGVUd29XZWVrcyA9IGdldERhdGVUd29XZWVrcztcbmV4cG9ydHMuZGVmYXVsdCA9IGV4cG9ydHMuZ2V0RGF0ZVR3b1dlZWtzO1xuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG5leHBvcnRzLmdldFJlZnJlc2hVc2VySWQgPSB2b2lkIDA7XG5jb25zdCBqc29ud2VidG9rZW5fMSA9IHJlcXVpcmUoXCJqc29ud2VidG9rZW5cIik7XG5jb25zdCBzZXJ2ZXJfMSA9IHJlcXVpcmUoXCIuLi9zZXJ2ZXJcIik7XG5jb25zdCBnZXRSZWZyZXNoVXNlcklkID0gKGNvbnRleHQpID0+IHtcbiAgICBjb25zdCB7IHJlZnJlc2hUb2tlbiB9ID0gY29udGV4dC5yZXEuY29va2llcztcbiAgICBpZiAocmVmcmVzaFRva2VuKSB7XG4gICAgICAgIGNvbnN0IHRva2VuID0gcmVmcmVzaFRva2VuLnJlcGxhY2UoJ0JlYXJlciAnLCAnJyk7XG4gICAgICAgIGNvbnN0IHZlcmlmaWVkVG9rZW4gPSAoMCwganNvbndlYnRva2VuXzEudmVyaWZ5KSh0b2tlbiwgc2VydmVyXzEuUkVGUkVTSF9UT0tFTl9TRUNSRVQpO1xuICAgICAgICByZXR1cm4gdmVyaWZpZWRUb2tlbiAmJiB2ZXJpZmllZFRva2VuLnVzZXJJZDtcbiAgICB9XG4gICAgcmV0dXJuIG51bGw7XG59O1xuZXhwb3J0cy5nZXRSZWZyZXNoVXNlcklkID0gZ2V0UmVmcmVzaFVzZXJJZDtcbmV4cG9ydHMuZGVmYXVsdCA9IGV4cG9ydHMuZ2V0UmVmcmVzaFVzZXJJZDtcbiIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuZXhwb3J0cy5nZXRVc2VySWQgPSB2b2lkIDA7XG5jb25zdCBqc29ud2VidG9rZW5fMSA9IHJlcXVpcmUoXCJqc29ud2VidG9rZW5cIik7XG5jb25zdCBzZXJ2ZXJfMSA9IHJlcXVpcmUoXCIuLi9zZXJ2ZXJcIik7XG5jb25zdCBnZXRVc2VySWQgPSAoY29udGV4dCkgPT4ge1xuICAgIGNvbnN0IGF1dGhIZWFkZXIgPSBjb250ZXh0LnJlcS5nZXQoJ0F1dGhvcml6YXRpb24nKTtcbiAgICBpZiAoYXV0aEhlYWRlcikge1xuICAgICAgICBjb25zdCB0b2tlbiA9IGF1dGhIZWFkZXIucmVwbGFjZSgnQmVhcmVyICcsICcnKTtcbiAgICAgICAgY29uc3QgdmVyaWZpZWRUb2tlbiA9ICgwLCBqc29ud2VidG9rZW5fMS52ZXJpZnkpKHRva2VuLCBzZXJ2ZXJfMS5BQ0NFU1NfVE9LRU5fU0VDUkVUKTtcbiAgICAgICAgcmV0dXJuIHZlcmlmaWVkVG9rZW4gJiYgdmVyaWZpZWRUb2tlbi51c2VySWQ7XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xufTtcbmV4cG9ydHMuZ2V0VXNlcklkID0gZ2V0VXNlcklkO1xuZXhwb3J0cy5kZWZhdWx0ID0gZXhwb3J0cy5nZXRVc2VySWQ7XG4iLCJcInVzZSBzdHJpY3RcIjtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbmZ1bmN0aW9uIHVwc2VydENvbm5lY3Rpb24obmFtZSwgb2xkVmFsdWUsIG5ld1ZhbHVlKSB7XG4gICAgLy8gd2UgbmVlZCB0byBtdXRhdGUgaWYgd2UncmUgY2hhbmdpbmcgdGhlIHZhbHVlIG9yIGlmIGdvaW5nIGZyb20gc2V0IC0+IHVuc2V0IG9yIHVuc2V0IC0+IHNldFxuICAgIC8vIE5PVEU6IGNvZXJjZSB0byBib29sZWFuIGJlY2F1c2UgZGIgaXMgbnVsbCBhbmQgYXJncyBhcmUgdW5kZWZpbmVkXG4gICAgY29uc3Qgc2hvdWxkTW9kaWZ5ID0gb2xkVmFsdWUgIT09IG5ld1ZhbHVlIHx8ICEhb2xkVmFsdWUgIT09ICEhbmV3VmFsdWU7XG4gICAgcmV0dXJuIChzaG91bGRNb2RpZnkgJiZcbiAgICAgICAge1xuICAgICAgICAgICAgW25hbWVdOiBuZXdWYWx1ZSA/IHsgY29ubmVjdDogeyBpZDogbmV3VmFsdWUgfSB9IDogeyBkaXNjb25uZWN0OiB0cnVlIH0sXG4gICAgICAgIH0pO1xufVxuZXhwb3J0cy5kZWZhdWx0ID0gdXBzZXJ0Q29ubmVjdGlvbjtcbiIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBwcmlzbWEvY2xpZW50XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImFwb2xsby1zZXJ2ZXItbGFtYmRhXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImJjcnlwdFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJjb29raWUtcGFyc2VyXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImNvcnNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiZXhwcmVzc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJncmFwaHFsLW1pZGRsZXdhcmVcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiZ3JhcGhxbC1zY2FsYXJzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImdyYXBocWwtc2hpZWxkXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImpzb253ZWJ0b2tlblwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh1c1wiKTsiLCIvLyBUaGUgbW9kdWxlIGNhY2hlXG52YXIgX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fID0ge307XG5cbi8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG5mdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuXHR2YXIgY2FjaGVkTW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXTtcblx0aWYgKGNhY2hlZE1vZHVsZSAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0cmV0dXJuIGNhY2hlZE1vZHVsZS5leHBvcnRzO1xuXHR9XG5cdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG5cdHZhciBtb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdID0ge1xuXHRcdC8vIG5vIG1vZHVsZS5pZCBuZWVkZWRcblx0XHQvLyBubyBtb2R1bGUubG9hZGVkIG5lZWRlZFxuXHRcdGV4cG9ydHM6IHt9XG5cdH07XG5cblx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG5cdF9fd2VicGFja19tb2R1bGVzX19bbW9kdWxlSWRdLmNhbGwobW9kdWxlLmV4cG9ydHMsIG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuXG5cdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG5cdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbn1cblxuIiwiIiwiLy8gc3RhcnR1cFxuLy8gTG9hZCBlbnRyeSBtb2R1bGUgYW5kIHJldHVybiBleHBvcnRzXG4vLyBUaGlzIGVudHJ5IG1vZHVsZSBpcyByZWZlcmVuY2VkIGJ5IG90aGVyIG1vZHVsZXMgc28gaXQgY2FuJ3QgYmUgaW5saW5lZFxudmFyIF9fd2VicGFja19leHBvcnRzX18gPSBfX3dlYnBhY2tfcmVxdWlyZV9fKDcyOCk7XG4iLCIiXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=